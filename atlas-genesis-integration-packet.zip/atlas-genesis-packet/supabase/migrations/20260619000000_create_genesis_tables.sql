-- ============================================================
-- ATLAS Genesis Command Center — Database Migration
-- Supabase / Postgres
-- Owner: Isaac Brandon Burdette / Atlas Genesis Matrix LLC
--
-- Instructions:
-- Place this file in supabase/migrations/
-- Name it: YYYYMMDDHHMMSS_create_genesis_tables.sql
-- Run: supabase db push  OR  supabase migration up
-- ============================================================

-- ─── PHASES ────────────────────────────────────────────────────

create table if not exists genesis_phases (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  slug        text not null,
  label       text not null,
  title       text not null,
  color       text not null default '#00f5c4',
  status      text not null default 'planned'
              check (status in ('active','planned','future','complete','archived')),
  eta         text,
  sort_order  integer not null default 0,
  created_by  uuid references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique(org_id, slug)
);

-- ─── AREAS ─────────────────────────────────────────────────────

create table if not exists genesis_areas (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  phase_id    uuid not null references genesis_phases(id) on delete cascade,
  slug        text not null,
  title       text not null,
  icon        text,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique(org_id, slug)
);

-- ─── TASKS ─────────────────────────────────────────────────────

create table if not exists genesis_tasks (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  phase_id    uuid not null references genesis_phases(id) on delete cascade,
  area_id     uuid not null references genesis_areas(id) on delete cascade,
  source_key  text not null,
  text        text not null,
  done        boolean not null default false,
  priority    text not null default 'medium'
              check (priority in ('critical','high','medium','low')),
  sort_order  integer not null default 0,
  assigned_to uuid references auth.users(id) on delete set null,
  due_date    date,
  created_by  uuid references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique(org_id, source_key)
);

-- ─── KANBAN COLUMNS ────────────────────────────────────────────

create table if not exists genesis_kanban_columns (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  key         text not null,
  label       text not null,
  color       text not null default '#444444',
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique(org_id, key)
);

-- ─── KANBAN CARDS ──────────────────────────────────────────────

create table if not exists genesis_kanban_cards (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  column_key  text not null,
  task_id     uuid references genesis_tasks(id) on delete set null,
  text        text not null,
  priority    text not null default 'medium'
              check (priority in ('critical','high','medium','low')),
  phase_label text,
  area_title  text,
  color       text,
  sort_order  integer not null default 0,
  created_by  uuid references auth.users(id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ─── IDEAS ─────────────────────────────────────────────────────

create table if not exists genesis_ideas (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null,
  source_number    integer,
  category         text not null
                   check (category in ('CAPTURE','GENERATE','PRIVACY','CONNECT','PATENT')),
  title            text not null,
  description      text not null,
  patent_direction text not null,
  status           text not null default 'concept',
  score            integer check (score >= 0 and score <= 100),
  tags             text[] not null default '{}',
  created_by       uuid references auth.users(id) on delete set null,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique(org_id, source_number)
);

-- ─── MINDMAP NODES ─────────────────────────────────────────────

create table if not exists genesis_mindmap_nodes (
  id                uuid primary key default gen_random_uuid(),
  org_id            uuid not null,
  source_key        text not null,
  label             text not null,
  x                 numeric not null,
  y                 numeric not null,
  radius            numeric not null,
  color             text not null,
  parent_source_key text,
  text_color        text default '#ffffff',
  sort_order        integer not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique(org_id, source_key)
);

-- ─── MOAT SECTIONS ─────────────────────────────────────────────

create table if not exists genesis_moat_sections (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  slug        text not null,
  icon        text,
  title       text not null,
  color       text not null default '#00f5c4',
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  unique(org_id, slug)
);

-- ─── MOAT ITEMS ────────────────────────────────────────────────

create table if not exists genesis_moat_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  section_id  uuid not null references genesis_moat_sections(id) on delete cascade,
  text        text not null,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ─── AUDIT EVENTS ──────────────────────────────────────────────

create table if not exists genesis_audit_events (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null,
  user_id      uuid references auth.users(id) on delete set null,
  action       text not null,
  entity_type  text not null,
  entity_id    uuid,
  metadata     jsonb not null default '{}',
  created_at   timestamptz not null default now()
);

-- ─── USER PREFERENCES ──────────────────────────────────────────

create table if not exists genesis_user_preferences (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null,
  user_id          uuid not null references auth.users(id) on delete cascade,
  default_view     text not null default 'roadmap',
  collapsed_phases jsonb not null default '{}',
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique(org_id, user_id)
);

-- ─── INDEXES ────────────────────────────────────────────────────

create index if not exists idx_genesis_phases_org_id on genesis_phases(org_id);
create index if not exists idx_genesis_phases_sort on genesis_phases(org_id, sort_order);

create index if not exists idx_genesis_areas_org_id on genesis_areas(org_id);
create index if not exists idx_genesis_areas_phase_id on genesis_areas(phase_id);

create index if not exists idx_genesis_tasks_org_id on genesis_tasks(org_id);
create index if not exists idx_genesis_tasks_phase_id on genesis_tasks(phase_id);
create index if not exists idx_genesis_tasks_area_id on genesis_tasks(area_id);
create index if not exists idx_genesis_tasks_done on genesis_tasks(org_id, done);
create index if not exists idx_genesis_tasks_priority on genesis_tasks(org_id, priority);

create index if not exists idx_genesis_kanban_cards_org_id on genesis_kanban_cards(org_id);
create index if not exists idx_genesis_kanban_cards_column on genesis_kanban_cards(org_id, column_key);
create index if not exists idx_genesis_kanban_cards_task on genesis_kanban_cards(task_id);
create index if not exists idx_genesis_kanban_cards_sort on genesis_kanban_cards(org_id, column_key, sort_order);

create index if not exists idx_genesis_ideas_org_id on genesis_ideas(org_id);
create index if not exists idx_genesis_ideas_category on genesis_ideas(org_id, category);
create index if not exists idx_genesis_ideas_source_number on genesis_ideas(org_id, source_number);

-- GIN index for tags array
create index if not exists idx_genesis_ideas_tags on genesis_ideas using gin(tags);

-- Full text search index for ideas
create index if not exists idx_genesis_ideas_fts on genesis_ideas using gin(
  to_tsvector('english',
    coalesce(title, '') || ' ' ||
    coalesce(description, '') || ' ' ||
    coalesce(patent_direction, '')
  )
);

create index if not exists idx_genesis_mindmap_org_id on genesis_mindmap_nodes(org_id);
create index if not exists idx_genesis_moat_sections_org_id on genesis_moat_sections(org_id);
create index if not exists idx_genesis_moat_items_section on genesis_moat_items(section_id);
create index if not exists idx_genesis_audit_events_org_id on genesis_audit_events(org_id);
create index if not exists idx_genesis_audit_events_user on genesis_audit_events(user_id);
create index if not exists idx_genesis_audit_events_created on genesis_audit_events(org_id, created_at desc);
create index if not exists idx_genesis_user_prefs_user on genesis_user_preferences(user_id);

-- ─── UPDATED_AT TRIGGER ─────────────────────────────────────────
-- Only add if the project already has a set_updated_at() function.
-- Check with: \df set_updated_at
-- If it exists, uncomment these blocks:

/*
create or replace trigger set_genesis_phases_updated_at
  before update on genesis_phases
  for each row execute function set_updated_at();

create or replace trigger set_genesis_areas_updated_at
  before update on genesis_areas
  for each row execute function set_updated_at();

create or replace trigger set_genesis_tasks_updated_at
  before update on genesis_tasks
  for each row execute function set_updated_at();

create or replace trigger set_genesis_kanban_columns_updated_at
  before update on genesis_kanban_columns
  for each row execute function set_updated_at();

create or replace trigger set_genesis_kanban_cards_updated_at
  before update on genesis_kanban_cards
  for each row execute function set_updated_at();

create or replace trigger set_genesis_ideas_updated_at
  before update on genesis_ideas
  for each row execute function set_updated_at();

create or replace trigger set_genesis_mindmap_nodes_updated_at
  before update on genesis_mindmap_nodes
  for each row execute function set_updated_at();

create or replace trigger set_genesis_moat_sections_updated_at
  before update on genesis_moat_sections
  for each row execute function set_updated_at();

create or replace trigger set_genesis_moat_items_updated_at
  before update on genesis_moat_items
  for each row execute function set_updated_at();

create or replace trigger set_genesis_user_preferences_updated_at
  before update on genesis_user_preferences
  for each row execute function set_updated_at();
*/

-- ─── ROW LEVEL SECURITY ─────────────────────────────────────────

alter table genesis_phases enable row level security;
alter table genesis_areas enable row level security;
alter table genesis_tasks enable row level security;
alter table genesis_kanban_columns enable row level security;
alter table genesis_kanban_cards enable row level security;
alter table genesis_ideas enable row level security;
alter table genesis_mindmap_nodes enable row level security;
alter table genesis_moat_sections enable row level security;
alter table genesis_moat_items enable row level security;
alter table genesis_audit_events enable row level security;
alter table genesis_user_preferences enable row level security;

-- ─── RLS POLICIES ───────────────────────────────────────────────
-- IMPORTANT: Adapt org membership check to match your existing
-- org_members table / membership check function.
-- Replace "your_org_membership_check()" with the real function.

-- Example policies (adjust org check to your actual schema):

-- Phases — read for org members
create policy "genesis_phases_read" on genesis_phases
  for select using (
    auth.uid() is not null
    -- and your_org_membership_check(org_id, auth.uid())
  );

-- Phases — write for admins only (enforce in server code too)
create policy "genesis_phases_write" on genesis_phases
  for all using (
    auth.uid() is not null
    -- and your_admin_check(org_id, auth.uid())
  );

-- Areas — read for org members
create policy "genesis_areas_read" on genesis_areas
  for select using (auth.uid() is not null);

create policy "genesis_areas_write" on genesis_areas
  for all using (auth.uid() is not null);

-- Tasks — read for org members
create policy "genesis_tasks_read" on genesis_tasks
  for select using (auth.uid() is not null);

-- Tasks — update for members (done toggle)
create policy "genesis_tasks_update" on genesis_tasks
  for update using (auth.uid() is not null);

-- Tasks — insert/delete for admins (server-side check also required)
create policy "genesis_tasks_insert" on genesis_tasks
  for insert with check (auth.uid() is not null);

create policy "genesis_tasks_delete" on genesis_tasks
  for delete using (auth.uid() is not null);

-- Kanban columns — read for org members
create policy "genesis_kanban_columns_read" on genesis_kanban_columns
  for select using (auth.uid() is not null);

create policy "genesis_kanban_columns_write" on genesis_kanban_columns
  for all using (auth.uid() is not null);

-- Kanban cards — read for org members, write for members+
create policy "genesis_kanban_cards_read" on genesis_kanban_cards
  for select using (auth.uid() is not null);

create policy "genesis_kanban_cards_write" on genesis_kanban_cards
  for all using (auth.uid() is not null);

-- Ideas — read for org members
create policy "genesis_ideas_read" on genesis_ideas
  for select using (auth.uid() is not null);

create policy "genesis_ideas_write" on genesis_ideas
  for all using (auth.uid() is not null);

-- Mindmap — read for org members
create policy "genesis_mindmap_nodes_read" on genesis_mindmap_nodes
  for select using (auth.uid() is not null);

create policy "genesis_mindmap_nodes_write" on genesis_mindmap_nodes
  for all using (auth.uid() is not null);

-- Moat sections — read for org members
create policy "genesis_moat_sections_read" on genesis_moat_sections
  for select using (auth.uid() is not null);

create policy "genesis_moat_sections_write" on genesis_moat_sections
  for all using (auth.uid() is not null);

-- Moat items — read for org members
create policy "genesis_moat_items_read" on genesis_moat_items
  for select using (auth.uid() is not null);

create policy "genesis_moat_items_write" on genesis_moat_items
  for all using (auth.uid() is not null);

-- Audit events — read for admins only (enforce in server code)
create policy "genesis_audit_events_read" on genesis_audit_events
  for select using (auth.uid() is not null);

-- Audit events — insert from server code only
create policy "genesis_audit_events_insert" on genesis_audit_events
  for insert with check (auth.uid() is not null);

-- User preferences — each user owns their own row
create policy "genesis_user_preferences_read" on genesis_user_preferences
  for select using (auth.uid() = user_id);

create policy "genesis_user_preferences_write" on genesis_user_preferences
  for all using (auth.uid() = user_id);
