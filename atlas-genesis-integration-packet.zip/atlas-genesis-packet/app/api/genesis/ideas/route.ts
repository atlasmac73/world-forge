// app/api/genesis/ideas/route.ts
// ATLAS Genesis Command Center — Ideas Search Endpoint
//
// GET /api/genesis/ideas?category=CAPTURE&q=search&limit=20&offset=0

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import {
  requireGenesisAccess,
  handleGenesisPermissionError,
} from "@/lib/genesis/permissions";
import { GENESIS_IDEA_PAGE_SIZE } from "@/lib/genesis/constants";
import type { GenesisIdeaCategory } from "@/lib/genesis/types";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

const VALID_CATEGORIES: GenesisIdeaCategory[] = [
  "CAPTURE",
  "GENERATE",
  "PRIVACY",
  "CONNECT",
  "PATENT",
];

export async function GET(req: NextRequest) {
  try {
    const ctx = await requireGenesisAccess();
    const { orgId } = ctx;

    const { searchParams } = new URL(req.url);
    const rawCategory = searchParams.get("category");
    const q = searchParams.get("q")?.trim() ?? "";
    const limit = Math.min(
      parseInt(searchParams.get("limit") ?? String(GENESIS_IDEA_PAGE_SIZE)),
      100
    );
    const offset = Math.max(
      parseInt(searchParams.get("offset") ?? "0"),
      0
    );

    const supabase = getServiceClient();

    let query = supabase
      .from("genesis_ideas")
      .select("*", { count: "exact" })
      .eq("org_id", orgId)
      .order("source_number", { ascending: true });

    // Category filter
    if (
      rawCategory &&
      rawCategory !== "ALL" &&
      VALID_CATEGORIES.includes(rawCategory as GenesisIdeaCategory)
    ) {
      query = query.eq("category", rawCategory);
    }

    // Full text search
    if (q.length > 0) {
      query = query.or(
        `title.ilike.%${q}%,description.ilike.%${q}%,patent_direction.ilike.%${q}%`
      );
    }

    // Pagination
    query = query.range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error("[genesis/ideas] Query error:", error);
      return NextResponse.json(
        { error: "Failed to fetch ideas" },
        { status: 500 }
      );
    }

    return NextResponse.json({
      ideas: data ?? [],
      total: count ?? 0,
      limit,
      offset,
      hasMore: offset + limit < (count ?? 0),
    });
  } catch (error) {
    const { error: message, status } = handleGenesisPermissionError(error);
    return NextResponse.json({ error: message }, { status });
  }
}
