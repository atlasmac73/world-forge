// app/api/genesis/tasks/[taskId]/route.ts
// ATLAS Genesis Command Center — Task Update Endpoint
//
// PATCH /api/genesis/tasks/[taskId]
// Toggle done, update text (admin), update priority (admin)

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import {
  requireGenesisAccess,
  handleGenesisPermissionError,
  canEditGenesisContent,
  canToggleGenesisTasks,
} from "@/lib/genesis/permissions";
import { UpdateTaskSchema } from "@/lib/genesis/validators";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

interface RouteParams {
  params: { taskId: string };
}

export async function PATCH(req: NextRequest, { params }: RouteParams) {
  try {
    const ctx = await requireGenesisAccess();
    const { orgId, userId } = ctx;
    const { taskId } = params;

    if (!taskId) {
      return NextResponse.json({ error: "Task ID required" }, { status: 400 });
    }

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid request body" },
        { status: 400 }
      );
    }

    const parsed = UpdateTaskSchema.safeParse({ ...body, taskId });
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid input", issues: parsed.error.issues },
        { status: 400 }
      );
    }

    const input = parsed.data;
    const supabase = getServiceClient();

    // Verify task belongs to org
    const { data: existing, error: fetchErr } = await supabase
      .from("genesis_tasks")
      .select("id, org_id, done, text")
      .eq("id", taskId)
      .eq("org_id", orgId)
      .single();

    if (fetchErr || !existing) {
      return NextResponse.json({ error: "Task not found" }, { status: 404 });
    }

    // Build update payload based on permissions
    const updates: Record<string, unknown> = {};

    if (input.done !== undefined) {
      const canToggle = await canToggleGenesisTasks();
      if (!canToggle) {
        return NextResponse.json(
          { error: "Not allowed to toggle tasks" },
          { status: 403 }
        );
      }
      updates.done = input.done;
    }

    // Text and priority updates require admin
    if (input.text !== undefined || input.priority !== undefined) {
      const canEdit = await canEditGenesisContent();
      if (!canEdit) {
        return NextResponse.json(
          { error: "Admin required to edit task content" },
          { status: 403 }
        );
      }
      if (input.text !== undefined) updates.text = input.text;
      if (input.priority !== undefined) updates.priority = input.priority;
    }

    if (Object.keys(updates).length === 0) {
      return NextResponse.json({ error: "No valid updates" }, { status: 400 });
    }

    updates.updated_at = new Date().toISOString();

    const { data: updated, error: updateErr } = await supabase
      .from("genesis_tasks")
      .update(updates)
      .eq("id", taskId)
      .eq("org_id", orgId)
      .select()
      .single();

    if (updateErr) {
      console.error("[genesis/tasks] Update error:", updateErr);
      return NextResponse.json(
        { error: "Failed to update task" },
        { status: 500 }
      );
    }

    return NextResponse.json({ task: updated });
  } catch (error) {
    const { error: message, status } = handleGenesisPermissionError(error);
    return NextResponse.json({ error: message }, { status });
  }
}
