// app/api/admin/genesis/seed/route.ts
// ATLAS Genesis Command Center — Admin Seed Endpoint
// Owner: Isaac Brandon Burdette / Atlas Genesis Matrix LLC
//
// POST /api/admin/genesis/seed
// Admin/owner only. Idempotent. Runs genesis seed for current org.

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import {
  requireGenesisAdmin,
  handleGenesisPermissionError,
} from "@/lib/genesis/permissions";
import {
  SEED_PHASES,
  SEED_AREAS,
  SEED_TASKS,
  SEED_KANBAN_COLUMNS,
  SEED_IDEAS,
  SEED_MINDMAP_NODES,
  SEED_MOAT_SECTIONS,
} from "@/lib/genesis/seed-data";

// Use service role client for seeding (server-side only)
function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

export async function POST(req: NextRequest) {
  try {
    // 1. Require admin/owner
    const ctx = await requireGenesisAdmin();
    const { orgId, userId } = ctx;
    const supabase = getServiceClient();

    const results: Record<string, number> = {};

    // 2. Seed phases
    const phaseRows = SEED_PHASES.map((p, i) => ({
      org_id: orgId,
      slug: p.slug,
      label: p.label,
      title: p.title,
      color: p.color,
      status: p.status,
      eta: p.eta,
      sort_order: p.sort_order,
      created_by: userId,
    }));

    const { data: phases, error: phaseErr } = await supabase
      .from("genesis_phases")
      .upsert(phaseRows, { onConflict: "org_id,slug", ignoreDuplicates: false })
      .select("id, slug");

    if (phaseErr) throw phaseErr;
    results.phases = phases?.length ?? 0;

    const phaseIdBySlug = Object.fromEntries(
      (phases ?? []).map((p) => [p.slug, p.id])
    );

    // 3. Seed areas
    const areaRows = SEED_AREAS.map((a) => ({
      org_id: orgId,
      phase_id: phaseIdBySlug[a.phase_slug],
      slug: a.slug,
      title: a.title,
      icon: a.icon,
      sort_order: a.sort_order,
    })).filter((a) => a.phase_id); // skip if phase not found

    const { data: areas, error: areaErr } = await supabase
      .from("genesis_areas")
      .upsert(areaRows, { onConflict: "org_id,slug", ignoreDuplicates: false })
      .select("id, slug");

    if (areaErr) throw areaErr;
    results.areas = areas?.length ?? 0;

    const areaIdBySlug = Object.fromEntries(
      (areas ?? []).map((a) => [a.slug, a.id])
    );

    // 4. Seed tasks
    const taskRows = SEED_TASKS.map((t, i) => {
      const area = SEED_AREAS.find((a) => a.slug === t.area_slug);
      const phase = SEED_PHASES.find((p) => p.slug === area?.phase_slug);
      return {
        org_id: orgId,
        phase_id: phase ? phaseIdBySlug[phase.slug] : undefined,
        area_id: areaIdBySlug[t.area_slug],
        source_key: t.source_key,
        text: t.text,
        priority: t.priority,
        sort_order: t.sort_order,
        done: false,
        created_by: userId,
      };
    }).filter((t) => t.phase_id && t.area_id);

    const { data: tasks, error: taskErr } = await supabase
      .from("genesis_tasks")
      .upsert(taskRows, {
        onConflict: "org_id,source_key",
        ignoreDuplicates: true,
      })
      .select("id, source_key");

    if (taskErr) throw taskErr;
    results.tasks = tasks?.length ?? 0;

    const taskIdBySourceKey = Object.fromEntries(
      (tasks ?? []).map((t) => [t.source_key, t.id])
    );

    // 5. Seed kanban columns
    const columnRows = SEED_KANBAN_COLUMNS.map((c) => ({
      org_id: orgId,
      key: c.key,
      label: c.label,
      color: c.color,
      sort_order: c.sort_order,
    }));

    const { data: columns, error: colErr } = await supabase
      .from("genesis_kanban_columns")
      .upsert(columnRows, { onConflict: "org_id,key", ignoreDuplicates: true })
      .select("id, key");

    if (colErr) throw colErr;
    results.kanban_columns = columns?.length ?? 0;

    // 6. Seed kanban cards from tasks (only if not already seeded)
    const existingCards = await supabase
      .from("genesis_kanban_cards")
      .select("task_id")
      .eq("org_id", orgId)
      .not("task_id", "is", null);

    const existingTaskIds = new Set(
      (existingCards.data ?? []).map((c) => c.task_id)
    );

    const cardRows = SEED_TASKS.map((t, i) => {
      const taskId = taskIdBySourceKey[t.source_key];
      if (!taskId || existingTaskIds.has(taskId)) return null;
      const area = SEED_AREAS.find((a) => a.slug === t.area_slug);
      const phase = SEED_PHASES.find((p) => p.slug === area?.phase_slug);
      return {
        org_id: orgId,
        column_key: "backlog" as const,
        task_id: taskId,
        text: t.text,
        priority: t.priority,
        phase_label: phase?.label ?? null,
        area_title: area?.title ?? null,
        color: phase?.color ?? null,
        sort_order: i,
        created_by: userId,
      };
    }).filter(Boolean);

    let cardSeedCount = 0;
    if (cardRows.length > 0) {
      const { data: cards, error: cardErr } = await supabase
        .from("genesis_kanban_cards")
        .insert(cardRows)
        .select("id");
      if (cardErr) throw cardErr;
      cardSeedCount = cards?.length ?? 0;
    }
    results.kanban_cards = cardSeedCount;

    // 7. Seed ideas
    const ideaRows = SEED_IDEAS.map((idea) => ({
      org_id: orgId,
      source_number: idea.source_number,
      category: idea.category,
      title: idea.title,
      description: idea.description,
      patent_direction: idea.patent_direction,
      status: "concept",
      created_by: userId,
    }));

    const { data: ideas, error: ideaErr } = await supabase
      .from("genesis_ideas")
      .upsert(ideaRows, {
        onConflict: "org_id,source_number",
        ignoreDuplicates: true,
      })
      .select("id");

    if (ideaErr) throw ideaErr;
    results.ideas = ideas?.length ?? 0;

    // 8. Seed mindmap nodes
    const nodeRows = SEED_MINDMAP_NODES.map((n) => ({
      org_id: orgId,
      source_key: n.source_key,
      label: n.label,
      x: n.x,
      y: n.y,
      radius: n.radius,
      color: n.color,
      parent_source_key: n.parent_source_key,
      text_color: n.text_color,
      sort_order: n.sort_order,
    }));

    const { data: nodes, error: nodeErr } = await supabase
      .from("genesis_mindmap_nodes")
      .upsert(nodeRows, {
        onConflict: "org_id,source_key",
        ignoreDuplicates: true,
      })
      .select("id");

    if (nodeErr) throw nodeErr;
    results.mindmap_nodes = nodes?.length ?? 0;

    // 9. Seed moat sections and items
    let moatSectionCount = 0;
    let moatItemCount = 0;

    for (const section of SEED_MOAT_SECTIONS) {
      const sectionRow = {
        org_id: orgId,
        slug: section.slug,
        icon: section.icon,
        title: section.title,
        color: section.color,
        sort_order: section.sort_order,
      };

      const { data: sec, error: secErr } = await supabase
        .from("genesis_moat_sections")
        .upsert([sectionRow], {
          onConflict: "org_id,slug",
          ignoreDuplicates: false,
        })
        .select("id")
        .single();

      if (secErr) throw secErr;
      moatSectionCount++;

      if (sec) {
        // Check existing items
        const existingItems = await supabase
          .from("genesis_moat_items")
          .select("id")
          .eq("section_id", sec.id);

        if ((existingItems.data ?? []).length === 0) {
          const itemRows = section.items.map((text, i) => ({
            org_id: orgId,
            section_id: sec.id,
            text,
            sort_order: i,
          }));

          const { data: items, error: itemErr } = await supabase
            .from("genesis_moat_items")
            .insert(itemRows)
            .select("id");

          if (itemErr) throw itemErr;
          moatItemCount += items?.length ?? 0;
        }
      }
    }

    results.moat_sections = moatSectionCount;
    results.moat_items = moatItemCount;

    // 10. Write audit event
    await supabase.from("genesis_audit_events").insert({
      org_id: orgId,
      user_id: userId,
      action: "seed",
      entity_type: "system",
      metadata: { results, seeded_at: new Date().toISOString() },
    });

    return NextResponse.json({
      success: true,
      message: "Genesis seed complete (idempotent)",
      results,
    });
  } catch (error) {
    const { error: message, status } = handleGenesisPermissionError(error);
    if (status === 401 || status === 403) {
      return NextResponse.json({ error: message }, { status });
    }
    console.error("[genesis/seed] Error:", error);
    return NextResponse.json(
      { error: "Seed failed. Check server logs." },
      { status: 500 }
    );
  }
}
