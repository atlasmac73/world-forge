// app/api/admin/genesis/reset/route.ts
// ATLAS Genesis Command Center — Admin Reset Endpoint
// Owner: Isaac Brandon Burdette / Atlas Genesis Matrix LLC
//
// POST /api/admin/genesis/reset
// OWNER ONLY. Requires exact confirmation string.
// Deletes ALL genesis data for the current org.

import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import {
  requireGenesisOwner,
  handleGenesisPermissionError,
} from "@/lib/genesis/permissions";
import { AdminResetSchema } from "@/lib/genesis/validators";
import { GENESIS_RESET_CONFIRMATION_TEXT } from "@/lib/genesis/constants";

function getServiceClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
}

export async function POST(req: NextRequest) {
  try {
    // 1. Require OWNER (not just admin)
    const ctx = await requireGenesisOwner();
    const { orgId, userId } = ctx;

    // 2. Parse and validate body
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        { error: "Invalid request body" },
        { status: 400 }
      );
    }

    const parsed = AdminResetSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          error: `Confirmation required. Send: { "confirm": "${GENESIS_RESET_CONFIRMATION_TEXT}" }`,
        },
        { status: 400 }
      );
    }

    const supabase = getServiceClient();

    // 3. Write audit event BEFORE deleting (so there's a record even if delete fails)
    await supabase.from("genesis_audit_events").insert({
      org_id: orgId,
      user_id: userId,
      action: "reset",
      entity_type: "system",
      metadata: {
        confirmed_by: userId,
        confirmed_at: new Date().toISOString(),
        warning: "All Genesis data deleted for org",
      },
    });

    // 4. Delete all genesis data for this org
    // Order matters: delete dependents first
    const tables = [
      "genesis_moat_items",
      "genesis_moat_sections",
      "genesis_mindmap_nodes",
      "genesis_ideas",
      "genesis_kanban_cards",
      "genesis_kanban_columns",
      "genesis_tasks",
      "genesis_areas",
      "genesis_phases",
      "genesis_user_preferences",
      // Note: Do NOT delete genesis_audit_events — preserve the audit trail
    ];

    const deleteResults: Record<string, boolean> = {};
    for (const table of tables) {
      const { error } = await supabase
        .from(table)
        .delete()
        .eq("org_id", orgId);

      deleteResults[table] = !error;
      if (error) {
        console.error(`[genesis/reset] Failed to delete ${table}:`, error);
      }
    }

    return NextResponse.json({
      success: true,
      message: "Genesis data reset complete for org",
      deleted: deleteResults,
    });
  } catch (error) {
    const { error: message, status } = handleGenesisPermissionError(error);
    if (status === 401 || status === 403) {
      return NextResponse.json({ error: message }, { status });
    }
    console.error("[genesis/reset] Error:", error);
    return NextResponse.json(
      { error: "Reset failed. Check server logs." },
      { status: 500 }
    );
  }
}
