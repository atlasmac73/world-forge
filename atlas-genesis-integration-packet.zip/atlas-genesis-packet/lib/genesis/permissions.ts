// lib/genesis/permissions.ts
// ATLAS Genesis Command Center — Permission Helpers
// Owner: Isaac Brandon Burdette / Atlas Genesis Matrix LLC
//
// IMPORTANT: Adapt these functions to use the ATLAS app's existing
// auth helpers, session helpers, and role/org membership system.
// Do NOT create a second role system if one already exists.

import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

// ─── Types ─────────────────────────────────────────────────────

export interface GenesisOrgContext {
  userId: string;
  orgId: string;
  role: "owner" | "admin" | "member" | "viewer";
}

export class GenesisAccessError extends Error {
  constructor(
    message: string,
    public statusCode: 401 | 403 = 403
  ) {
    super(message);
    this.name = "GenesisAccessError";
  }
}

// ─── Internal Helpers ──────────────────────────────────────────

function createSupabaseServerClient() {
  const cookieStore = cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options);
          });
        },
      },
    }
  );
}

// ─── Core Permission Functions ─────────────────────────────────

/**
 * Get the current user's org context for Genesis.
 * Adapt this to use the existing ATLAS org/user resolution.
 * Returns { userId, orgId, role } or throws GenesisAccessError.
 */
export async function getGenesisOrgContext(): Promise<GenesisOrgContext> {
  const supabase = createSupabaseServerClient();
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser();

  if (error || !user) {
    throw new GenesisAccessError("Not authenticated", 401);
  }

  // TODO: Replace this placeholder with your actual org membership lookup.
  // In ATLAS, this likely checks org_members or a similar table.
  // For now, we derive orgId from user metadata or a profile table.
  //
  // Example (adapt to your schema):
  // const { data: membership } = await supabase
  //   .from("org_members")
  //   .select("org_id, role")
  //   .eq("user_id", user.id)
  //   .single();
  //
  // if (!membership) throw new GenesisAccessError("Not a member of any org", 403);
  // return { userId: user.id, orgId: membership.org_id, role: membership.role };

  // Placeholder: use user's own id as org (single-user mode)
  // Replace with real org lookup
  const orgId =
    (user.user_metadata?.org_id as string) ??
    (user.app_metadata?.org_id as string) ??
    user.id;

  const role =
    (user.user_metadata?.role as GenesisOrgContext["role"]) ??
    (user.app_metadata?.role as GenesisOrgContext["role"]) ??
    "member";

  return {
    userId: user.id,
    orgId,
    role,
  };
}

/**
 * Require authenticated Genesis access (any authenticated user).
 * Throws GenesisAccessError if not authenticated.
 */
export async function requireGenesisAccess(): Promise<GenesisOrgContext> {
  return getGenesisOrgContext();
}

/**
 * Require admin or owner access for Genesis.
 * Throws GenesisAccessError if not admin/owner.
 */
export async function requireGenesisAdmin(): Promise<GenesisOrgContext> {
  const ctx = await getGenesisOrgContext();
  if (ctx.role !== "admin" && ctx.role !== "owner") {
    throw new GenesisAccessError("Genesis admin access required", 403);
  }
  return ctx;
}

/**
 * Require owner-only access (e.g., reset operation).
 * Throws GenesisAccessError if not owner.
 */
export async function requireGenesisOwner(): Promise<GenesisOrgContext> {
  const ctx = await getGenesisOrgContext();
  if (ctx.role !== "owner") {
    throw new GenesisAccessError("Genesis owner access required", 403);
  }
  return ctx;
}

/**
 * Check if the current user can edit Genesis content
 * (task text, idea records, moat sections).
 * Returns true for admin/owner.
 */
export async function canEditGenesisContent(): Promise<boolean> {
  try {
    const ctx = await getGenesisOrgContext();
    return ctx.role === "admin" || ctx.role === "owner";
  } catch {
    return false;
  }
}

/**
 * Check if the current user can manage Genesis admin actions
 * (seed, export, edit). Returns true for admin/owner.
 */
export async function canManageGenesisAdmin(): Promise<boolean> {
  try {
    const ctx = await getGenesisOrgContext();
    return ctx.role === "admin" || ctx.role === "owner";
  } catch {
    return false;
  }
}

/**
 * Check if the current user can reset Genesis data.
 * Returns true for owner only.
 */
export async function canResetGenesis(): Promise<boolean> {
  try {
    const ctx = await getGenesisOrgContext();
    return ctx.role === "owner";
  } catch {
    return false;
  }
}

/**
 * Check if the current user can toggle task done state.
 * Returns true for member, admin, owner.
 */
export async function canToggleGenesisTasks(): Promise<boolean> {
  try {
    const ctx = await getGenesisOrgContext();
    return ["member", "admin", "owner"].includes(ctx.role);
  } catch {
    return false;
  }
}

/**
 * Check if the current user can move Kanban cards.
 * Returns true for member, admin, owner.
 */
export async function canMoveGenesisKanbanCards(): Promise<boolean> {
  try {
    const ctx = await getGenesisOrgContext();
    return ["member", "admin", "owner"].includes(ctx.role);
  } catch {
    return false;
  }
}

// ─── Error Handler for API Routes ──────────────────────────────

/**
 * Convert a GenesisAccessError into an API response shape.
 * Use in API route catch blocks.
 */
export function handleGenesisPermissionError(error: unknown): {
  error: string;
  status: number;
} {
  if (error instanceof GenesisAccessError) {
    return { error: error.message, status: error.statusCode };
  }
  return { error: "Internal server error", status: 500 };
}
