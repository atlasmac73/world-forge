// lib/genesis/validators.ts
// ATLAS Genesis Command Center — Zod Mutation Validators

import { z } from "zod";

const PrioritySchema = z.enum(["critical", "high", "medium", "low"]);
const KanbanColumnKeySchema = z.enum(["backlog", "inprogress", "review", "done"]);
const IdeaCategorySchema = z.enum(["CAPTURE", "GENERATE", "PRIVACY", "CONNECT", "PATENT"]);
const PhaseStatusSchema = z.enum(["active", "planned", "future", "complete", "archived"]);

// ─── Tasks ─────────────────────────────────────────────────────

export const ToggleTaskSchema = z.object({
  taskId: z.string().uuid(),
  done: z.boolean(),
});

export const UpdateTaskTextSchema = z.object({
  taskId: z.string().uuid(),
  text: z.string().min(1).max(1000),
});

export const CreateTaskSchema = z.object({
  phaseId: z.string().uuid(),
  areaId: z.string().uuid(),
  text: z.string().min(1).max(1000),
  priority: PrioritySchema.default("medium"),
  sort_order: z.number().int().default(0),
});

export const UpdateTaskSchema = z.object({
  taskId: z.string().uuid(),
  text: z.string().min(1).max(1000).optional(),
  done: z.boolean().optional(),
  priority: PrioritySchema.optional(),
  assigned_to: z.string().uuid().nullable().optional(),
  due_date: z.string().nullable().optional(),
});

// ─── Kanban ────────────────────────────────────────────────────

export const MoveKanbanCardSchema = z.object({
  cardId: z.string().uuid(),
  columnKey: KanbanColumnKeySchema,
  sort_order: z.number().int().min(0).default(0),
});

export const CreateKanbanCardSchema = z.object({
  column_key: KanbanColumnKeySchema,
  text: z.string().min(1).max(500),
  priority: PrioritySchema.default("medium"),
  task_id: z.string().uuid().nullable().optional(),
  phase_label: z.string().max(100).nullable().optional(),
  area_title: z.string().max(200).nullable().optional(),
  color: z.string().max(20).nullable().optional(),
  sort_order: z.number().int().min(0).default(0),
});

export const UpdateKanbanCardSchema = z.object({
  cardId: z.string().uuid(),
  column_key: KanbanColumnKeySchema.optional(),
  text: z.string().min(1).max(500).optional(),
  priority: PrioritySchema.optional(),
  sort_order: z.number().int().min(0).optional(),
});

export const DeleteKanbanCardSchema = z.object({
  cardId: z.string().uuid(),
});

// ─── Ideas ─────────────────────────────────────────────────────

export const CreateIdeaSchema = z.object({
  category: IdeaCategorySchema,
  title: z.string().min(1).max(300),
  description: z.string().min(1).max(2000),
  patent_direction: z.string().min(1).max(1000),
  status: z.string().max(50).default("concept"),
  score: z.number().int().min(0).max(100).nullable().optional(),
  tags: z.array(z.string().max(50)).max(10).default([]),
});

export const UpdateIdeaSchema = z.object({
  ideaId: z.string().uuid(),
  category: IdeaCategorySchema.optional(),
  title: z.string().min(1).max(300).optional(),
  description: z.string().min(1).max(2000).optional(),
  patent_direction: z.string().min(1).max(1000).optional(),
  status: z.string().max(50).optional(),
  score: z.number().int().min(0).max(100).nullable().optional(),
  tags: z.array(z.string().max(50)).max(10).optional(),
});

export const DeleteIdeaSchema = z.object({
  ideaId: z.string().uuid(),
});

// ─── User Preferences ──────────────────────────────────────────

export const UpdateGenesisPreferencesSchema = z.object({
  default_view: z.enum(["roadmap", "kanban", "mindmap", "ideas", "moat"]).optional(),
  collapsed_phases: z.record(z.string(), z.boolean()).optional(),
});

// ─── Admin ─────────────────────────────────────────────────────

export const AdminSeedSchema = z.object({
  orgId: z.string().uuid().optional(), // defaults to current org
});

export const AdminResetSchema = z.object({
  confirm: z.literal("RESET GENESIS"), // exact match required
});

export const AdminExportSchema = z.object({
  orgId: z.string().uuid().optional(),
});

// ─── Phase/Area (Admin Edit) ────────────────────────────────────

export const UpdatePhaseSchema = z.object({
  phaseId: z.string().uuid(),
  title: z.string().min(1).max(200).optional(),
  status: PhaseStatusSchema.optional(),
  eta: z.string().max(100).nullable().optional(),
  color: z.string().max(20).optional(),
});

export const UpdateMoatSectionSchema = z.object({
  sectionId: z.string().uuid(),
  title: z.string().min(1).max(200).optional(),
  icon: z.string().max(10).nullable().optional(),
  color: z.string().max(20).optional(),
});

export const CreateMoatItemSchema = z.object({
  sectionId: z.string().uuid(),
  text: z.string().min(1).max(500),
  sort_order: z.number().int().default(0),
});

export const UpdateMoatItemSchema = z.object({
  itemId: z.string().uuid(),
  text: z.string().min(1).max(500).optional(),
  sort_order: z.number().int().optional(),
});

export const DeleteMoatItemSchema = z.object({
  itemId: z.string().uuid(),
});

// ─── Type exports ───────────────────────────────────────────────

export type ToggleTaskInput = z.infer<typeof ToggleTaskSchema>;
export type UpdateTaskTextInput = z.infer<typeof UpdateTaskTextSchema>;
export type CreateTaskInput = z.infer<typeof CreateTaskSchema>;
export type UpdateTaskInput = z.infer<typeof UpdateTaskSchema>;
export type MoveKanbanCardInput = z.infer<typeof MoveKanbanCardSchema>;
export type CreateKanbanCardInput = z.infer<typeof CreateKanbanCardSchema>;
export type UpdateKanbanCardInput = z.infer<typeof UpdateKanbanCardSchema>;
export type CreateIdeaInput = z.infer<typeof CreateIdeaSchema>;
export type UpdateIdeaInput = z.infer<typeof UpdateIdeaSchema>;
export type UpdateGenesisPreferencesInput = z.infer<typeof UpdateGenesisPreferencesSchema>;
export type AdminSeedInput = z.infer<typeof AdminSeedSchema>;
export type AdminResetInput = z.infer<typeof AdminResetSchema>;
