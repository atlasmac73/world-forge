// lib/genesis/types.ts
// ATLAS Genesis Command Center — TypeScript Types
// Owner: Isaac Brandon Burdette / Atlas Genesis Matrix LLC

export type GenesisPriority = "critical" | "high" | "medium" | "low";
export type GenesisPhaseStatus = "active" | "planned" | "future" | "complete" | "archived";
export type GenesisView = "roadmap" | "kanban" | "mindmap" | "ideas" | "moat";
export type GenesisIdeaCategory = "CAPTURE" | "GENERATE" | "PRIVACY" | "CONNECT" | "PATENT";
export type KanbanColumnKey = "backlog" | "inprogress" | "review" | "done";
export type GenesisEntityType =
  | "phase"
  | "area"
  | "task"
  | "kanban_card"
  | "kanban_column"
  | "idea"
  | "mindmap_node"
  | "moat_section"
  | "moat_item"
  | "system";

export interface GenesisPhase {
  id: string;
  org_id: string;
  slug: string; // "p1" - "p5"
  label: string; // "PHASE 1"
  title: string; // "FOUNDATION & PROTECTION"
  color: string; // hex
  status: GenesisPhaseStatus;
  eta: string | null;
  sort_order: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
  areas?: GenesisArea[];
}

export interface GenesisArea {
  id: string;
  org_id: string;
  phase_id: string;
  slug: string; // "a1" - "a8"
  title: string;
  icon: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
  tasks?: GenesisTask[];
}

export interface GenesisTask {
  id: string;
  org_id: string;
  phase_id: string;
  area_id: string;
  source_key: string; // "t1" - "t56"
  text: string;
  done: boolean;
  priority: GenesisPriority;
  sort_order: number;
  assigned_to: string | null;
  due_date: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface GenesisKanbanColumn {
  id: string;
  org_id: string;
  key: KanbanColumnKey;
  label: string;
  color: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
  cards?: GenesisKanbanCard[];
}

export interface GenesisKanbanCard {
  id: string;
  org_id: string;
  column_key: KanbanColumnKey;
  task_id: string | null;
  text: string;
  priority: GenesisPriority;
  phase_label: string | null;
  area_title: string | null;
  color: string | null;
  sort_order: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface GenesisIdea {
  id: string;
  org_id: string;
  source_number: number | null;
  category: GenesisIdeaCategory;
  title: string;
  description: string;
  patent_direction: string;
  status: string;
  score: number | null;
  tags: string[];
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface GenesisMindMapNode {
  id: string;
  org_id: string;
  source_key: string; // "root", "n1", "c1", etc
  label: string;
  x: number;
  y: number;
  radius: number;
  color: string;
  parent_source_key: string | null;
  text_color: string | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface GenesisMoatSection {
  id: string;
  org_id: string;
  slug: string;
  icon: string | null;
  title: string;
  color: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
  items?: GenesisMoatItem[];
}

export interface GenesisMoatItem {
  id: string;
  org_id: string;
  section_id: string;
  text: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface GenesisStats {
  totalTasks: number;
  doneTasks: number;
  progressPct: number;
  totalIdeas: number;
  totalPhases: number;
  totalAreas: number;
  kanbanColumns: number;
  kanbanCards: number;
}

export interface GenesisAuditEvent {
  id: string;
  org_id: string;
  user_id: string | null;
  action: string;
  entity_type: GenesisEntityType;
  entity_id: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface GenesisUserPreferences {
  id: string;
  org_id: string;
  user_id: string;
  default_view: GenesisView;
  collapsed_phases: Record<string, boolean>;
  created_at: string;
  updated_at: string;
}

export interface GenesisOverview {
  stats: GenesisStats;
  phases: GenesisPhase[];
  kanban: GenesisKanbanColumn[];
  ideas: GenesisIdea[];
  mindmap: GenesisMindMapNode[];
  moat: GenesisMoatSection[];
}

export interface GenesisAdminStatus {
  phaseCount: number;
  areaCount: number;
  taskCount: number;
  kanbanColumnCount: number;
  kanbanCardCount: number;
  ideaCount: number;
  mindmapNodeCount: number;
  moatSectionCount: number;
  moatItemCount: number;
  isSeeded: boolean;
}

// ─── Query Params ──────────────────────────────────────────────
export interface GenesisIdeaQuery {
  category?: GenesisIdeaCategory | "ALL";
  q?: string;
  limit?: number;
  offset?: number;
}
