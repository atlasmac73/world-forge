# GENESIS_DATA_MODEL.md — Database Schema Reference

## Scoping Rules

All Genesis tables must be scoped to the existing ATLAS org/user model.

- If the app uses `org_id` for multi-tenant scoping, all genesis tables must include `org_id`.
- If the app is single-user/single-org, still include `org_id` for future expansion.
- Never create a second user/auth system. Reuse existing `auth.users`, `org_members`, and permission helpers.
- `created_by` and `user_id` always reference `auth.users(id)`.

## Tables

### genesis_phases
The 5 roadmap phases. Seeded from PHASES data in prototype.

```sql
genesis_phases (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null,
  slug          text not null,           -- e.g. "p1", "p2"
  label         text not null,           -- e.g. "PHASE 1"
  title         text not null,           -- e.g. "FOUNDATION & PROTECTION"
  color         text not null,           -- hex color
  status        text not null check (status in ('active','planned','future','complete','archived')),
  eta           text,                    -- e.g. "Weeks 1-4"
  sort_order    integer not null default 0,
  created_by    uuid references auth.users(id),
  created_at    timestamptz default now(),
  updated_at    timestamptz default now(),
  unique(org_id, slug)
)
```

### genesis_areas
Areas inside each phase. Seeded from area objects in PHASES.

```sql
genesis_areas (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null,
  phase_id      uuid not null references genesis_phases(id) on delete cascade,
  slug          text not null,           -- e.g. "a1", "a2"
  title         text not null,
  icon          text,                    -- emoji icon
  sort_order    integer not null default 0,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now(),
  unique(org_id, slug)
)
```

### genesis_tasks
Individual tasks inside each area. Seeded from task objects in PHASES.

```sql
genesis_tasks (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null,
  phase_id      uuid not null references genesis_phases(id) on delete cascade,
  area_id       uuid not null references genesis_areas(id) on delete cascade,
  source_key    text not null,           -- original id: "t1", "t2", etc
  text          text not null,
  done          boolean not null default false,
  priority      text not null check (priority in ('critical','high','medium','low')),
  sort_order    integer not null default 0,
  assigned_to   uuid references auth.users(id),
  due_date      date,
  created_by    uuid references auth.users(id),
  created_at    timestamptz default now(),
  updated_at    timestamptz default now(),
  unique(org_id, source_key)
)
```

### genesis_kanban_columns
The 4 Kanban columns. Seeded from KANBAN_COLS.

```sql
genesis_kanban_columns (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null,
  key           text not null,           -- "backlog", "inprogress", "review", "done"
  label         text not null,           -- display label
  color         text not null,           -- hex color
  sort_order    integer not null default 0,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now(),
  unique(org_id, key)
)
```

### genesis_kanban_cards
Cards on the Kanban board. Seeded from all tasks (in backlog). Custom cards also stored here.

```sql
genesis_kanban_cards (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null,
  column_key    text not null,           -- current column: "backlog", "inprogress", etc
  task_id       uuid references genesis_tasks(id) on delete set null,  -- null for custom cards
  text          text not null,
  priority      text not null check (priority in ('critical','high','medium','low')),
  phase_label   text,                    -- e.g. "PHASE 1"
  area_title    text,                    -- e.g. "IP & Patent Defensive Moat"
  color         text,                    -- phase color
  sort_order    integer not null default 0,
  created_by    uuid references auth.users(id),
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
)
```

### genesis_ideas
The 100-idea library. Seeded from IDEAS_100.

```sql
genesis_ideas (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null,
  source_number    integer,              -- original idea number 1-100
  category         text not null check (category in ('CAPTURE','GENERATE','PRIVACY','CONNECT','PATENT')),
  title            text not null,
  description      text not null,
  patent_direction text not null,        -- stored as "IP Direction" in UI
  status           text not null default 'concept',
  score            integer,
  tags             text[] default '{}',
  created_by       uuid references auth.users(id),
  created_at       timestamptz default now(),
  updated_at       timestamptz default now(),
  unique(org_id, source_number)
)
```

### genesis_mindmap_nodes
SVG mind map nodes. Seeded from MINDMAP_NODES.

```sql
genesis_mindmap_nodes (
  id                uuid primary key default gen_random_uuid(),
  org_id            uuid not null,
  source_key        text not null,       -- original id: "root", "n1", "c1", etc
  label             text not null,
  x                 numeric not null,
  y                 numeric not null,
  radius            numeric not null,    -- "r" field from prototype
  color             text not null,
  parent_source_key text,               -- "parent" field from prototype
  text_color        text,               -- "textColor" from prototype
  sort_order        integer default 0,
  created_at        timestamptz default now(),
  updated_at        timestamptz default now(),
  unique(org_id, source_key)
)
```

### genesis_moat_sections
Patent moat sections. Seeded from prototype moat data.

```sql
genesis_moat_sections (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  slug        text not null,
  icon        text,
  title       text not null,
  color       text not null,
  sort_order  integer not null default 0,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now(),
  unique(org_id, slug)
)
```

### genesis_moat_items
Individual items inside each moat section.

```sql
genesis_moat_items (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null,
  section_id  uuid not null references genesis_moat_sections(id) on delete cascade,
  text        text not null,
  sort_order  integer not null default 0,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
)
```

### genesis_audit_events
Admin action audit log. Insert-only from server code.

```sql
genesis_audit_events (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null,
  user_id      uuid references auth.users(id),
  action       text not null,            -- "seed", "reset", "export", "edit_idea", etc
  entity_type  text not null,            -- "phase", "task", "idea", "moat", "kanban", "system"
  entity_id    uuid,
  metadata     jsonb default '{}',
  created_at   timestamptz default now()
)
```

### genesis_user_preferences
Per-user preferences like default view and collapsed phase state.

```sql
genesis_user_preferences (
  id               uuid primary key default gen_random_uuid(),
  org_id           uuid not null,
  user_id          uuid not null references auth.users(id),
  default_view     text default 'roadmap',
  collapsed_phases jsonb default '{}',   -- { "p1": true, "p2": false }
  created_at       timestamptz default now(),
  updated_at       timestamptz default now(),
  unique(org_id, user_id)
)
```

## Required Indexes

```sql
-- All main tables
create index on genesis_phases(org_id);
create index on genesis_areas(org_id);
create index on genesis_areas(phase_id);
create index on genesis_tasks(org_id);
create index on genesis_tasks(phase_id);
create index on genesis_tasks(area_id);
create index on genesis_tasks(done);
create index on genesis_kanban_cards(org_id);
create index on genesis_kanban_cards(column_key);
create index on genesis_kanban_cards(task_id);
create index on genesis_ideas(org_id);
create index on genesis_ideas(category);
create index on genesis_ideas(source_number);
create index on genesis_mindmap_nodes(org_id);
create index on genesis_moat_items(section_id);
create index on genesis_audit_events(org_id);
create index on genesis_audit_events(user_id);
create index on genesis_user_preferences(user_id);

-- GIN index for idea tags array
create index on genesis_ideas using gin(tags);

-- Full text search for ideas
create index on genesis_ideas using gin(
  to_tsvector('english', coalesce(title,'') || ' ' || coalesce(description,'') || ' ' || coalesce(patent_direction,''))
);
```

## Updated_at Triggers

If the repo uses an updated_at trigger pattern, apply it to all genesis tables:

```sql
-- Apply if the project already has a set_updated_at() trigger function
create trigger set_genesis_phases_updated_at before update on genesis_phases
  for each row execute function set_updated_at();
-- (Repeat for all genesis tables)
```
