# GENESIS_UI_SPEC.md — UI Design Specification

## Design Direction

The Genesis Command Center must preserve the **dark tactical command center aesthetic** from the prototype. This is intentional brand identity, not a placeholder style.

## Color Palette

```
Background (deep):      #060810
Background (card):      #0d1224
Background (hover):     #111827
Border (primary):       #00f5c440
Border (subtle):        #ffffff10

Accent — Phase 1:       #00f5c4  (cyan-green)
Accent — Phase 2:       #ff6b35  (orange)
Accent — Phase 3:       #a855f7  (purple)
Accent — Phase 4:       #facc15  (yellow)
Accent — Phase 5:       #ec4899  (pink)

Category — CAPTURE:     #00f5c4
Category — GENERATE:    #ff6b35
Category — PRIVACY:     #a855f7
Category — CONNECT:     #3b82f6
Category — PATENT:      #facc15

Priority — CRITICAL:    #ff4444
Priority — HIGH:        #ff6b35
Priority — MEDIUM:      #facc15
Priority — LOW:         #888888

Text (primary):         #e0e8ff
Text (secondary):       #aaaaaa
Text (muted):           #666666
```

## Typography

- Font family: `'Courier New', monospace` (tactical aesthetic)
- Body text: 12-14px
- Section labels: 11px, letter-spacing: 3-4px, uppercase
- Phase labels: 11px, font-weight: 900, letter-spacing: 3px
- Stats: 18px, font-weight: 900

## Layout

- `min-height: 100vh`
- `background: #060810`
- Max content width: 1200px, centered
- Sticky header with progress bar below it
- Tab navigation bar below progress bar
- Content area with 24px padding
- Responsive: mobile-friendly, no horizontal overflow

## Components

### Header
- Left: `◈ GENESIS SYSTEM` / `COMMAND CENTER` 
- Right: StatPills (PROGRESS %, TASKS done/total, IDEAS count, PHASES count)
- Sticky, z-index: 100
- Border-bottom: `1px solid #00f5c440`

### Progress Bar
- Height: 3px
- Background: `#111`
- Fill: `linear-gradient(90deg, #00f5c4, #3b82f6)`
- Transitions smoothly
- Width = percentage of tasks done

### Tab Navigation
- Tabs: 🗺 ROADMAP | 📋 KANBAN | 🧠 MIND MAP | 💡 100 IDEAS | 🛡 PATENT MOAT
- Active tab: `border: 1px solid #00f5c4`, `background: #00f5c415`, `color: #00f5c4`
- Inactive tab: `border: 1px solid #ffffff20`, `color: #888`
- Font: 11px, letter-spacing: 2px, font-weight: 700

### SectionTitle Component
```tsx
<div className="text-[11px] text-cyan-400 tracking-[4px] mb-5 font-bold">
  ◈ {children}
</div>
```

### PhaseTag Component
```tsx
// status: "active" | "planned" | "future"
const colors = { active: "#00f5c4", planned: "#facc15", future: "#888" }
<span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: `${color}20`, color }}>
  {status.toUpperCase()}
</span>
```

### PriorityBadge Component
```tsx
// priority: "critical" | "high" | "medium" | "low"
const colors = { critical: "#ff4444", high: "#ff6b35", medium: "#facc15", low: "#888" }
<span className="text-[9px] px-1.5 py-0.5 rounded tracking-widest" style={{ background: `${color}25`, color }}>
  {priority.toUpperCase()}
</span>
```

### Phase Card (Roadmap)
- Border: `1px solid {phase.color}40`
- Border-radius: 8px
- Header gradient: `linear-gradient(90deg, {phase.color}18, transparent)`
- Collapsible accordion
- Click anywhere on header to toggle

### Kanban Column
- Header: colored border-bottom matching column state
- Min-height: 400px
- Card drop zones
- "Add card" button at bottom

### Kanban Card
- Background: `#0d1224`
- Border: `1px solid {color}30`
- Drag handle indicator
- Priority badge top-right
- Phase/area label bottom

### Idea Card (Collapsed)
- Shows: number, category badge, title
- Click to expand
- Category badge: background `{catColor}20`, text `{catColor}`

### Idea Card (Expanded)
- Shows: title, description, "IP Direction / Internal Strategy Note" section
- IP Direction label in muted text style, not legal-advice styling

## Accessibility Requirements

- All buttons must be `<button>` elements with descriptive `aria-label` or visible text
- No `user-select: none` globally (breaks text selection for users)
- Mind map SVG nodes must have `<title>` tags for screen readers
- Tabs must have `role="tab"` and `aria-selected`
- Color is not the only indicator of state (include text labels)
- Focus outlines must be visible
- Keyboard navigable main views

## Responsive Breakpoints

- Mobile (< 768px): Single column, collapsed by default, scrollable
- Tablet (768-1024px): 2-column kanban max
- Desktop (> 1024px): Full 4-column kanban, full roadmap view

## Do NOT

- No emoji-only controls without accessible text alternatives
- No `user-select: none` on the entire page
- No `cursor: not-allowed` on non-disabled elements
- No inaccessible SVG (add titles/aria)
- No inline styles for every element — use Tailwind or existing class system where possible
- No giant monolithic single-file components
- No hardcoded task data in components (must come from DB/props)
