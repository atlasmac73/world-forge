# GENESIS_PRD.md — Genesis Command Center Product Requirements

## What Is Genesis Command Center?

Genesis Command Center is the **strategic operating module** for ATLAS OS. It is the founder's personal mission control — a protected, database-backed dashboard that manages:

- The 5-phase Genesis roadmap and all tasks
- Kanban execution board (persisted, drag-and-drop)
- 100-idea innovation library with search and category filtering
- Interactive mind map of the Genesis ecosystem
- Patent moat and IP strategy tracking
- Admin seed/reset/export controls
- Audit trail for all admin operations

## Why It Exists

The Genesis Command Center turns Isaac's entire product vision — from provisional patents to transmedia content to the Genesis Engine ingestion system — into a **live, actionable command center** inside the ATLAS app. It is not a prototype or a dashboard widget. It is a first-class module.

## Who Uses It

| Role | Access Level |
|---|---|
| Owner (Isaac) | Full access: view all, edit all, seed, reset, export, audit |
| Admin | Full access: view all, edit all, seed, export, audit |
| Member | Read + task toggle + kanban move |
| Viewer | Read-only |
| Public / Unauthenticated | No access |

## Routes

| Route | Access |
|---|---|
| `/genesis` | Authenticated users only |
| `/genesis/admin` | Admin/Owner only |
| `/api/genesis/*` | Auth-gated server routes |
| `/api/admin/genesis/*` | Admin/Owner server routes |

## Views Inside the Module

### 1. Roadmap View
- 5 phases accordion, collapsible per-user
- Areas inside each phase
- Tasks inside each area with priority badges
- Task toggle (done/undone) — persisted to DB
- Task text editing (admin/owner only)
- Phase-level progress stats
- Collapse state saved per user

### 2. Kanban View
- 4 columns: Backlog, In Progress, Review, Done
- Seeded from roadmap tasks
- Custom cards (user-added)
- Card move between columns — persisted to DB
- Sort order persisted
- Add/edit/delete custom cards

### 3. Mind Map View
- SVG-rendered mind map from DB nodes
- Parent-child edges drawn
- Hover states with node labels
- Responsive container
- Preserves original Genesis ecosystem layout from prototype

### 4. 100 Ideas Library View
- Database-backed, not client-side hardcoded
- Category filter: ALL / CAPTURE / GENERATE / PRIVACY / CONNECT / PATENT
- Full-text search: title, description, patent_direction
- Debounced input
- Query params: `view=ideas&category=CAPTURE&q=...`
- Expandable idea cards
- Patent direction labeled as "IP Direction / Internal Strategy Note"
- Pagination or load-more for 100+ records

### 5. Patent Moat View
- Database-backed sections and items
- Sections: Provisional Patents, Trade Secrets, Copyrights, Trademarks, Defensive Publications, Competitive Moat, IP Protection Timeline
- Content editable only by admin/owner
- Clear disclaimer: "Internal strategy content only, not legal advice"

## MVP Acceptance Criteria

- [ ] `/genesis` route exists and requires auth
- [ ] `/genesis/admin` route exists and requires admin/owner
- [ ] Database migration exists with all genesis_* tables
- [ ] Seed data creates all 5 phases, all areas, all tasks, all 100 ideas, all mindmap nodes, all moat sections
- [ ] Roadmap loads from database
- [ ] Task toggle persists to DB
- [ ] Kanban cards persist column moves to DB
- [ ] Custom kanban cards can be added and persist
- [ ] Ideas load from database
- [ ] Idea search (title, description, patent_direction) works
- [ ] Idea category filter works
- [ ] Mind map renders from DB nodes
- [ ] Patent moat renders from DB sections/items
- [ ] Admin seed action works (idempotent)
- [ ] Admin reset requires exact confirmation: "RESET GENESIS"
- [ ] Audit events are written for admin actions
- [ ] TypeScript typecheck passes
- [ ] Build passes
- [ ] `docs/GENESIS_MODULE.md` created

## Out of Scope for MVP (Future Phases)

- Universal content ingestion engine (video, audio, PDF)
- ChatGPT/Claude/Gemini chat importer
- Google Drive bidirectional sync
- Gmail/Calendar context engine
- Local encrypted vault
- TransMedia generation pipeline
- Autonomous agent tournament system
- Multi-AI model router
- 50-state / 195-country deployment
- Leon Therano transmedia saga (Portal P15)

## Technology Stack (ATLAS Standard)

- Next.js 14 (App Router)
- Supabase (Postgres + Auth + RLS)
- TypeScript (strict)
- Tailwind CSS
- Anthropic Claude SDK (for future AI features)
- Vercel deployment
- GitHub: atlasmac73/atlas-v22

## Owner

Isaac Brandon Burdette — sole founder, owner, and inventor
