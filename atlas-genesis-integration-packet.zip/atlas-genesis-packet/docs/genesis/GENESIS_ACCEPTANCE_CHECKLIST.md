# GENESIS_ACCEPTANCE_CHECKLIST.md — Definition of Done

Genesis is NOT complete until every item below is checked.

## Routes

- [ ] `/genesis` route exists
- [ ] `/genesis` redirects unauthenticated users to login
- [ ] `/genesis/admin` route exists
- [ ] `/genesis/admin` returns 403/redirect for non-admin/non-owner users
- [ ] Admin controls (seed, reset, export) are NOT visible or accessible to member/viewer roles

## Database

- [ ] Migration file exists in `supabase/migrations/`
- [ ] All 11 genesis_* tables are created:
  - [ ] genesis_phases
  - [ ] genesis_areas
  - [ ] genesis_tasks
  - [ ] genesis_kanban_columns
  - [ ] genesis_kanban_cards
  - [ ] genesis_ideas
  - [ ] genesis_mindmap_nodes
  - [ ] genesis_moat_sections
  - [ ] genesis_moat_items
  - [ ] genesis_audit_events
  - [ ] genesis_user_preferences
- [ ] All required indexes exist
- [ ] RLS is enabled on all genesis_* tables
- [ ] RLS policies prevent cross-org data access

## Seed Data

- [ ] Seed creates all 5 phases
- [ ] Seed creates all 8 areas
- [ ] Seed creates all 56 tasks (t1–t56)
- [ ] Seed creates 4 kanban columns
- [ ] Seed generates kanban cards from all tasks (placed in "backlog")
- [ ] Seed creates all 100 ideas
- [ ] Seed creates all 30+ mindmap nodes
- [ ] Seed creates all moat sections and items
- [ ] Seed is idempotent (running twice creates no duplicates)
- [ ] Seed endpoint is admin-only

## Roadmap View

- [ ] Roadmap loads from database (not hardcoded)
- [ ] Phases, areas, and tasks render correctly
- [ ] Phase colors match seed data
- [ ] Phase collapse/expand works
- [ ] Phase collapse state persists per user (DB or localStorage fallback)
- [ ] Task toggle (done/undone) works and persists to DB
- [ ] Priority badges render for each task
- [ ] Phase ETA labels show
- [ ] Overall progress stats update in header after task toggle

## Kanban View

- [ ] Kanban loads from database (not client-side array)
- [ ] All 4 columns render
- [ ] Cards are displayed in each column
- [ ] Moving a card to another column persists to DB
- [ ] Page refresh preserves card positions
- [ ] Custom card can be added to any column
- [ ] Custom card persists to DB
- [ ] Card edit works (admin) or text display works (member)
- [ ] Sort order persists within columns

## Idea Library View

- [ ] Ideas load from database (not hardcoded array)
- [ ] All 100 ideas display
- [ ] Category filter works: ALL, CAPTURE, GENERATE, PRIVACY, CONNECT, PATENT
- [ ] Search works across title, description, patent_direction
- [ ] Search is debounced (no API call on every keystroke)
- [ ] Search + filter can be combined
- [ ] Query params update: `?view=ideas&category=CAPTURE&q=...`
- [ ] Pagination or load-more works for large result sets
- [ ] Idea card expand/collapse works
- [ ] Patent direction is labeled "IP Direction / Internal Strategy Note" (not "patent" in UI)

## Mind Map View

- [ ] Mind map renders from DB nodes (not hardcoded)
- [ ] Root node renders at center
- [ ] Parent-child edges are drawn
- [ ] All category nodes render with correct colors
- [ ] Child nodes render around parent nodes
- [ ] Hover state shows node label
- [ ] SVG nodes have accessible titles
- [ ] Map is responsive within its container

## Patent Moat View

- [ ] Moat renders from DB sections and items (not hardcoded)
- [ ] All sections render: Provisional Patents, Trade Secrets, Copyrights, Trademarks, Defensive Publications, Competitive Moat
- [ ] IP Protection Timeline renders
- [ ] Disclaimer is visible: "Internal strategy content only, not legal advice"
- [ ] Content is editable only by admin/owner

## Admin Panel

- [ ] `/genesis/admin` loads for admin/owner
- [ ] Seed status shows data counts (phases, areas, tasks, cards, ideas, nodes, moat sections/items)
- [ ] "Seed Missing Data" button works
- [ ] Seed is idempotent (button can be pressed multiple times safely)
- [ ] "Export Genesis Data" button downloads JSON
- [ ] Audit log shows last 100 events
- [ ] Reset danger zone requires exact text: `RESET GENESIS`
- [ ] Reset API validates confirmation server-side
- [ ] All admin actions write to genesis_audit_events
- [ ] Admin panel is NOT accessible to member/viewer

## Types and Validation

- [ ] `lib/genesis/types.ts` exists with all interfaces
- [ ] `lib/genesis/validators.ts` exists with zod schemas for all mutations
- [ ] No `implicit any` TypeScript errors in genesis files
- [ ] All API routes validate request bodies

## Build Quality

- [ ] `npm run typecheck` (or equivalent) passes with no errors in genesis files
- [ ] `npm run build` passes or any failure is proven pre-existing
- [ ] `npm run lint` passes with no new errors
- [ ] No unused imports in genesis files
- [ ] No console.log left in production code paths
- [ ] No secrets hardcoded anywhere

## Documentation

- [ ] `docs/GENESIS_MODULE.md` exists
- [ ] GENESIS_MODULE.md includes: routes, tables, permissions, seed instructions, reset instructions, test commands, known limitations

## Ownership

- [ ] No UI copy, seed data, or admin text refers to anyone other than Isaac Brandon Burdette as owner/inventor of ATLAS/Genesis IP
- [ ] Patent moat view includes IP disclaimer
