# GENESIS_MASTER_INTEGRATION_PROMPT.md
# ATLAS Genesis Command Center — Master Claude Code Integration Prompt
# Owner: Isaac Brandon Burdette / Atlas Genesis Matrix LLC
#
# HOW TO USE:
# 1. Open Claude Code inside the atlas-v22 repo (genesis branch)
# 2. Copy/paste everything below into Claude Code
# 3. Claude Code will do a quick preflight, then integrate

---

You are working inside the existing ATLAS Next.js app repo (atlasmac73/atlas-v22, branch v67).

## STATUS

The current build has already been checked and is healthy. Do NOT restart a full audit. Do a 2-minute preflight, then begin integrating immediately.

## MISSION

Incorporate the Genesis Command Center module into the ATLAS app now. This is a production integration, not a prototype build.

All supporting docs and source files are in `/docs/genesis/`. The source prototype is at `/docs/genesis/GENESIS_SOURCE_PROTOTYPE.tsx`.

## PREFLIGHT ONLY (2 minutes)

Inspect only:
- `package.json` — detect package manager, existing deps, build/test commands
- `app/` structure — detect route groups, protected route pattern
- `lib/` structure — detect existing Supabase helpers, auth helpers, permission helpers
- `supabase/migrations/` — detect existing migration pattern
- `components/` — detect existing UI system (Tailwind, shadcn, etc.)
- `middleware.ts` — detect auth middleware pattern

Then immediately start implementing.

## INTEGRATION PLAN (in order)

### Step 1 — Apply Database Migration

Copy `/docs/genesis/supabase/migrations/20260619000000_create_genesis_tables.sql` into the existing `supabase/migrations/` folder.

Adapt the RLS policies to use the existing ATLAS org membership check (look for `org_members` table or existing RLS helpers in the codebase).

Run: `supabase db push` or `supabase migration up`

Verify all 11 genesis_* tables are created.

### Step 2 — Install Genesis Module Files

Copy these into the repo:

```
lib/genesis/types.ts         → from /docs/genesis/lib/genesis/types.ts
lib/genesis/validators.ts    → from /docs/genesis/lib/genesis/validators.ts
lib/genesis/constants.ts     → from /docs/genesis/lib/genesis/constants.ts
lib/genesis/seed-data.ts     → from /docs/genesis/lib/genesis/seed-data.ts
lib/genesis/permissions.ts   → from /docs/genesis/lib/genesis/permissions.ts
```

IMPORTANT: In `permissions.ts`, adapt `getGenesisOrgContext()` to use the existing ATLAS auth helper (e.g., `createServerComponentClient`, session helpers, existing user resolution). Do not create a second auth system.

### Step 3 — Install API Routes

Copy:
```
app/api/genesis/ideas/route.ts
app/api/genesis/tasks/[taskId]/route.ts
app/api/admin/genesis/seed/route.ts
app/api/admin/genesis/reset/route.ts
```

Also create:
- `app/api/admin/genesis/audit/route.ts` — GET, admin only, returns last 100 genesis_audit_events for org
- `app/api/genesis/kanban/cards/route.ts` — POST (create card) + GET (list cards by org)
- `app/api/genesis/kanban/cards/[cardId]/route.ts` — PATCH (move/edit), DELETE

### Step 4 — Create Protected Genesis Pages

Create the main Genesis page at the correct protected route location.

If the app uses `app/(dashboard)/` or `app/(app)/` or `app/(protected)/`, place it there:
```
app/(dashboard)/genesis/page.tsx
app/(dashboard)/genesis/loading.tsx
app/(dashboard)/genesis/error.tsx
app/(dashboard)/genesis/admin/page.tsx
```

If no route groups exist:
```
app/genesis/page.tsx
app/genesis/admin/page.tsx
```

The main page should:
- Be a server component
- Load genesis overview data server-side
- Pass typed initial data to client components
- Require auth (reuse existing auth guard pattern)

The admin page should:
- Require admin/owner (reuse existing admin guard)
- Show GenesisAdminPanel

### Step 5 — Build Component Tree

Create components from the prototype. Reference the prototype at `/docs/genesis/GENESIS_SOURCE_PROTOTYPE.tsx` for the exact product logic.

Refactor rules:
- Split the single-file prototype into the component tree in `components/genesis/`
- Replace inline styles with Tailwind (or existing CSS system)
- Preserve dark command-center aesthetic (colors, fonts in `lib/genesis/constants.ts`)
- Use typed props — no `implicit any`
- Remove global `user-select: none`
- Add accessible labels to buttons
- All data comes from DB props/API, not hardcoded arrays

Components to create:
```
components/genesis/GenesisCommandCenter.tsx
components/genesis/GenesisTabs.tsx
components/genesis/GenesisStats.tsx
components/genesis/RoadmapView.tsx
components/genesis/RoadmapPhaseCard.tsx
components/genesis/KanbanBoard.tsx
components/genesis/KanbanColumn.tsx
components/genesis/KanbanCard.tsx
components/genesis/MindMapView.tsx
components/genesis/IdeaLibraryView.tsx
components/genesis/IdeaCard.tsx
components/genesis/PatentMoatView.tsx
components/genesis/AdminGenesisPanel.tsx
components/genesis/PriorityBadge.tsx
components/genesis/PhaseTag.tsx
components/genesis/SectionTitle.tsx
```

### Step 6 — Seed Genesis Data

After migration and API routes are live:
1. Run the admin seed endpoint via the admin UI at `/genesis/admin`
   OR
2. Call `POST /api/admin/genesis/seed` with admin credentials

Verify seed created:
- 5 phases
- 8 areas
- 56 tasks
- 4 kanban columns
- 56 kanban cards in backlog
- 100 ideas
- 30+ mindmap nodes
- 6 moat sections with items

### Step 7 — Typecheck and Build

Run the project's actual commands from package.json:
```bash
npm run typecheck  # or npx tsc --noEmit
npm run lint
npm run build
```

Fix ALL TypeScript errors introduced by Genesis integration. If a build failure pre-existed before this integration, document it with exact evidence — do not hide pre-existing failures.

## CRITICAL RULES

1. Do not break existing routes, auth, billing, dashboard, admin, Supabase, or Vercel behavior
2. Do not hardcode secrets
3. Do not put SUPABASE_SERVICE_ROLE_KEY in client code
4. Do not create a second auth system
5. Reuse existing Supabase helpers, auth helpers, permissions helpers, org helpers
6. Isaac Brandon Burdette is the sole owner/founder/inventor — no other names in IP content
7. Patent/moat content must be labeled as internal strategy, not legal advice
8. Admin reset requires exact typed confirmation: RESET GENESIS
9. All admin actions write to genesis_audit_events
10. Typecheck and build must pass before calling this done

## SUPPORTING DOCS

All supporting specs are in `/docs/genesis/`:
- `GENESIS_PRD.md` — what the module is
- `GENESIS_DATA_MODEL.md` — full schema reference
- `GENESIS_ADMIN_SECURITY.md` — security rules
- `GENESIS_UI_SPEC.md` — design spec and colors
- `GENESIS_ACCEPTANCE_CHECKLIST.md` — definition of done
- `GENESIS_FUTURE_ROADMAP.md` — what NOT to build now
- `GENESIS_MODULE.md` — final module documentation

Also: `/docs/ATLAS_OWNERSHIP_AND_IP_RULES.md`

## FINAL REPORT FORMAT

When done, report exactly:
1. Preflight result (detected patterns)
2. Migration status
3. Files created
4. Files modified
5. Routes created
6. Components created
7. Seed status
8. Typecheck result
9. Build result
10. Any remaining manual steps or known blockers

Do NOT say "complete" unless typecheck passes, build passes, and the /genesis route loads.

Begin now. Preflight, then integrate.
