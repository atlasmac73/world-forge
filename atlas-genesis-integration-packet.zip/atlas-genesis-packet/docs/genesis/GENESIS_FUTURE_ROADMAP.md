# GENESIS_FUTURE_ROADMAP.md — What to Build Now vs Later

## Build NOW (MVP Sprint)

This is the scope of the current integration sprint.

### Protected Genesis Command Center Module
- `/genesis` route (authenticated)
- `/genesis/admin` route (admin/owner only)
- All 5 roadmap views: Roadmap, Kanban, Mind Map, Ideas, Patent Moat
- Database persistence for all views
- Admin seed, export, reset
- Audit log
- TypeScript, build passing

### Data Layer
- 11 genesis_* Supabase tables
- Migration file
- Seed data (5 phases, 8 areas, 56 tasks, 4 kanban columns, 100 ideas, 30+ mindmap nodes, moat sections)
- Idempotent seed

### Admin Panel
- Seed status
- Content counts
- Seed action (idempotent)
- Export action
- Reset (owner only, typed confirmation)
- Audit log viewer

---

## Build LATER (Future Phases — Do Not Include in MVP)

Do NOT attempt to build any of the following in the current sprint. Document them only.

### Phase 2 — Genesis Engine Universal Ingestion
- Universal content parser (PDF, video, audio, web, docs)
- Google Drive bidirectional sync
- YouTube transcript + metadata extractor
- Gmail/Google Calendar context sources
- ChatGPT/Claude/Gemini chat history importer
- GitHub repo code ingestion + semantic indexing
- Google Notebook export bridge
- Privacy firewall (user controls all data sharing)
- Local-first encrypted data vault

### Phase 2 — TransMedia Generation Engine
- Input-to-output transformer (any format → any format)
- PDF/Guide/Roadmap generator pipeline
- Slideshow/presentation auto-generator
- Podcast script + audio generation pipeline
- YouTube video script + storyboard generator
- Audiobook creator from any source material
- Interactive mind map auto-generator from content
- Spreadsheet + data viz auto-generator

### Phase 3 — App Unification
- Unified authentication (SSO across all apps)
- Shared component library across all apps
- Unified command center UI
- Cross-app data sharing layer
- Merge 4 apps into unified navigation shell

### Phase 4 — Beta Launch
- Waitlist landing page with NDA capture
- Beta feedback system
- Onboarding flow for beta users
- Privacy-respecting analytics for beta
- Transmedia content bible
- Companion app for books

### Phase 5 — Scale & Monetize
- Tiered subscription model (currently T1-T7 in ATLAS)
- Utility patents (full) for core innovations
- Developer API + marketplace launch
- Partnership/licensing deals
- Series A fundraise preparation

### Portal P15 — Leon Therano Transmedia Saga
- 13-book transmedia saga (Leon Therano)
- VR/metaverse portals
- Full transmedia franchise build

### Advanced AI Features
- Multi-AI router (Claude for reasoning, GPT-4o for code, Gemini for search)
- Autonomous agent tournament system
- ATLAS Memory OS pgvector integration (already partially built in v66)
- Self-improving Genesis Engine factory
- 50-state deployment
- 195-country deployment

---

## Architecture Notes for Future

- The Genesis Command Center MVP is intentionally scoped as a **read/write dashboard**.
- The Genesis Engine ingestion system (Phase 2) is a **separate buildout** that will connect to the Command Center later.
- The 100-idea library and patent moat are **static seed data** for MVP; future versions will allow real-time idea generation from the Genesis Engine.
- Mind map editing is **admin-future** — MVP shows the map from seed data only.
- The ATLAS Memory OS (`/second-brain` dashboard, pgvector, knowledge graph) built in v66 is a **parallel track** and will eventually connect to Genesis Engine as a data source.
