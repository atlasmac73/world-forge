# GENESIS_MODULE.md — Genesis Command Center Module

**Owner:** Isaac Brandon Burdette / Atlas Genesis Matrix LLC  
**Module:** Genesis Command Center  
**Version:** ATLAS v67

---

## Purpose

The Genesis Command Center is the strategic operations module for ATLAS OS. It converts the founder's product vision — across 5 phases, 56 tasks, 100 innovation ideas, and the full patent/IP strategy — into a **live, database-backed command center** inside the ATLAS app.

---

## Routes

| Route | Auth Required | Role Required |
|---|---|---|
| `/genesis` | ✅ Authenticated | Any authenticated user |
| `/genesis/admin` | ✅ Authenticated | Admin or Owner only |
| `GET /api/genesis/ideas` | ✅ Auth | Any member |
| `PATCH /api/genesis/tasks/[taskId]` | ✅ Auth | Member+ (done toggle); Admin+ (text edit) |
| `POST /api/admin/genesis/seed` | ✅ Auth | Admin or Owner |
| `POST /api/admin/genesis/reset` | ✅ Auth | **Owner only** |
| `GET /api/admin/genesis/audit` | ✅ Auth | Admin or Owner |

---

## Database Tables

All tables are prefixed with `genesis_`. All tables have RLS enabled.

| Table | Purpose |
|---|---|
| `genesis_phases` | 5 roadmap phases |
| `genesis_areas` | Areas within each phase |
| `genesis_tasks` | Individual tasks within each area |
| `genesis_kanban_columns` | 4 Kanban columns |
| `genesis_kanban_cards` | Cards on the Kanban board |
| `genesis_ideas` | 100-idea library |
| `genesis_mindmap_nodes` | SVG mind map nodes |
| `genesis_moat_sections` | Patent moat sections |
| `genesis_moat_items` | Items within moat sections |
| `genesis_audit_events` | Admin action audit log |
| `genesis_user_preferences` | Per-user UI preferences |

Migration file: `supabase/migrations/20260619000000_create_genesis_tables.sql`

---

## Permissions

| Action | Viewer | Member | Admin | Owner |
|---|---|---|---|---|
| View all tabs | ✅ | ✅ | ✅ | ✅ |
| Toggle task done | ❌ | ✅ | ✅ | ✅ |
| Move kanban card | ❌ | ✅ | ✅ | ✅ |
| Add custom kanban card | ❌ | ✅ | ✅ | ✅ |
| Edit task text | ❌ | ❌ | ✅ | ✅ |
| Edit ideas/moat | ❌ | ❌ | ✅ | ✅ |
| Seed genesis data | ❌ | ❌ | ✅ | ✅ |
| Export data | ❌ | ❌ | ✅ | ✅ |
| View audit log | ❌ | ❌ | ✅ | ✅ |
| **Reset genesis data** | ❌ | ❌ | ❌ | **✅** |

---

## How to Seed Genesis Data

### Option 1: Admin UI
1. Navigate to `/genesis/admin`
2. Click "Seed Missing Genesis Data"
3. Seed is idempotent — safe to run multiple times

### Option 2: API
```bash
curl -X POST https://atlasdealnavpro13.vercel.app/api/admin/genesis/seed \
  -H "Authorization: Bearer <your-session-token>" \
  -H "Content-Type: application/json"
```

### What Gets Seeded
- 5 roadmap phases
- 8 areas
- 56 tasks
- 4 Kanban columns
- Kanban cards for all tasks (placed in backlog)
- 100 ideas (CAPTURE, GENERATE, PRIVACY, CONNECT, PATENT)
- 30+ mind map nodes
- 6 moat sections with all items
- IP protection timeline (stored in moat section)

---

## How to Reset Genesis Data

> ⚠️ **Owner only.** This permanently deletes ALL Genesis data for the current org.

### Via Admin UI
1. Navigate to `/genesis/admin`
2. Scroll to "Danger Zone"
3. Type exactly: `RESET GENESIS`
4. Click "Reset"

### Via API
```bash
curl -X POST https://atlasdealnavpro13.vercel.app/api/admin/genesis/reset \
  -H "Authorization: Bearer <owner-session-token>" \
  -H "Content-Type: application/json" \
  -d '{"confirm": "RESET GENESIS"}'
```

Note: Audit events are NOT deleted during reset (for accountability).

---

## Test Commands

```bash
# Run TypeScript typecheck
npm run typecheck
# or
npx tsc --noEmit

# Run tests (if available)
npm run test

# Run linter
npm run lint

# Build check
npm run build
```

---

## Views

1. **Roadmap** — 5-phase accordion with areas and tasks
2. **Kanban** — 4-column board with persistent cards
3. **Mind Map** — SVG network of Genesis ecosystem
4. **100 Ideas** — Searchable, filterable innovation library
5. **Patent Moat** — IP strategy sections (internal only)

---

## Environment Variables Required

No new env vars required. Uses existing ATLAS Supabase configuration:

```env
NEXT_PUBLIC_SUPABASE_URL=<already set>
NEXT_PUBLIC_SUPABASE_ANON_KEY=<already set>
SUPABASE_SERVICE_ROLE_KEY=<already set, server-only>
```

---

## Component Structure

```
components/genesis/
  GenesisCommandCenter.tsx   — Main shell, tab state
  GenesisTabs.tsx            — Tab navigation
  GenesisStats.tsx           — Header stat pills
  RoadmapView.tsx            — Phase accordion + tasks
  RoadmapPhaseCard.tsx       — Single phase card
  KanbanBoard.tsx            — Kanban board shell
  KanbanColumn.tsx           — Single column
  KanbanCard.tsx             — Single card (draggable)
  MindMapView.tsx            — SVG mind map renderer
  IdeaLibraryView.tsx        — Ideas with search + filter
  IdeaCard.tsx               — Single expandable idea card
  PatentMoatView.tsx         — Moat sections display
  AdminGenesisPanel.tsx      — Admin seed/reset/audit UI
  PriorityBadge.tsx          — Priority color badge
  PhaseTag.tsx               — Phase status tag
  SectionTitle.tsx           — Section heading component
```

---

## Known Limitations

- Mind map editing is read-only in MVP (nodes are seeded, not editable via UI)
- Kanban drag-and-drop requires `@dnd-kit` — install if not already present
- RLS policies use a placeholder org membership check — adapt to actual ATLAS org_members schema
- Phase collapse preferences fall back to localStorage if DB preference save fails
- Reset is hard — there is no undo

---

## IP Notice

This module contains internal IP strategy content. Patent/IP direction fields are displayed as "IP Direction / Internal Strategy Notes" in the UI. This is NOT legal advice.

**Owner:** Isaac Brandon Burdette  
**Entity:** Atlas Genesis Matrix LLC  
**GitHub:** atlasmac73/atlas-v22  
**Supabase:** kjfwanpwzgcscgsdgekm  
**Vercel:** atlasdealnavpro13.vercel.app
