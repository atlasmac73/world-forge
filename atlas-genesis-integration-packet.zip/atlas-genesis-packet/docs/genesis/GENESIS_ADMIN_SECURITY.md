# GENESIS_ADMIN_SECURITY.md — Admin Access and Security Rules

## Admin Route

```
/genesis/admin
```

**Only admin and owner roles can access this route.**

Client-side hiding is NOT sufficient. Server-side permission checks are REQUIRED in both the page component and all API routes.

## Admin vs Member Permissions Matrix

| Action | Viewer | Member | Admin | Owner |
|---|---|---|---|---|
| View roadmap | ✅ | ✅ | ✅ | ✅ |
| View kanban | ✅ | ✅ | ✅ | ✅ |
| View ideas | ✅ | ✅ | ✅ | ✅ |
| View mind map | ✅ | ✅ | ✅ | ✅ |
| View patent moat | ✅ | ✅ | ✅ | ✅ |
| Toggle task done | ❌ | ✅ | ✅ | ✅ |
| Move kanban card | ❌ | ✅ | ✅ | ✅ |
| Add custom kanban card | ❌ | ✅ | ✅ | ✅ |
| Edit task text | ❌ | ❌ | ✅ | ✅ |
| Edit idea record | ❌ | ❌ | ✅ | ✅ |
| Edit moat content | ❌ | ❌ | ✅ | ✅ |
| Seed Genesis data | ❌ | ❌ | ✅ | ✅ |
| Export Genesis data | ❌ | ❌ | ✅ | ✅ |
| View audit log | ❌ | ❌ | ✅ | ✅ |
| Reset Genesis data | ❌ | ❌ | ❌ | ✅ |

## Admin Actions

### Seed Missing Data
- Button: "Seed Missing Genesis Data"
- Calls `/api/admin/genesis/seed`
- Idempotent — safe to run multiple times
- Creates missing phases, areas, tasks, ideas, kanban columns, mindmap nodes, moat sections
- Does NOT duplicate existing rows (upsert by org_id + slug/source_key)
- Writes audit event: `{ action: "seed", entity_type: "system" }`

### Export Data
- Button: "Export Genesis Data (JSON)"
- Calls `/api/admin/genesis/export`
- Returns all Genesis data for the current org as JSON
- Writes audit event: `{ action: "export", entity_type: "system" }`

### View Audit Log
- GET `/api/admin/genesis/audit`
- Shows last 100 admin events
- Fields: created_at, user_id, action, entity_type, entity_id, metadata

### Edit Content
- Edit phases: admin only
- Edit task text: admin only
- Edit idea records: admin only
- Edit moat sections/items: admin only
- All edits write audit events

### Reset Danger Zone

**RESET REQUIRES TYPED CONFIRMATION.**

The reset form must:
1. Display a warning: "This will delete ALL Genesis data for this org and cannot be undone."
2. Require the user to type exactly: `RESET GENESIS`
3. The API request must include `{ "confirm": "RESET GENESIS" }` in the body
4. If the confirm field does not match exactly, the API returns 400
5. Only owner role can call reset (not just admin)
6. Writes audit event: `{ action: "reset", entity_type: "system", metadata: { confirmed_by: userId, timestamp: ISO } }`

```typescript
// API route safety check — never skip this
if (body.confirm !== "RESET GENESIS") {
  return NextResponse.json({ error: "Confirmation required" }, { status: 400 });
}
await requireGenesisOwner(req); // not just admin — owner only
```

## Security Rules

### API Routes
All `/api/genesis/*` routes must:
- Validate session/auth using existing project auth helpers
- Check org membership
- Return 401 if not authenticated
- Return 403 if not authorized
- Never return raw DB errors to client
- Never log secrets or tokens

All `/api/admin/genesis/*` routes must additionally:
- Check admin/owner role using existing project permission helpers
- Return 403 if not admin/owner
- Write audit events for all state-changing actions

### No Client-Side Auth Checks Alone
Never rely solely on UI-level hiding of admin controls. Every mutation must be protected server-side.

### No Service Role in Client Code
Never put the Supabase service role key in any client-side code or any `'use client'` component.

### RLS on All Genesis Tables
Every genesis_* table must have Row Level Security enabled. RLS policies must prevent users from reading or writing data for orgs they don't belong to, even if they bypass the UI.

## Environment Variables

Use only the existing ATLAS environment variable pattern. Do not hardcode values.

```env
# Already set in ATLAS .env — do not duplicate
NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=... # server-only, never exposed to client
```
