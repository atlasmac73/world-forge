# ATLAS Ownership and IP Rules

## Sole Owner, Founder, and Inventor

**Isaac Brandon Burdette** is the sole owner, founder, and inventor of:

- ATLAS OS / Atlas Genesis Matrix LLC
- Genesis Engine™
- TransMedia Engine™
- Genesis Command Center™
- The People's AI™
- SPECTER skip trace engine
- All ATLAS portal modules, subscription tiers, and AI agent systems
- All associated IP, trademarks, copyrights, trade secrets, and provisional patents

## Entity Clarifications

| Entity | Person | Relationship to ATLAS IP |
|---|---|---|
| Atlas Genesis Matrix LLC | Isaac Brandon Burdette | Owner / Inventor |
| All Trades Construction (WV) | Isaac Brandon Burdette | Separate business |
| Atlas Management & Construction LLC | Nalone Stallings | WV operations support — NOT an inventor of ATLAS IP |
| Burdette Built LLC (Denver CO) | Adrian Burdette | Isaac's brother — separate entity, NOT an inventor of ATLAS IP |

## Rules for Claude Code / AI Integration Work

1. Any document, UI copy, database seed, admin note, patent/IP section, or audit trail that lists anyone other than Isaac Brandon Burdette as inventor of ATLAS Genesis Matrix IP must be corrected before legal or business use.

2. Nalone Stallings is a business collaborator/operations support person, not an inventor. Do not attribute ATLAS IP to Nalone.

3. Adrian Burdette runs Burdette Built LLC (Denver) as a separate construction entity. Do not attribute ATLAS IP to Adrian.

4. Patent/IP content inside the ATLAS app is **internal strategy content** and is **not legal advice**. Always label it clearly as such.

5. The Genesis Command Center patent moat view must include the disclaimer: *"This section contains internal IP strategy notes for founder review only. This is not legal advice. Consult a qualified IP attorney for legal guidance."*

## Current IP Assets (Do Not Modify Without Owner Approval)

- AGM-001-GC — Genesis Cycle (6-phase SENSE→INTERPRET→MUTATE→SIMULATE→PROMOTE→LEARN)
- AGM-002-ST — SPECTER Skip Trace
- AGM-013-BR — Base Reality Recording™
- AGM-015-ND — NASDROP (hidden God Mode trigger)
- SOM™ — Sovereign Operating Model
- 100-idea defensive publication catalog (Genesis Command Center)
- 5-phase Genesis Engine roadmap

## Coined Terms (Do Not Attribute to Others)

- "Base Reality Recording™" — coined March 2026 by Isaac Brandon Burdette
- "Sovereign Operating Model (SOM™)" — coined by Isaac Brandon Burdette
- "Genesis Engine™" — coined by Isaac Brandon Burdette
- "TransMedia Engine™" — coined by Isaac Brandon Burdette
- "The People's AI™" — coined by Isaac Brandon Burdette

## USPTO Filing Status

Five provisional patent applications drafted. USPTO filing at patentcenter.uspto.gov pending confirmation. Do not claim "filed" status in any UI copy until filing is confirmed.
