/**
 * ATLAS v20 — Main App Shell
 * Renders the sidebar + active portal dynamically
 */

'use client'

import { useAtlasStore } from '@/store/useAtlasStore'
import { Sidebar } from '@/components/Sidebar'
import { Dashboard } from '@/components/portals/Dashboard'
import { DealNavigator } from '@/components/portals/DealNavigator'
import { CommsHub } from '@/components/portals/CommsHub'
import { MarketIntel } from '@/components/portals/MarketIntel'
import { AgentLab } from '@/components/portals/AgentLab'
import { SP6Wallet } from '@/components/portals/SP6Wallet'
import { Settings } from '@/components/portals/Settings'
import { SwarmNexus } from '@/components/portals/SwarmNexus'
import { WarRoom } from '@/components/portals/WarRoom'
import { VoiceAgent } from '@/components/portals/VoiceAgent'
import { SignalStack } from '@/components/portals/SignalStack'
import { CommandPalette } from '@/components/CommandPalette'
import { CopilotPanel } from '@/components/CopilotPanel'
import { TopBar } from '@/components/TopBar'

const PORTALS = {
  'dashboard':      <Dashboard />,
  'deal-navigator': <DealNavigator />,
  'comms-hub':      <CommsHub />,
  'market-intel':   <MarketIntel />,
  'agent-lab':      <AgentLab />,
  'sp6-wallet':     <SP6Wallet />,
  'settings':       <Settings />,
  'swarm-nexus':    <SwarmNexus />,
  'war-room':       <WarRoom />,
  'voice-agent':    <VoiceAgent />,
  'signal-stack':   <SignalStack />,
}

export default function AtlasApp() {
  const { activePortal } = useAtlasStore()

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-atlas-dark atlas-grid">
      {/* Left Sidebar Navigation */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar />
        <main className="flex-1 overflow-auto p-4">
          <div className="animate-fade-in">
            {PORTALS[activePortal] ?? <Dashboard />}
          </div>
        </main>
      </div>

      {/* Right Copilot Panel */}
      <CopilotPanel />
      
      {/* Command Palette (Cmd+K) */}
      <CommandPalette />
    </div>
  )
}
