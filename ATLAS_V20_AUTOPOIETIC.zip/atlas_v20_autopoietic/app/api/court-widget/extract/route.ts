/**
 * ATLAS v20 — Court Widget AI Extract API
 * POST /api/court-widget/extract
 * Extracts structured docket data from raw text.
 * Uses either the bloated v1 prompt or the mutated v2 prompt.
 * Always logs metrics for the Heartbeat to analyze.
 */

import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { createClient } from '@/lib/supabase/server'
import { calculateRunCost } from '@/lib/autopoietic/limits'
import {
  COURT_EXTRACT_PROMPT_V1,
  COURT_EXTRACT_PROMPT_V2,
} from '@/components/portals/CourtWidget'

export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { rawText, promptVersion = 'v1' } = await req.json()
  if (!rawText?.trim()) {
    return NextResponse.json({ error: 'rawText required' }, { status: 400 })
  }

  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: 'ANTHROPIC_API_KEY not configured' }, { status: 500 })
  }

  const client = new Anthropic({ apiKey })
  const prompt = promptVersion === 'v2' ? COURT_EXTRACT_PROMPT_V2 : COURT_EXTRACT_PROMPT_V1
  const start  = Date.now()

  try {
    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 600,
      messages: [{ role: 'user', content: prompt + '\n' + rawText }],
    })

    const latency_ms = Date.now() - start
    const text = response.content.find(b => b.type === 'text')?.text ?? '{}'
    const clean = text.replace(/```json|```/g, '').trim()
    const docket = JSON.parse(clean)

    const cost_usd = calculateRunCost(
      response.usage.input_tokens,
      response.usage.output_tokens
    )

    // Log to agent_runs for Heartbeat monitoring
    await supabase.from('agent_runs').insert({
      user_id: user.id,
      session_id: `court-widget-${Date.now()}`,
      tool_name: 'court.aiExtract',
      input: { rawTextLength: rawText.length, promptVersion },
      output: { docket, latency_ms, cost_usd },
      status: 'completed',
      tokens_used: response.usage.input_tokens + response.usage.output_tokens,
      credits_consumed: 3,
      completed_at: new Date().toISOString(),
    })

    return NextResponse.json({
      docket,
      cost_usd,
      latency_ms,
      usage: response.usage,
      prompt_version: promptVersion,
    })

  } catch (err) {
    const message = err instanceof Error ? err.message : 'Extraction failed'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
