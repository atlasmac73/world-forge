/**
 * ATLAS v20 — Heartbeat API Route
 * POST /api/heartbeat  → Run a Heartbeat cycle manually (God Mode)
 * GET  /api/heartbeat  → Get latest cycle status
 *
 * Vercel Cron triggers POST every 15 minutes (see vercel.json).
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { runHeartbeatCycle } from '@/lib/autopoietic/heartbeat'
import { DEFAULT_LIMITS } from '@/lib/autopoietic/limits'

// ─── POST: Trigger heartbeat ──────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  // Verify cron secret (Vercel sets this header automatically)
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env.CRON_SECRET
  const isVercelCron = authHeader === `Bearer ${cronSecret}`
  const isMockCron   = cronSecret === undefined // Dev mode: no secret required

  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  // Allow: verified cron OR logged-in user (God Mode manual trigger)
  if (!isVercelCron && !isMockCron && !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const userId = user?.id ?? 'system-heartbeat'
  const body = await req.json().catch(() => ({}))
  const limits = { ...DEFAULT_LIMITS, ...body.limits }

  try {
    const cycle = await runHeartbeatCycle(userId, limits)
    return NextResponse.json({ success: true, cycle })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Heartbeat failed'
    return NextResponse.json({ success: false, error: message }, { status: 500 })
  }
}

// ─── GET: Latest cycle status ─────────────────────────────────────────────────

export async function GET() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { data: cycles } = await supabase
    .from('heartbeat_cycles')
    .select('*')
    .eq('user_id', user.id)
    .order('started_at', { ascending: false })
    .limit(10)

  const { data: approvals } = await supabase
    .from('autopoietic_approvals')
    .select('*')
    .eq('user_id', user.id)
    .eq('status', 'pending')
    .order('created_at', { ascending: false })
    .limit(5)

  return NextResponse.json({ cycles: cycles ?? [], pendingApprovals: approvals ?? [] })
}
