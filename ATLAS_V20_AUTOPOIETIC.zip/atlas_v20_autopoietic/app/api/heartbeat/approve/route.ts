/**
 * ATLAS v20 — Autopoietic Approval API
 * POST /api/heartbeat/approve
 * God Mode approves or rejects a pending mutation.
 * On approval: promotes lean prompt to production CourtWidget.
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { approvalId, action, mutationId } = await req.json()
  // action: 'approve' | 'reject'

  if (!approvalId || !action) {
    return NextResponse.json({ error: 'approvalId and action required' }, { status: 400 })
  }

  const newStatus = action === 'approve' ? 'approved' : 'rejected'

  const { error } = await supabase
    .from('autopoietic_approvals')
    .update({
      status: newStatus,
      reviewed_at: new Date().toISOString(),
      reviewed_by: user.id,
    })
    .eq('id', approvalId)
    .eq('user_id', user.id)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // On approval: record which prompt version is now "active"
  if (action === 'approve') {
    await supabase.from('active_prompt_config').upsert({
      widget: 'CourtWidget',
      tool: 'court.aiExtract',
      prompt_version: 'v2',
      mutation_id: mutationId,
      activated_at: new Date().toISOString(),
      activated_by: user.id,
    })
  }

  return NextResponse.json({
    success: true,
    status: newStatus,
    message: action === 'approve'
      ? '✅ Mutation approved. Court Widget now uses the optimized prompt.'
      : '❌ Mutation rejected. Original prompt remains active.',
  })
}
