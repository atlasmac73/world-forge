/**
 * ATLAS v20 — Autopoietic GitHub PR Creator
 * When a mutation passes simulation, this module opens a PR on
 * the experiment/meta-singularity branch for God Mode approval.
 */

'use server'

import type { MutationResult } from '@/lib/autopoietic/mutationEngine'

// ─── Types ────────────────────────────────────────────────────────────────────

export interface PRPayload {
  title: string
  body: string
  branch: string
  base: string
  files: PRFile[]
}

export interface PRFile {
  path: string
  content: string
  sha?: string // Required for updates, omit for new files
}

export interface PRResult {
  success: boolean
  prUrl?: string
  prNumber?: number
  error?: string
}

export interface ApprovalCard {
  mutationId: string
  summary: string
  latencyReduction: string
  costReduction: string
  accuracyScore: string
  leanPrompt: string
  prUrl: string
  generatedAt: string
  requiresApproval: boolean
}

// ─── GitHub API helpers ───────────────────────────────────────────────────────

const GITHUB_API = 'https://api.github.com'

function headers() {
  return {
    Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
    'Content-Type': 'application/json',
    'X-GitHub-Api-Version': '2022-11-28',
  }
}

async function getFileSha(
  owner: string,
  repo: string,
  path: string,
  branch: string
): Promise<string | undefined> {
  try {
    const res = await fetch(
      `${GITHUB_API}/repos/${owner}/${repo}/contents/${path}?ref=${branch}`,
      { headers: headers() }
    )
    if (!res.ok) return undefined
    const data = await res.json()
    return data.sha
  } catch {
    return undefined
  }
}

// ─── Ensure experiment branch exists ──────────────────────────────────────────

async function ensureBranch(owner: string, repo: string, branch: string): Promise<void> {
  // Get main SHA
  const mainRef = await fetch(
    `${GITHUB_API}/repos/${owner}/${repo}/git/refs/heads/main`,
    { headers: headers() }
  )
  if (!mainRef.ok) throw new Error('Cannot read main branch ref')

  const { object: { sha } } = await mainRef.json()

  // Create branch (no-op if already exists)
  const createRes = await fetch(
    `${GITHUB_API}/repos/${owner}/${repo}/git/refs`,
    {
      method: 'POST',
      headers: headers(),
      body: JSON.stringify({ ref: `refs/heads/${branch}`, sha }),
    }
  )

  // 422 = branch already exists, which is fine
  if (!createRes.ok && createRes.status !== 422) {
    const err = await createRes.json()
    throw new Error(`Failed to create branch: ${err.message}`)
  }
}

// ─── Commit mutation files to sandbox dir ─────────────────────────────────────

async function commitMutationFiles(
  owner: string,
  repo: string,
  branch: string,
  mutation: MutationResult,
  originalPrompt: string
): Promise<void> {
  const files: PRFile[] = [
    {
      path: `court_widget_mutations/${mutation.mutationId}.json`,
      content: JSON.stringify({
        mutationId: mutation.mutationId,
        generatedAt: mutation.generatedAt,
        originalPrompt,
        leanPrompt: mutation.leanPrompt,
        explanation: mutation.explanation,
        estimatedTokenReduction: mutation.estimatedTokenReduction,
        simulationSummary: {
          totalRuns: mutation.simulationResults.length,
          passed: mutation.passed,
          avgCostUsd: mutation.avgSimCostUsd,
          avgLatencyMs: mutation.avgSimLatencyMs,
        },
      }, null, 2),
    },
    {
      path: `.tmp_sandbox/court_extract_prompt_${mutation.mutationId}.ts`,
      content: `// ATLAS v20 — Autopoietic Mutation\n// Generated: ${mutation.generatedAt}\n// ${mutation.explanation}\n// Token reduction: ~${mutation.estimatedTokenReduction}%\n\nexport const COURT_EXTRACT_PROMPT_CANDIDATE = \`${mutation.leanPrompt}\`\n`,
    },
  ]

  for (const file of files) {
    const sha = await getFileSha(owner, repo, file.path, branch)
    const body: Record<string, unknown> = {
      message: `🤖 autopoietic: write mutation ${mutation.mutationId}`,
      content: Buffer.from(file.content).toString('base64'),
      branch,
    }
    if (sha) body.sha = sha

    const res = await fetch(
      `${GITHUB_API}/repos/${owner}/${repo}/contents/${file.path}`,
      { method: 'PUT', headers: headers(), body: JSON.stringify(body) }
    )

    if (!res.ok) {
      const err = await res.json()
      throw new Error(`Failed to commit ${file.path}: ${err.message}`)
    }
  }
}

// ─── Build the Approval Card (Sixth Portal Inbox message) ─────────────────────

export function buildApprovalCard(
  mutation: MutationResult,
  prUrl: string,
  baselineCostUsd: number,
  baselineLatencyMs: number
): ApprovalCard {
  const costReductionPct = Math.round(
    ((baselineCostUsd - mutation.avgSimCostUsd) / baselineCostUsd) * 100
  )
  const latencyReductionPct = Math.round(
    ((baselineLatencyMs - mutation.avgSimLatencyMs) / baselineLatencyMs) * 100
  )

  return {
    mutationId: mutation.mutationId,
    summary: mutation.explanation,
    latencyReduction: `${latencyReductionPct}% faster (${Math.round(baselineLatencyMs)}ms → ${Math.round(mutation.avgSimLatencyMs)}ms)`,
    costReduction: `${costReductionPct}% cheaper ($${baselineCostUsd.toFixed(5)} → $${mutation.avgSimCostUsd.toFixed(5)} per run)`,
    accuracyScore: `${mutation.simulationResults.filter(r => r.accuracy).length}/${mutation.simulationResults.length} (100% required)`,
    leanPrompt: mutation.leanPrompt,
    prUrl,
    generatedAt: mutation.generatedAt,
    requiresApproval: true,
  }
}

// ─── Master PR Creator ─────────────────────────────────────────────────────────

export async function createMutationPR(
  mutation: MutationResult,
  baselineCostUsd: number,
  baselineLatencyMs: number,
  originalPrompt: string
): Promise<PRResult> {
  const token    = process.env.GITHUB_TOKEN
  const repoFull = process.env.GITHUB_REPO // format: "owner/repo"

  if (!token || !repoFull) {
    return {
      success: false,
      error: 'GITHUB_TOKEN and GITHUB_REPO env vars required',
    }
  }

  const [owner, repo] = repoFull.split('/')
  const branch = 'experiment/meta-singularity'

  try {
    // 1. Ensure branch exists
    await ensureBranch(owner, repo, branch)

    // 2. Commit mutation files to sandbox
    await commitMutationFiles(owner, repo, branch, mutation, originalPrompt)

    // 3. Build PR body
    const costReductionPct = Math.round(
      ((baselineCostUsd - mutation.avgSimCostUsd) / baselineCostUsd) * 100
    )
    const latencyReductionPct = Math.round(
      ((baselineLatencyMs - mutation.avgSimLatencyMs) / baselineLatencyMs) * 100
    )

    const prBody = `## 🤖 Autopoietic Mutation — Court Widget AI Extract

**Mutation ID:** \`${mutation.mutationId}\`
**Generated:** ${mutation.generatedAt}

---

### What changed
${mutation.explanation}

### Performance Delta
| Metric | Baseline | Mutated | Δ |
|--------|---------|---------|---|
| Cost/run | $${baselineCostUsd.toFixed(5)} | $${mutation.avgSimCostUsd.toFixed(5)} | **-${costReductionPct}%** |
| Latency | ${Math.round(baselineLatencyMs)}ms | ${Math.round(mutation.avgSimLatencyMs)}ms | **-${latencyReductionPct}%** |
| Token reduction | — | — | **~${mutation.estimatedTokenReduction}%** |

### Simulation Results
- Total runs: ${mutation.simulationResults.length}
- Accuracy: ${mutation.simulationResults.filter(r => r.accuracy).length}/${mutation.simulationResults.length} ✅

### The Lean Prompt
\`\`\`
${mutation.leanPrompt}
\`\`\`

---

> ⚠️ **Awaiting God Mode approval.** Review in ATLAS → Sixth Portal → Autopoietic Console.
> This PR was autonomously generated by the ATLAS System Heartbeat.`

    // 4. Open PR
    const prRes = await fetch(
      `${GITHUB_API}/repos/${owner}/${repo}/pulls`,
      {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({
          title: `🤖 [Autopoietic] Refactored Court Widget AI Extract — -${costReductionPct}% cost, -${latencyReductionPct}% latency`,
          body: prBody,
          head: branch,
          base: 'main',
          draft: false,
        }),
      }
    )

    if (!prRes.ok) {
      const err = await prRes.json()
      // 422 often means PR already exists
      if (prRes.status === 422) {
        return { success: true, prUrl: `https://github.com/${repoFull}/pulls`, prNumber: 0 }
      }
      throw new Error(err.message)
    }

    const pr = await prRes.json()
    return { success: true, prUrl: pr.html_url, prNumber: pr.number }

  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Unknown GitHub error',
    }
  }
}
