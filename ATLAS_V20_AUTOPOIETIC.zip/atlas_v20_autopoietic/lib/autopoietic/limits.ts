/**
 * ATLAS v20 — Autopoietic Genesis Limits & Kill Switch Config
 * Enforces budget guardrails for the System Heartbeat.
 */

export interface HeartbeatLimits {
  max_per_cycle_usd: number        // Kill switch: halt if cycle cost exceeds this
  auto_refactor_limit: number      // Max mutations allowed before requiring human approval
  alert_threshold: number          // 0-1 fraction of budget that triggers a warning
  simulation_count: number         // Number of simulated runs per mutation test
  latency_trigger_ms: number       // Trigger mutation if avg latency exceeds this
  cost_trigger_usd: number         // Trigger mutation if per-run cost exceeds this
  sandbox_dir: string              // Directory mutations are written to (sandboxed)
  mutation_dir: string             // Directory for court widget mutation history
  target_widget: string            // The widget being self-optimized
}

export const DEFAULT_LIMITS: HeartbeatLimits = {
  max_per_cycle_usd: 5.00,
  auto_refactor_limit: 10,
  alert_threshold: 0.80,
  simulation_count: 100,
  latency_trigger_ms: 2000,
  cost_trigger_usd: 0.10,
  sandbox_dir: '.tmp_sandbox',
  mutation_dir: 'court_widget_mutations',
  target_widget: 'CourtWidget',
}

// USD cost per 1K tokens (Claude claude-sonnet-4-20250514 pricing)
export const CLAUDE_COST_PER_1K_INPUT  = 0.003
export const CLAUDE_COST_PER_1K_OUTPUT = 0.015

export function calculateRunCost(inputTokens: number, outputTokens: number): number {
  return (
    (inputTokens  / 1000) * CLAUDE_COST_PER_1K_INPUT +
    (outputTokens / 1000) * CLAUDE_COST_PER_1K_OUTPUT
  )
}

export function isBudgetExceeded(cycleCostUsd: number, limits: HeartbeatLimits): boolean {
  return cycleCostUsd >= limits.max_per_cycle_usd
}

export function isAlertThresholdMet(cycleCostUsd: number, limits: HeartbeatLimits): boolean {
  return cycleCostUsd >= limits.max_per_cycle_usd * limits.alert_threshold
}
