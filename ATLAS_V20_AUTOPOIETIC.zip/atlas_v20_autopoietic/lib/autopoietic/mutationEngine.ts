/**
 * ATLAS v20 — Autopoietic Mutation Engine
 * Detects inefficient prompts, generates optimized replacements,
 * runs simulated court docket extractions, and scores the mutation.
 */

'use server'

import Anthropic from '@anthropic-ai/sdk'
import {
  calculateRunCost,
  DEFAULT_LIMITS,
  type HeartbeatLimits,
  COURT_EXTRACT_PROMPT_V1,
} from '@/lib/autopoietic/limits'

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MutationInput {
  bloatedPrompt: string
  avgCostUsd: number
  avgLatencyMs: number
  sampleDockets: SampleDocket[]
  limits: HeartbeatLimits
}

export interface MutationResult {
  leanPrompt: string
  explanation: string
  estimatedTokenReduction: number
  simulationResults: SimulationResult[]
  passed: boolean
  avgSimCostUsd: number
  avgSimLatencyMs: number
  mutationId: string
  generatedAt: string
}

export interface SimulationResult {
  run: number
  success: boolean
  latency_ms: number
  cost_usd: number
  accuracy: boolean
  docket?: Record<string, unknown>
}

export interface SampleDocket {
  rawText: string
  expectedCaseType: string
  expectedCounty: string
}

// ─── Synthetic docket corpus for simulations ──────────────────────────────────

export const SIMULATION_CORPUS: SampleDocket[] = [
  {
    rawText: `IN THE CIRCUIT COURT OF KANAWHA COUNTY, WEST VIRGINIA. CIVIL ACTION NO. CV-2024-0847. Plaintiff: First National Mortgage Corp vs. Defendant: Robert and Linda Harmon. Property Address: 1247 Quarrier St, Charleston WV 25301. FORECLOSURE. Filed: November 12, 2024. Amount: $142,500. Auction: February 28, 2025.`,
    expectedCaseType: 'foreclosure',
    expectedCounty: 'Kanawha',
  },
  {
    rawText: `STATE OF WEST VIRGINIA, SHERIFF OF KANAWHA COUNTY. TAX LIEN CERTIFICATE NO. TC-2024-1103. Property Owner: James A. McClung. Address: 842 Bridge Road, South Charleston WV 25303. Delinquent Amount: $8,740.00. Filed September 3, 2024. Status: Pending redemption.`,
    expectedCaseType: 'tax_lien',
    expectedCounty: 'Kanawha',
  },
  {
    rawText: `IN THE CIRCUIT COURT OF KANAWHA COUNTY. PROBATE CASE PR-2024-0291. In the Matter of the Estate of Dorothy M. Simmons, deceased. Real Property: 304 Oakwood Road, Dunbar WV 25064. Petition filed June 18, 2024. Status: Active administration.`,
    expectedCaseType: 'probate',
    expectedCounty: 'Kanawha',
  },
  {
    rawText: `KANAWHA COUNTY CIRCUIT COURT. FAMILY COURT CASE FC-2024-0518. IN RE: Marriage of Timothy R. and Sarah L. Adkins. Marital property at 673 Virginia St E, Charleston WV 25301. Divorce petition filed March 22, 2024. Joint assets under review.`,
    expectedCaseType: 'divorce',
    expectedCounty: 'Kanawha',
  },
  {
    rawText: `UNITED STATES BANKRUPTCY COURT, SOUTHERN DISTRICT OF WEST VIRGINIA. Case No. BK-2024-03847. Debtor: Michael W. Carpenter. Property of estate: 91 Norwood Road, Charleston WV 25301. Chapter 7 petition filed August 7, 2024. Status: Active proceedings.`,
    expectedCaseType: 'bankruptcy',
    expectedCounty: 'Kanawha',
  },
]

// ─── Step 1: Generate a leaner prompt ─────────────────────────────────────────

export async function generateMutatedPrompt(
  bloatedPrompt: string,
  avgCostUsd: number,
  avgLatencyMs: number
): Promise<{ leanPrompt: string; explanation: string; estimatedTokenReduction: number }> {
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

  const metaPrompt = `You are a prompt optimization engineer. You have been given an inefficient, bloated LLM prompt that is being used to extract structured court docket data from raw text. The prompt is costing $${avgCostUsd.toFixed(4)} per run with ${avgLatencyMs}ms average latency — both above acceptable thresholds.

Your task: Rewrite the prompt to be maximally concise while preserving 100% accuracy. Strip all redundancy, verbosity, and repetition. The optimized prompt must still produce identical JSON output.

ORIGINAL BLOATED PROMPT:
---
${bloatedPrompt}
---

Respond ONLY with valid JSON in this exact format:
{
  "lean_prompt": "the optimized prompt text",
  "explanation": "one sentence describing what you removed and why",
  "estimated_token_reduction_pct": 65
}`

  const response = await client.messages.create({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1000,
    messages: [{ role: 'user', content: metaPrompt }],
  })

  const text = response.content.find(b => b.type === 'text')?.text ?? '{}'
  const clean = text.replace(/```json|```/g, '').trim()
  const parsed = JSON.parse(clean)

  return {
    leanPrompt: parsed.lean_prompt,
    explanation: parsed.explanation,
    estimatedTokenReduction: parsed.estimated_token_reduction_pct ?? 0,
  }
}

// ─── Step 2: Simulate N extractions with the lean prompt ──────────────────────

export async function runSimulations(
  leanPrompt: string,
  count: number,
  limits: HeartbeatLimits
): Promise<SimulationResult[]> {
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
  const results: SimulationResult[] = []

  // Cycle through the corpus for simulations
  for (let i = 0; i < count; i++) {
    const sample = SIMULATION_CORPUS[i % SIMULATION_CORPUS.length]
    const start = Date.now()

    try {
      const response = await client.messages.create({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 400,
        messages: [{
          role: 'user',
          content: leanPrompt + '\n' + sample.rawText,
        }],
      })

      const latency_ms = Date.now() - start
      const text = response.content.find(b => b.type === 'text')?.text ?? '{}'
      const docket = JSON.parse(text.replace(/```json|```/g, '').trim())

      const cost_usd = calculateRunCost(
        response.usage.input_tokens,
        response.usage.output_tokens
      )

      // Accuracy check: verify key fields match expectations
      const accuracy =
        docket.case_type === sample.expectedCaseType &&
        docket.county?.toLowerCase().includes(sample.expectedCounty.toLowerCase())

      results.push({
        run: i + 1,
        success: true,
        latency_ms,
        cost_usd,
        accuracy,
        docket,
      })

      // Respect rate limits — don't hammer the API in simulations
      // For a real heartbeat, use batch API instead
      if (i < count - 1) await new Promise(r => setTimeout(r, 200))

    } catch (err) {
      results.push({
        run: i + 1,
        success: false,
        latency_ms: Date.now() - start,
        cost_usd: 0,
        accuracy: false,
      })
    }
  }

  return results
}

// ─── Step 3: Score the simulation results ─────────────────────────────────────

export function scoreMutation(
  results: SimulationResult[],
  limits: HeartbeatLimits
): { passed: boolean; avgCostUsd: number; avgLatencyMs: number; accuracyPct: number } {
  const successful = results.filter(r => r.success)
  const accurate = results.filter(r => r.accuracy)

  const avgCostUsd = successful.length > 0
    ? successful.reduce((s, r) => s + r.cost_usd, 0) / successful.length
    : 999

  const avgLatencyMs = successful.length > 0
    ? successful.reduce((s, r) => s + r.latency_ms, 0) / successful.length
    : 999

  const accuracyPct = (accurate.length / results.length) * 100

  const passed =
    accuracyPct === 100 &&
    avgCostUsd <= limits.cost_trigger_usd / 2 &&  // Must be at least 50% cheaper
    avgLatencyMs <= limits.latency_trigger_ms / 2 // Must be at least 50% faster

  return { passed, avgCostUsd, avgLatencyMs, accuracyPct }
}

// ─── Master Mutation Cycle ─────────────────────────────────────────────────────

export async function runMutationCycle(input: MutationInput): Promise<MutationResult> {
  const mutationId = `mutation_${Date.now()}`

  // 1. Generate lean prompt
  const { leanPrompt, explanation, estimatedTokenReduction } = await generateMutatedPrompt(
    input.bloatedPrompt,
    input.avgCostUsd,
    input.avgLatencyMs
  )

  // 2. Run simulations (capped for cost control; full 100 in prod)
  const simCount = Math.min(input.limits.simulation_count, 10) // 10 in dev, 100 in prod
  const simulationResults = await runSimulations(leanPrompt, simCount, input.limits)

  // 3. Score
  const { passed, avgCostUsd, avgLatencyMs } = scoreMutation(simulationResults, input.limits)

  return {
    leanPrompt,
    explanation,
    estimatedTokenReduction,
    simulationResults,
    passed,
    avgSimCostUsd: avgCostUsd,
    avgSimLatencyMs: avgLatencyMs,
    mutationId,
    generatedAt: new Date().toISOString(),
  }
}
