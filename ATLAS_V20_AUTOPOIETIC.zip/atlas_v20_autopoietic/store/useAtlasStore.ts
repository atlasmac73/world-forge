/**
 * ATLAS v20 — Unified Zustand Store
 * Single source of truth. Eliminates all global state collisions from v19 prototype.
 * Replaces: const state = {}, const SaasState = {}, window globals.
 */

import { create } from 'zustand'
import { persist, devtools } from 'zustand/middleware'

// ─── Types ────────────────────────────────────────────────────────────────────

export type Portal =
  | 'dashboard'
  | 'deal-navigator'
  | 'comms-hub'
  | 'market-intel'
  | 'agent-lab'
  | 'sp6-wallet'
  | 'settings'
  | 'swarm-nexus'
  | 'war-room'
  | 'voice-agent'
  | 'signal-stack'

export type ModalType =
  | 'api-key'
  | 'neural-call'
  | 'stripe-checkout'
  | 'property-detail'
  | 'lead-detail'
  | 'agent-run'
  | null

export type AgentStatus = 'idle' | 'running' | 'completed' | 'failed'

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: number
  toolCalls?: ToolCall[]
}

export interface ToolCall {
  id: string
  name: string
  input: Record<string, unknown>
  output?: string
  status: 'pending' | 'success' | 'error'
}

export interface Property {
  id: string
  address: string
  city: string
  state: string
  zip: string
  equity_pct: number
  arv: number
  asking_price?: number
  status: 'hot' | 'warm' | 'cold' | 'closed'
  tax_delinquent: boolean
  owner_name?: string
  created_at: string
}

export interface Lead {
  id: string
  name: string
  phone?: string
  email?: string
  property_id?: string
  status: 'new' | 'contacted' | 'negotiating' | 'closed' | 'dead'
  touch_sequence: number
  last_contact?: string
  created_at: string
}

export interface AgentRun {
  id: string
  agent_type: 'investigator' | 'underwriter' | 'copywriter' | 'orchestrator'
  status: AgentStatus
  input: string
  output?: string
  tokens_used?: number
  credits_consumed?: number
  created_at: string
  completed_at?: string
}

export interface SP6Wallet {
  balance: number
  credits_used_today: number
  credits_limit_daily: number
  plan: 'free' | 'pro' | 'enterprise'
  stripe_customer_id?: string
}

export interface ApiKeys {
  anthropic: string
  mapbox: string
  twilio_sid: string
  twilio_token: string
  supabase_url: string
  supabase_key: string
}

// ─── Store Interface ───────────────────────────────────────────────────────────

interface AtlasStore {
  // ── Navigation ──
  activePortal: Portal
  setActivePortal: (portal: Portal) => void

  // ── Modals ──
  activeModal: ModalType
  modalData: Record<string, unknown>
  openModal: (modal: ModalType, data?: Record<string, unknown>) => void
  closeModal: () => void

  // ── Copilot / Chat ──
  messages: ChatMessage[]
  isStreaming: boolean
  addMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void
  updateLastMessage: (content: string) => void
  clearMessages: () => void
  setStreaming: (v: boolean) => void

  // ── Properties ──
  properties: Property[]
  selectedProperty: Property | null
  setProperties: (properties: Property[]) => void
  setSelectedProperty: (property: Property | null) => void
  addProperty: (property: Property) => void

  // ── Leads ──
  leads: Lead[]
  selectedLead: Lead | null
  setLeads: (leads: Lead[]) => void
  setSelectedLead: (lead: Lead | null) => void
  addLead: (lead: Lead) => void
  updateLeadStatus: (id: string, status: Lead['status']) => void

  // ── Agent Runs ──
  agentRuns: AgentRun[]
  activeRun: AgentRun | null
  setAgentRuns: (runs: AgentRun[]) => void
  addAgentRun: (run: AgentRun) => void
  updateAgentRun: (id: string, updates: Partial<AgentRun>) => void
  setActiveRun: (run: AgentRun | null) => void

  // ── SP6 Wallet / Billing Gate ──
  wallet: SP6Wallet
  updateWallet: (updates: Partial<SP6Wallet>) => void
  consumeCredits: (amount: number) => boolean // returns false if limit hit

  // ── API Keys ──
  apiKeys: Partial<ApiKeys>
  setApiKey: (key: keyof ApiKeys, value: string) => void
  hasRequiredKeys: () => boolean

  // ── App State ──
  safeMode: boolean
  offlineMode: boolean
  isInitialized: boolean
  setSafeMode: (v: boolean) => void
  setOfflineMode: (v: boolean) => void
  setInitialized: (v: boolean) => void

  // ── Map ──
  mapCenter: [number, number]
  mapZoom: number
  setMapCenter: (coords: [number, number]) => void
  setMapZoom: (zoom: number) => void

  // ── Search / Filters ──
  propertyFilters: {
    minEquity: number
    taxDelinquent: boolean
    status: Property['status'] | 'all'
    zipCode: string
  }
  setPropertyFilter: <K extends keyof AtlasStore['propertyFilters']>(
    key: K,
    value: AtlasStore['propertyFilters'][K]
  ) => void
}

// ─── Store Implementation ──────────────────────────────────────────────────────

export const useAtlasStore = create<AtlasStore>()(
  devtools(
    persist(
      (set, get) => ({
        // ── Navigation ──
        activePortal: 'dashboard',
        setActivePortal: (portal) => set({ activePortal: portal }),

        // ── Modals ──
        activeModal: null,
        modalData: {},
        openModal: (modal, data = {}) => set({ activeModal: modal, modalData: data }),
        closeModal: () => set({ activeModal: null, modalData: {} }),

        // ── Copilot / Chat ──
        messages: [],
        isStreaming: false,
        addMessage: (message) =>
          set((state) => ({
            messages: [
              ...state.messages,
              { ...message, id: crypto.randomUUID(), timestamp: Date.now() },
            ],
          })),
        updateLastMessage: (content) =>
          set((state) => {
            const msgs = [...state.messages]
            if (msgs.length > 0) msgs[msgs.length - 1].content = content
            return { messages: msgs }
          }),
        clearMessages: () => set({ messages: [] }),
        setStreaming: (v) => set({ isStreaming: v }),

        // ── Properties ──
        properties: [],
        selectedProperty: null,
        setProperties: (properties) => set({ properties }),
        setSelectedProperty: (property) => set({ selectedProperty: property }),
        addProperty: (property) =>
          set((state) => ({ properties: [property, ...state.properties] })),

        // ── Leads ──
        leads: [],
        selectedLead: null,
        setLeads: (leads) => set({ leads }),
        setSelectedLead: (lead) => set({ selectedLead: lead }),
        addLead: (lead) =>
          set((state) => ({ leads: [lead, ...state.leads] })),
        updateLeadStatus: (id, status) =>
          set((state) => ({
            leads: state.leads.map((l) => (l.id === id ? { ...l, status } : l)),
          })),

        // ── Agent Runs ──
        agentRuns: [],
        activeRun: null,
        setAgentRuns: (runs) => set({ agentRuns: runs }),
        addAgentRun: (run) =>
          set((state) => ({ agentRuns: [run, ...state.agentRuns] })),
        updateAgentRun: (id, updates) =>
          set((state) => ({
            agentRuns: state.agentRuns.map((r) =>
              r.id === id ? { ...r, ...updates } : r
            ),
          })),
        setActiveRun: (run) => set({ activeRun: run }),

        // ── SP6 Wallet / Billing Gate ──
        wallet: {
          balance: 0,
          credits_used_today: 0,
          credits_limit_daily: 100,
          plan: 'free',
        },
        updateWallet: (updates) =>
          set((state) => ({ wallet: { ...state.wallet, ...updates } })),
        consumeCredits: (amount) => {
          const { wallet } = get()
          if (wallet.credits_used_today + amount > wallet.credits_limit_daily) {
            return false // Billing gate: block action
          }
          set((state) => ({
            wallet: {
              ...state.wallet,
              credits_used_today: state.wallet.credits_used_today + amount,
            },
          }))
          return true
        },

        // ── API Keys ──
        apiKeys: {},
        setApiKey: (key, value) =>
          set((state) => ({ apiKeys: { ...state.apiKeys, [key]: value } })),
        hasRequiredKeys: () => {
          const { apiKeys } = get()
          return !!(apiKeys.anthropic && apiKeys.supabase_url && apiKeys.supabase_key)
        },

        // ── App State ──
        safeMode: false,
        offlineMode: false,
        isInitialized: false,
        setSafeMode: (v) => set({ safeMode: v }),
        setOfflineMode: (v) => set({ offlineMode: v }),
        setInitialized: (v) => set({ isInitialized: v }),

        // ── Map ──
        mapCenter: [-81.6326, 38.3498], // Charleston, WV
        mapZoom: 11,
        setMapCenter: (coords) => set({ mapCenter: coords }),
        setMapZoom: (zoom) => set({ mapZoom: zoom }),

        // ── Filters ──
        propertyFilters: {
          minEquity: 30,
          taxDelinquent: false,
          status: 'all',
          zipCode: '',
        },
        setPropertyFilter: (key, value) =>
          set((state) => ({
            propertyFilters: { ...state.propertyFilters, [key]: value },
          })),
      }),
      {
        name: 'atlas-v20-store',
        partialize: (state) => ({
          apiKeys: state.apiKeys,
          safeMode: state.safeMode,
          wallet: state.wallet,
          activePortal: state.activePortal,
          mapCenter: state.mapCenter,
          mapZoom: state.mapZoom,
          propertyFilters: state.propertyFilters,
        }),
      }
    ),
    { name: 'ATLAS v20' }
  )
)
