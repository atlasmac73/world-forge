/**
 * ATLAS v20 — Autopoietic Genesis Console
 * Sixth Portal component — God Mode visibility into the System Heartbeat.
 * Shows live cycle status, mutation history, and pending approvals.
 */

'use client'

import { useState, useEffect, useCallback } from 'react'
import {
  Activity, Zap, GitPullRequest, CheckCircle, XCircle,
  AlertTriangle, Clock, DollarSign, RefreshCw, Play,
  ChevronDown, ChevronRight, Shield, Terminal
} from 'lucide-react'

// ─── Types ────────────────────────────────────────────────────────────────────

interface HeartbeatLog {
  timestamp: string
  node: string
  message: string
  level: 'info' | 'warn' | 'error' | 'success'
}

interface ApprovalCard {
  mutationId: string
  summary: string
  latencyReduction: string
  costReduction: string
  accuracyScore: string
  leanPrompt: string
  prUrl: string
  generatedAt: string
}

interface HeartbeatCycle {
  id: string
  status: string
  startedAt: string
  completedAt?: string
  totalCostUsd: number
  prUrl?: string
  killReason?: string
  logs: HeartbeatLog[]
  metrics?: {
    avgApiLatencyMs: number
    avgTokenCostUsd: number
    totalRunsAnalyzed: number
    mutationTriggered: boolean
    triggerReason?: string
  }
}

interface PendingApproval {
  id: string
  mutation_id: string
  approval_card: ApprovalCard
  pr_url?: string
  created_at: string
}

// ─── Status badge ─────────────────────────────────────────────────────────────

const STATUS_STYLES: Record<string, string> = {
  idle:       'bg-slate-700 text-slate-300 border-slate-600',
  gathering:  'bg-blue-500/20 text-blue-300 border-blue-500/30',
  analyzing:  'bg-purple-500/20 text-purple-300 border-purple-500/30',
  mutating:   'bg-amber-500/20 text-amber-300 border-amber-500/30',
  simulating: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
  proposing:  'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
  completed:  'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  killed:     'bg-red-500/20 text-red-300 border-red-500/30',
  error:      'bg-red-500/20 text-red-300 border-red-500/30',
  running:    'bg-amber-500/20 text-amber-300 border-amber-500/30',
}

const LOG_COLORS: Record<string, string> = {
  info:    'text-slate-400',
  warn:    'text-amber-400',
  error:   'text-red-400',
  success: 'text-emerald-400',
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function AutopoieticConsole() {
  const [cycles, setCycles] = useState<HeartbeatCycle[]>([])
  const [pendingApprovals, setPendingApprovals] = useState<PendingApproval[]>([])
  const [isRunning, setIsRunning] = useState(false)
  const [liveCycle, setLiveCycle] = useState<HeartbeatCycle | null>(null)
  const [expandedCycle, setExpandedCycle] = useState<string | null>(null)
  const [expandedApproval, setExpandedApproval] = useState<string | null>(null)
  const [approvalAction, setApprovalAction] = useState<Record<string, 'approving' | 'rejecting' | null>>({})

  // ── Fetch status ────────────────────────────────────────────────────────────
  const fetchStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/heartbeat')
      if (!res.ok) return
      const data = await res.json()
      setCycles(data.cycles ?? [])
      setPendingApprovals(data.pendingApprovals ?? [])
    } catch { /* ignore */ }
  }, [])

  useEffect(() => {
    fetchStatus()
    const interval = setInterval(fetchStatus, 15_000) // Poll every 15s
    return () => clearInterval(interval)
  }, [fetchStatus])

  // ── Manual trigger ──────────────────────────────────────────────────────────
  const triggerHeartbeat = useCallback(async () => {
    setIsRunning(true)
    setLiveCycle({
      id: 'live',
      status: 'gathering',
      startedAt: new Date().toISOString(),
      totalCostUsd: 0,
      logs: [{ timestamp: new Date().toISOString(), node: 'Trigger', message: '💓 Manual heartbeat triggered from God Mode', level: 'info' }],
    })

    try {
      const res = await fetch('/api/heartbeat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      })
      const data = await res.json()
      if (data.cycle) setLiveCycle(data.cycle)
      await fetchStatus()
    } catch (err) {
      setLiveCycle(prev => prev ? {
        ...prev,
        status: 'error',
        logs: [...prev.logs, { timestamp: new Date().toISOString(), node: 'Error', message: String(err), level: 'error' }]
      } : null)
    } finally {
      setIsRunning(false)
    }
  }, [fetchStatus])

  // ── Approval action ─────────────────────────────────────────────────────────
  const handleApproval = useCallback(async (approval: PendingApproval, action: 'approve' | 'reject') => {
    setApprovalAction(prev => ({ ...prev, [approval.id]: action === 'approve' ? 'approving' : 'rejecting' }))

    try {
      await fetch('/api/heartbeat/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          approvalId: approval.id,
          action,
          mutationId: approval.mutation_id,
        }),
      })
      await fetchStatus()
    } finally {
      setApprovalAction(prev => ({ ...prev, [approval.id]: null }))
    }
  }, [fetchStatus])

  const lastCycle = liveCycle ?? cycles[0]

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-400" />
            Autopoietic Genesis Console
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">System Heartbeat · Self-Evolving Architecture · Experiment Branch: meta-singularity</p>
        </div>
        <button
          onClick={triggerHeartbeat}
          disabled={isRunning}
          className="flex items-center gap-2 px-3 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-sm rounded-lg disabled:opacity-50 transition-colors"
        >
          {isRunning
            ? <><RefreshCw className="w-4 h-4 animate-spin" /> Running…</>
            : <><Play className="w-4 h-4" /> Trigger Heartbeat</>}
        </button>
      </div>

      {/* Live Status Strip */}
      {lastCycle && (
        <div className="bg-slate-900 border border-slate-700 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className={`text-xs px-2 py-1 rounded border font-mono ${STATUS_STYLES[lastCycle.status] ?? STATUS_STYLES.idle}`}>
                {lastCycle.status.toUpperCase()}
              </div>
              <span className="text-xs text-slate-400 font-mono">{lastCycle.id}</span>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <DollarSign className="w-3 h-3" />
                ${lastCycle.totalCostUsd.toFixed(5)}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {lastCycle.startedAt ? new Date(lastCycle.startedAt).toLocaleTimeString() : '—'}
              </span>
            </div>
          </div>

          {/* Metrics */}
          {lastCycle.metrics && (
            <div className="grid grid-cols-3 gap-2 mb-3">
              <div className="bg-slate-800 rounded-lg p-2 text-center">
                <div className="text-lg font-bold text-white">{Math.round(lastCycle.metrics.avgApiLatencyMs)}ms</div>
                <div className="text-xs text-slate-400">Avg Latency</div>
              </div>
              <div className="bg-slate-800 rounded-lg p-2 text-center">
                <div className={`text-lg font-bold ${lastCycle.metrics.avgTokenCostUsd > 0.10 ? 'text-red-400' : 'text-emerald-400'}`}>
                  ${lastCycle.metrics.avgTokenCostUsd.toFixed(4)}
                </div>
                <div className="text-xs text-slate-400">Avg Cost/Run</div>
              </div>
              <div className="bg-slate-800 rounded-lg p-2 text-center">
                <div className="text-lg font-bold text-white">{lastCycle.metrics.totalRunsAnalyzed}</div>
                <div className="text-xs text-slate-400">Runs Analyzed</div>
              </div>
            </div>
          )}

          {/* Kill reason */}
          {lastCycle.killReason && (
            <div className="flex items-center gap-2 text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2 mb-3">
              <AlertTriangle className="w-3 h-3 shrink-0" />
              Kill Switch: {lastCycle.killReason}
            </div>
          )}

          {/* PR link */}
          {lastCycle.prUrl && (
            <a
              href={lastCycle.prUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-xs text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 rounded-lg px-3 py-2 mb-3 transition-colors"
            >
              <GitPullRequest className="w-3 h-3" />
              PR opened on experiment/meta-singularity →
            </a>
          )}

          {/* Logs */}
          <div className="bg-slate-950 rounded-lg p-3 font-mono text-xs space-y-0.5 max-h-48 overflow-y-auto">
            {lastCycle.logs.length === 0
              ? <div className="text-slate-600">No logs yet…</div>
              : lastCycle.logs.map((l, i) => (
                  <div key={i} className="flex gap-2">
                    <span className="text-slate-600 shrink-0">{new Date(l.timestamp).toLocaleTimeString()}</span>
                    <span className="text-slate-500 shrink-0">[{l.node}]</span>
                    <span className={LOG_COLORS[l.level]}>{l.message}</span>
                  </div>
                ))}
          </div>
        </div>
      )}

      {/* Pending Approvals */}
      {pendingApprovals.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-amber-300">
            <Shield className="w-4 h-4" />
            Pending God Mode Approvals ({pendingApprovals.length})
          </div>
          {pendingApprovals.map(approval => (
            <div key={approval.id} className="bg-slate-900 border border-amber-500/30 rounded-xl overflow-hidden">
              <div
                className="flex items-center justify-between px-4 py-3 cursor-pointer hover:bg-slate-800/50"
                onClick={() => setExpandedApproval(expandedApproval === approval.id ? null : approval.id)}
              >
                <div>
                  <div className="text-sm font-medium text-white">{approval.approval_card.summary}</div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {approval.approval_card.costReduction} · {approval.approval_card.latencyReduction}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {expandedApproval === approval.id
                    ? <ChevronDown className="w-4 h-4 text-slate-400" />
                    : <ChevronRight className="w-4 h-4 text-slate-400" />}
                </div>
              </div>

              {expandedApproval === approval.id && (
                <div className="px-4 pb-4 space-y-3 border-t border-amber-500/20">
                  <div className="grid grid-cols-3 gap-2 pt-3 text-xs">
                    <div className="bg-slate-800 rounded p-2">
                      <div className="text-emerald-400 font-medium">{approval.approval_card.costReduction}</div>
                      <div className="text-slate-500">Cost Reduction</div>
                    </div>
                    <div className="bg-slate-800 rounded p-2">
                      <div className="text-blue-400 font-medium">{approval.approval_card.latencyReduction}</div>
                      <div className="text-slate-500">Latency</div>
                    </div>
                    <div className="bg-slate-800 rounded p-2">
                      <div className="text-amber-400 font-medium">{approval.approval_card.accuracyScore}</div>
                      <div className="text-slate-500">Accuracy</div>
                    </div>
                  </div>

                  <div>
                    <div className="text-xs text-slate-400 mb-1 flex items-center gap-1">
                      <Terminal className="w-3 h-3" />
                      Lean Prompt (v2)
                    </div>
                    <pre className="bg-slate-950 rounded p-3 text-xs text-slate-300 overflow-auto max-h-32 whitespace-pre-wrap">
                      {approval.approval_card.leanPrompt}
                    </pre>
                  </div>

                  {approval.pr_url && (
                    <a
                      href={approval.pr_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-xs text-indigo-400 hover:text-indigo-300"
                    >
                      <GitPullRequest className="w-3 h-3" />
                      View PR on GitHub →
                    </a>
                  )}

                  <div className="flex gap-2">
                    <button
                      onClick={() => handleApproval(approval, 'approve')}
                      disabled={!!approvalAction[approval.id]}
                      className="flex-1 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-sm rounded-lg flex items-center justify-center gap-1 disabled:opacity-50 transition-colors"
                    >
                      <CheckCircle className="w-4 h-4" />
                      {approvalAction[approval.id] === 'approving' ? 'Approving…' : 'Approve Mutation'}
                    </button>
                    <button
                      onClick={() => handleApproval(approval, 'reject')}
                      disabled={!!approvalAction[approval.id]}
                      className="flex-1 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 text-sm rounded-lg flex items-center justify-center gap-1 disabled:opacity-50 transition-colors"
                    >
                      <XCircle className="w-4 h-4" />
                      {approvalAction[approval.id] === 'rejecting' ? 'Rejecting…' : 'Reject'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Cycle History */}
      {cycles.length > 0 && (
        <div className="space-y-2">
          <div className="text-sm font-semibold text-slate-300">Cycle History</div>
          {cycles.map(cycle => (
            <div
              key={cycle.id}
              className="bg-slate-900 border border-slate-700 rounded-lg overflow-hidden"
            >
              <div
                className="flex items-center justify-between px-3 py-2 cursor-pointer hover:bg-slate-800/30"
                onClick={() => setExpandedCycle(expandedCycle === cycle.id ? null : cycle.id)}
              >
                <div className="flex items-center gap-2">
                  <div className={`text-xs px-1.5 py-0.5 rounded border ${STATUS_STYLES[cycle.status] ?? STATUS_STYLES.idle}`}>
                    {cycle.status}
                  </div>
                  <span className="text-xs text-slate-400 font-mono">{cycle.id}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span>${cycle.totalCostUsd.toFixed(5)}</span>
                  {cycle.prUrl && <GitPullRequest className="w-3 h-3 text-indigo-400" />}
                  {expandedCycle === cycle.id ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                </div>
              </div>
              {expandedCycle === cycle.id && (
                <div className="px-3 pb-3 border-t border-slate-700">
                  <div className="bg-slate-950 rounded mt-2 p-2 font-mono text-xs space-y-0.5 max-h-32 overflow-y-auto">
                    {cycle.logs?.map((l, i) => (
                      <div key={i} className="flex gap-2">
                        <span className="text-slate-600 shrink-0">{new Date(l.timestamp).toLocaleTimeString()}</span>
                        <span className={LOG_COLORS[l.level]}>{l.message}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Empty state */}
      {!lastCycle && pendingApprovals.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <Activity className="w-12 h-12 text-slate-600 mb-3" />
          <div className="text-slate-400 text-sm">No heartbeat cycles yet.</div>
          <div className="text-slate-600 text-xs mt-1">Trigger manually or wait for the 15-minute cron.</div>
        </div>
      )}
    </div>
  )
}
