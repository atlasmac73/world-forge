'use client'

import { useAtlasStore, type Portal } from '@/store/useAtlasStore'
import { LayoutDashboard, Map, MessageSquare, BarChart3, Bot, Wallet, Settings, Zap, Target, Radio, Phone } from 'lucide-react'
import { clsx } from 'clsx'

const NAV_ITEMS: { id: Portal; label: string; icon: React.ReactNode; badge?: string }[] = [
  { id: 'dashboard',      label: 'Dashboard',     icon: <LayoutDashboard size={18} /> },
  { id: 'deal-navigator', label: 'Deal Navigator', icon: <Map size={18} />,           badge: 'AI' },
  { id: 'comms-hub',      label: 'Comms Hub',      icon: <MessageSquare size={18} />, badge: 'SMS' },
  { id: 'market-intel',   label: 'Market Intel',   icon: <BarChart3 size={18} /> },
  { id: 'agent-lab',      label: 'Agent Lab',      icon: <Bot size={18} />,           badge: 'NEW' },
  { id: 'swarm-nexus',    label: 'Swarm Nexus',    icon: <Zap size={18} />,           badge: '🔥' },
  { id: 'signal-stack',   label: 'Signal Stack',   icon: <Target size={18} /> },
  { id: 'war-room',       label: 'War Room',       icon: <Radio size={18} />,         badge: 'LIVE' },
  { id: 'voice-agent',    label: 'Voice Agent',    icon: <Phone size={18} /> },
  { id: 'sp6-wallet',     label: 'SP6 Wallet',     icon: <Wallet size={18} /> },
  { id: 'settings',       label: 'Settings',       icon: <Settings size={18} /> },
]

export function Sidebar() {
  const { activePortal, setActivePortal, wallet, safeMode } = useAtlasStore()

  return (
    <aside className="w-56 flex flex-col bg-atlas-panel border-r border-atlas-border h-screen shrink-0">
      {/* Logo */}
      <div className="p-4 border-b border-atlas-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-atlas-accent to-atlas-purple flex items-center justify-center glow-accent">
            <Zap size={16} className="text-white" />
          </div>
          <div>
            <div className="font-bold text-white text-sm leading-tight">ATLAS</div>
            <div className="text-[10px] text-atlas-muted font-mono">v20.0 GodMode</div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActivePortal(item.id)}
            className={clsx(
              'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-150 text-left',
              activePortal === item.id
                ? 'bg-atlas-accent/10 text-atlas-accent border border-atlas-accent/30'
                : 'text-atlas-muted hover:bg-white/5 hover:text-atlas-text'
            )}
          >
            <span className={activePortal === item.id ? 'text-atlas-accent' : ''}>{item.icon}</span>
            <span className="flex-1">{item.label}</span>
            {item.badge && (
              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-atlas-accent/20 text-atlas-accent">
                {item.badge}
              </span>
            )}
          </button>
        ))}
      </nav>

      {/* Wallet Status */}
      <div className="p-3 border-t border-atlas-border">
        <div className="atlas-panel p-2 rounded space-y-1">
          <div className="flex justify-between text-[11px]">
            <span className="text-atlas-muted">Credits Today</span>
            <span className="text-atlas-accent font-mono">
              {wallet.credits_used_today}/{wallet.credits_limit_daily}
            </span>
          </div>
          <div className="w-full bg-atlas-border rounded-full h-1">
            <div
              className="h-1 rounded-full bg-gradient-to-r from-atlas-accent to-atlas-purple transition-all"
              style={{ width: `${(wallet.credits_used_today / wallet.credits_limit_daily) * 100}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px]">
            <span className={clsx('px-1.5 py-0.5 rounded text-[9px] font-bold uppercase',
              wallet.plan === 'enterprise' ? 'bg-atlas-gold/20 text-atlas-gold' :
              wallet.plan === 'pro' ? 'bg-atlas-purple/20 text-atlas-purple' :
              'bg-atlas-muted/20 text-atlas-muted'
            )}>
              {wallet.plan}
            </span>
            {safeMode && <span className="text-atlas-gold text-[9px]">⚡ SAFE</span>}
          </div>
        </div>
      </div>
    </aside>
  )
}
