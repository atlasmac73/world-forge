-- ============================================================
-- ATLAS v20 — Supabase Schema + Row Level Security
-- Run this in your Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── PROPERTIES ───────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS properties (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  address         TEXT NOT NULL,
  city            TEXT NOT NULL DEFAULT 'Charleston',
  state           TEXT NOT NULL DEFAULT 'WV',
  zip             TEXT,
  equity_pct      NUMERIC(5,2),
  arv             NUMERIC(12,2),
  asking_price    NUMERIC(12,2),
  assessed_value  NUMERIC(12,2),
  status          TEXT NOT NULL DEFAULT 'warm' CHECK (status IN ('hot','warm','cold','closed')),
  tax_delinquent  BOOLEAN NOT NULL DEFAULT FALSE,
  tax_owed        NUMERIC(10,2),
  owner_name      TEXT,
  owner_phone     TEXT,
  owner_email     TEXT,
  distress_score  INTEGER CHECK (distress_score BETWEEN 0 AND 100),
  deal_grade      TEXT CHECK (deal_grade IN ('A','B','C','D','F')),
  notes           TEXT,
  dossier_json    JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own properties" ON properties
  FOR ALL USING (auth.uid() = user_id);

-- ─── LEADS ────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS leads (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  property_id     UUID REFERENCES properties(id) ON DELETE SET NULL,
  name            TEXT NOT NULL,
  phone           TEXT,
  email           TEXT,
  status          TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','contacted','negotiating','closed','dead')),
  touch_sequence  INTEGER NOT NULL DEFAULT 0,
  last_contact    TIMESTAMPTZ,
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own leads" ON leads
  FOR ALL USING (auth.uid() = user_id);

-- ─── AGENT RUNS ───────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS agent_runs (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id           UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  session_id        TEXT,
  tool_name         TEXT NOT NULL,
  agent_type        TEXT,
  status            TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running','completed','failed')),
  input             JSONB,
  output            JSONB,
  error             TEXT,
  credits_reserved  INTEGER DEFAULT 0,
  credits_consumed  INTEGER DEFAULT 0,
  tokens_used       INTEGER DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at      TIMESTAMPTZ
);

ALTER TABLE agent_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own agent runs" ON agent_runs
  FOR ALL USING (auth.uid() = user_id);

-- ─── SP6 USER WALLETS ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS sp6_user_wallets (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id               UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  balance               NUMERIC(10,2) NOT NULL DEFAULT 0,
  credits_used_today    INTEGER NOT NULL DEFAULT 0,
  credits_limit_daily   INTEGER NOT NULL DEFAULT 100,
  plan                  TEXT NOT NULL DEFAULT 'free' CHECK (plan IN ('free','pro','enterprise')),
  stripe_customer_id    TEXT,
  stripe_subscription_id TEXT,
  last_reset_date       DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE sp6_user_wallets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own wallet" ON sp6_user_wallets
  FOR ALL USING (auth.uid() = user_id);

-- ─── AUTO-CREATE WALLET ON SIGNUP ─────────────────────────────

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO sp6_user_wallets (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ─── RESET DAILY CREDITS (call via cron) ──────────────────────

CREATE OR REPLACE FUNCTION reset_daily_credits()
RETURNS void AS $$
BEGIN
  UPDATE sp6_user_wallets
  SET credits_used_today = 0,
      last_reset_date = CURRENT_DATE
  WHERE last_reset_date < CURRENT_DATE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─── UPDATED_AT TRIGGER ───────────────────────────────────────

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_properties_updated_at BEFORE UPDATE ON properties
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER set_leads_updated_at BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER set_wallets_updated_at BEFORE UPDATE ON sp6_user_wallets
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ─── INDEXES ──────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_properties_user    ON properties(user_id);
CREATE INDEX IF NOT EXISTS idx_properties_zip     ON properties(zip);
CREATE INDEX IF NOT EXISTS idx_properties_status  ON properties(status);
CREATE INDEX IF NOT EXISTS idx_leads_user         ON leads(user_id);
CREATE INDEX IF NOT EXISTS idx_leads_status       ON leads(status);
CREATE INDEX IF NOT EXISTS idx_agent_runs_user    ON agent_runs(user_id);
CREATE INDEX IF NOT EXISTS idx_agent_runs_status  ON agent_runs(status);
CREATE INDEX IF NOT EXISTS idx_wallets_user       ON sp6_user_wallets(user_id);

-- ─── REALTIME SUBSCRIPTIONS ───────────────────────────────────
-- Enable realtime for agent_runs (powers the live Agent Ledger)
ALTER PUBLICATION supabase_realtime ADD TABLE agent_runs;
ALTER PUBLICATION supabase_realtime ADD TABLE leads;
