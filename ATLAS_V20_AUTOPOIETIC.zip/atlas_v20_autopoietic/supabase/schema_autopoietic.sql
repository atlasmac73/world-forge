-- ============================================================
-- ATLAS v20 — Autopoietic Genesis Schema
-- Add these tables to your existing schema.sql via Supabase SQL Editor
-- ============================================================

-- ─── HEARTBEAT CYCLES ─────────────────────────────────────────────────────────
-- Stores every Heartbeat run: metrics gathered, decision, outcome

CREATE TABLE IF NOT EXISTS heartbeat_cycles (
  id             TEXT PRIMARY KEY,                     -- e.g. hb_1710000000000
  user_id        UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  status         TEXT NOT NULL DEFAULT 'running',      -- running | completed | killed | error
  started_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at   TIMESTAMPTZ,
  total_cost_usd NUMERIC(10, 6) DEFAULT 0,
  metrics        JSONB,                               -- HeartbeatMetrics snapshot
  pr_url         TEXT,                                -- GitHub PR link if created
  kill_reason    TEXT,                                -- Why kill switch fired
  logs           JSONB DEFAULT '[]',                  -- Array of HeartbeatLog
  approval_card  JSONB,                               -- ApprovalCard if mutation passed
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE heartbeat_cycles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own cycles" ON heartbeat_cycles FOR ALL USING (auth.uid() = user_id);

-- ─── AUTOPOIETIC APPROVALS ────────────────────────────────────────────────────
-- Pending/approved/rejected mutations waiting for God Mode sign-off

CREATE TABLE IF NOT EXISTS autopoietic_approvals (
  id            UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  cycle_id      TEXT REFERENCES heartbeat_cycles(id) ON DELETE CASCADE,
  user_id       UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  mutation_id   TEXT NOT NULL,
  approval_card JSONB NOT NULL,
  pr_url        TEXT,
  status        TEXT NOT NULL DEFAULT 'pending',      -- pending | approved | rejected
  reviewed_at   TIMESTAMPTZ,
  reviewed_by   UUID REFERENCES auth.users(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE autopoietic_approvals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users see own approvals" ON autopoietic_approvals FOR ALL USING (auth.uid() = user_id);

-- ─── ACTIVE PROMPT CONFIG ─────────────────────────────────────────────────────
-- Tracks which prompt version is currently active per widget/tool

CREATE TABLE IF NOT EXISTS active_prompt_config (
  widget        TEXT NOT NULL,
  tool          TEXT NOT NULL,
  prompt_version TEXT NOT NULL DEFAULT 'v1',          -- v1 (bloated) | v2 (mutated)
  mutation_id   TEXT,
  activated_at  TIMESTAMPTZ,
  activated_by  UUID REFERENCES auth.users(id),
  PRIMARY KEY (widget, tool)
);

ALTER TABLE active_prompt_config ENABLE ROW LEVEL SECURITY;
CREATE POLICY "All users can read prompt config" ON active_prompt_config FOR SELECT USING (true);
CREATE POLICY "Authenticated users can upsert" ON active_prompt_config FOR ALL USING (auth.uid() IS NOT NULL);

-- ─── REALTIME ─────────────────────────────────────────────────────────────────
-- Enable realtime for live heartbeat console updates

ALTER PUBLICATION supabase_realtime ADD TABLE heartbeat_cycles;
ALTER PUBLICATION supabase_realtime ADD TABLE autopoietic_approvals;

-- ─── INDEXES ──────────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_heartbeat_user       ON heartbeat_cycles(user_id);
CREATE INDEX IF NOT EXISTS idx_heartbeat_status     ON heartbeat_cycles(status);
CREATE INDEX IF NOT EXISTS idx_approvals_user       ON autopoietic_approvals(user_id);
CREATE INDEX IF NOT EXISTS idx_approvals_status     ON autopoietic_approvals(status);
CREATE INDEX IF NOT EXISTS idx_agent_runs_tool      ON agent_runs(tool_name);

-- ─── SANDBOX DIRECTORIES (informational comment only) ────────────────────────
-- The Heartbeat writes mutation files to these paths in your repo:
--   .tmp_sandbox/court_extract_prompt_<mutationId>.ts
--   court_widget_mutations/<mutationId>.json
-- These are tracked by Git on the experiment/meta-singularity branch.
-- They are listed in .gitignore on main to prevent accidental merge.
