# Genesis HQ — Product Command Center

Founder-only roadmap / kanban / idea-library / mind-map / patent-moat tracker for personal
product strategy across ventures. Lives entirely under the `genesis-hq` / `genesis_hq_*`
namespace and is **unrelated** to the existing Genesis Cycle self-improvement engine
(`lib/genesis/cycle.ts`, `app/api/genesis/*`, `genesis_cycles`/`genesis_mutations` tables,
GodMode portal). The two were deliberately namespaced apart to avoid any collision.

## Access model

ATLAS has no org/role table — ownership is just `auth.uid() = user_id` everywhere. Genesis HQ
follows the same pattern with a single-owner gate instead of the org/role model a generic
multi-tenant version might use:

- Any authenticated user can **view** all Genesis HQ content (roadmap, kanban, ideas, mind map,
  patent moat).
- Only the user whose email matches `GENESIS_HQ_OWNER_EMAIL` (env var, see `.env.example`) can
  seed, reset, or edit anything (toggle tasks, move/create/delete kanban cards, create/edit/delete
  ideas, admin actions).
- The check is enforced **server-side only**, in `lib/genesis-hq/permissions.ts`
  (`requireGenesisHqAccess` / `requireGenesisHqOwner`), comparing
  `supabase.auth.getUser()`'s email case-insensitively against `GENESIS_HQ_OWNER_EMAIL`. No
  client-supplied flag is ever trusted.
- RLS gives defense-in-depth: content tables grant `SELECT` only to `authenticated`; there are no
  `INSERT`/`UPDATE`/`DELETE` policies for that role. All writes go through the service-role admin
  client (`createAdminClient()`) after the server-side owner check, so even a buggy/bypassed route
  can't be used to write directly from the browser.
- `genesis_hq_audit_events` has **no RLS policy at all** for `authenticated` — it's readable and
  writable only via the service-role client.

## Database tables (see `supabase/schema.sql`, "GENESIS HQ" section)

`genesis_hq_phases`, `genesis_hq_areas`, `genesis_hq_tasks`, `genesis_hq_kanban_columns`,
`genesis_hq_kanban_cards`, `genesis_hq_ideas`, `genesis_hq_mindmap_nodes`,
`genesis_hq_moat_sections`, `genesis_hq_moat_items`, `genesis_hq_audit_events`,
`genesis_hq_user_preferences`.

`genesis_hq_tasks` and `genesis_hq_kanban_cards` are added to `supabase_realtime` for live
updates. None of these tables carry an `org_id` column — that's the deliberate simplification
versus a generic multi-tenant design, matching how the rest of ATLAS works.

## API routes

| Route | Method | Access |
|---|---|---|
| `/api/genesis-hq` | GET | any authenticated user — full overview (phases+areas+tasks, kanban+cards, ideas, mindmap, moat+items, stats) |
| `/api/genesis-hq/tasks/[taskId]` | PATCH | owner — toggle/edit a task |
| `/api/genesis-hq/kanban/cards` | POST | owner — create a card |
| `/api/genesis-hq/kanban/cards/[cardId]` | PATCH, DELETE | owner — move/edit/delete a card |
| `/api/genesis-hq/ideas` | GET | any authenticated user — search/paginate ideas |
| `/api/genesis-hq/ideas` | POST | owner — create an idea |
| `/api/genesis-hq/ideas/[ideaId]` | PATCH, DELETE | owner |
| `/api/genesis-hq/preferences` | GET, PUT | any authenticated user — own row only |
| `/api/admin/genesis-hq/status` | GET | any authenticated user — counts + `isOwner` + `isSeeded` |
| `/api/admin/genesis-hq/seed` | POST | owner — idempotent seed |
| `/api/admin/genesis-hq/reset` | POST | owner — destructive reset, requires exact confirmation text |
| `/api/admin/genesis-hq/audit` | GET | owner — audit log |

Every owner-only mutation writes a row to `genesis_hq_audit_events` (action, entity type/id,
metadata). Reset writes its audit row **before** deleting, and the audit table itself is excluded
from the delete list, so history survives a reset.

## Seeding

`POST /api/admin/genesis-hq/seed` is idempotent — safe to re-run. It upserts on natural keys
(`slug`, `source_key`, `source_number`, `key`) for tables with unique constraints, and does a
manual existence check for `genesis_hq_kanban_cards` (keyed by `task_id`) and
`genesis_hq_moat_items` (keyed by `section_id` + `text`) since those don't have natural unique
constraints. Seed content lives in `lib/genesis-hq/seed-data.ts`.

## Reset

`POST /api/admin/genesis-hq/reset` permanently deletes all phases, areas, tasks, kanban
cards/columns, ideas, mind map nodes, moat sections/items, and the caller's preferences row. It
requires the request body to contain `{ "confirm": "RESET GENESIS HQ" }` exactly
(`GENESIS_HQ_RESET_CONFIRMATION_TEXT` in `lib/genesis-hq/constants.ts`), validated server-side via
a Zod `z.literal`. The audit log is preserved.

## UI

Genesis HQ is a **portal**, not a set of Next.js routes — consistent with how the rest of ATLAS
works (`app/page.tsx`'s `PORTALS` map, `useAtlasStore`'s `Portal` union, `Sidebar.tsx`'s
`NAV_ITEMS`). `components/portals/GenesisHQ.tsx` is a thin wrapper around
`components/genesis-hq/GenesisHqCommandCenter.tsx`, which renders a tab bar (Roadmap, Kanban,
Mind Map, 100 Ideas, Patent Moat, Admin) instead of nested routes. Non-owners see a "VIEW ONLY"
badge and read-only views; the Admin tab shows "Owner access required" for non-owners.

## Setup

Add to `.env.local`:

```
GENESIS_HQ_OWNER_EMAIL=your-founder-email@example.com
```

Run the updated `supabase/schema.sql` against your Supabase project, then sign in as the owner
account and click **Seed Now** in the Genesis HQ → Admin tab.
