/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: {
      allowedOrigins: ['localhost:3000'],
    },
  },
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.supabase.co' },
      { protocol: 'https', hostname: 'api.mapbox.com' },
    ],
  },
  env: {
    NEXT_PUBLIC_APP_NAME: 'ATLAS v20',
    NEXT_PUBLIC_APP_VERSION: '20.0.0',
  },
}

module.exports = nextConfig
