# ATLAS v20 — Real Estate AI Command Center

> GodMode Edition · Next.js 14 · Multi-Agent Orchestration · Charleston, WV

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Set up environment variables
```bash
cp .env.example .env.local
# Fill in your API keys in .env.local
```

### 3. Set up Supabase database
- Create a project at [supabase.com](https://supabase.com)
- Go to SQL Editor → paste contents of `supabase/schema.sql` → Run

### 4. Run development server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Required API Keys

| Service     | Where to get it                          | Required |
|-------------|------------------------------------------|----------|
| Anthropic   | [console.anthropic.com](https://console.anthropic.com) | ✅ Yes |
| Supabase    | [supabase.com](https://supabase.com)     | ✅ Yes |
| Mapbox      | [account.mapbox.com](https://account.mapbox.com) | Optional |
| Twilio      | [twilio.com/console](https://www.twilio.com/console) | Optional |
| Stripe      | [dashboard.stripe.com](https://dashboard.stripe.com) | Optional |

You can also enter API keys directly in the app via **Settings → API Keys**.

---

## Architecture

```
ATLAS v20/
├── app/                          # Next.js 14 App Router
│   ├── layout.tsx                # Root layout + providers
│   ├── page.tsx                  # Main app shell
│   └── api/
│       ├── claude/route.ts       # Claude streaming endpoint
│       ├── agents/dossier/       # Investigator → Underwriter → Copywriter
│       ├── properties/           # Property CRUD
│       └── leads/                # Lead management
├── components/
│   ├── Sidebar.tsx               # Navigation
│   ├── TopBar.tsx                # Header controls
│   ├── CopilotPanel.tsx          # AI chat (streaming)
│   ├── ModalProvider.tsx         # All modals (no race conditions)
│   ├── modals/                   # ApiKeyModal, NeuralCallModal, StripeCheckout
│   └── portals/                  # Dashboard, DealNavigator, CommsHub, MarketIntel, AgentLab, SP6Wallet
├── store/
│   └── useAtlasStore.ts          # Unified Zustand store (no more global collisions)
├── lib/
│   ├── agent-os/toolGateway.ts   # Zero-Trust Gateway (auth + billing + logging)
│   ├── agents/
│   │   ├── investigator.ts       # L6 property researcher
│   │   ├── underwriter.ts        # L6 deal analyst
│   │   └── copywriter.ts         # L6 outreach writer
│   └── supabase/                 # Server + client helpers
└── supabase/
    └── schema.sql                # Full DB schema + RLS policies
```

## Key Features

- **Zero-Trust Tool Gateway** — Every AI call: auth → billing gate → rate limit → execute → log
- **Zustand Store** — Single source of truth, no global variable collisions
- **Multi-Agent Pipeline** — Investigator → Underwriter → Copywriter chain
- **Real-time Agent Ledger** — Supabase Realtime subscriptions
- **SP6 Credit Wallet** — Daily credit limits with billing gate enforcement
- **7-Touch Outreach** — WV tax-delinquent owner SMS/Email sequence
- **Charleston Market Intel** — Top ZIP code opportunity scoring

## Credit Costs

| Tool | Credits |
|------|---------|
| Copilot message | 2 |
| Property analysis | 5 |
| Market heatmap | 8 |
| Skip trace | 10 |
| SMS sequence | 3 |
| Full Dossier (3-agent pod) | 25 |

## Plans

| Plan | Daily Credits | Price |
|------|--------------|-------|
| Free | 100 | $0 |
| Pro | 1,000 | $97/mo |
| Enterprise | 5,000 | $297/mo |
