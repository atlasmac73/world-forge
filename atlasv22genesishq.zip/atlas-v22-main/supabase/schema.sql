-- ============================================================
-- ATLAS v20 — Supabase Schema + Row Level Security
-- Run this in your Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── PROPERTIES ───────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS properties (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  address         TEXT NOT NULL,
  city            TEXT NOT NULL DEFAULT 'Charleston',
  state           TEXT NOT NULL DEFAULT 'WV',
  zip             TEXT,
  equity_pct      NUMERIC(5,2),
  arv             NUMERIC(12,2),
  asking_price    NUMERIC(12,2),
  assessed_value  NUMERIC(12,2),
  status          TEXT NOT NULL DEFAULT 'warm' CHECK (status IN ('hot','warm','cold','closed')),
  tax_delinquent  BOOLEAN NOT NULL DEFAULT FALSE,
  tax_owed        NUMERIC(10,2),
  owner_name      TEXT,
  owner_phone     TEXT,
  owner_email     TEXT,
  distress_score  INTEGER CHECK (distress_score BETWEEN 0 AND 100),
  deal_grade      TEXT CHECK (deal_grade IN ('A','B','C','D','F')),
  notes           TEXT,
  dossier_json    JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own properties" ON properties
  FOR ALL USING (auth.uid() = user_id);

-- ─── LEADS ────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS leads (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  property_id     UUID REFERENCES properties(id) ON DELETE SET NULL,
  name            TEXT NOT NULL,
  phone           TEXT,
  email           TEXT,
  status          TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','contacted','negotiating','closed','dead')),
  touch_sequence  INTEGER NOT NULL DEFAULT 0,
  last_contact    TIMESTAMPTZ,
  notes           TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own leads" ON leads
  FOR ALL USING (auth.uid() = user_id);

-- ─── AGENT RUNS ───────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS agent_runs (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id           UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  session_id        TEXT,
  tool_name         TEXT NOT NULL,
  agent_type        TEXT,
  status            TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running','completed','failed')),
  input             JSONB,
  output            JSONB,
  error             TEXT,
  credits_reserved  INTEGER DEFAULT 0,
  credits_consumed  INTEGER DEFAULT 0,
  tokens_used       INTEGER DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at      TIMESTAMPTZ
);

ALTER TABLE agent_runs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own agent runs" ON agent_runs
  FOR ALL USING (auth.uid() = user_id);

-- ─── SP6 USER WALLETS ─────────────────────────────────────────

CREATE TABLE IF NOT EXISTS sp6_user_wallets (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id               UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  balance               NUMERIC(10,2) NOT NULL DEFAULT 0,
  credits_used_today    INTEGER NOT NULL DEFAULT 0,
  credits_limit_daily   INTEGER NOT NULL DEFAULT 100,
  plan                  TEXT NOT NULL DEFAULT 'free' CHECK (plan IN ('free','pro','enterprise')),
  stripe_customer_id    TEXT,
  stripe_subscription_id TEXT,
  last_reset_date       DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE sp6_user_wallets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users see own wallet" ON sp6_user_wallets
  FOR ALL USING (auth.uid() = user_id);

-- ─── AUTO-CREATE WALLET ON SIGNUP ─────────────────────────────

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO sp6_user_wallets (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ─── RESET DAILY CREDITS (call via cron) ──────────────────────

CREATE OR REPLACE FUNCTION reset_daily_credits()
RETURNS void AS $$
BEGIN
  UPDATE sp6_user_wallets
  SET credits_used_today = 0,
      last_reset_date = CURRENT_DATE
  WHERE last_reset_date < CURRENT_DATE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─── UPDATED_AT TRIGGER ───────────────────────────────────────

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_properties_updated_at BEFORE UPDATE ON properties
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER set_leads_updated_at BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER set_wallets_updated_at BEFORE UPDATE ON sp6_user_wallets
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ─── INDEXES ──────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_properties_user    ON properties(user_id);
CREATE INDEX IF NOT EXISTS idx_properties_zip     ON properties(zip);
CREATE INDEX IF NOT EXISTS idx_properties_status  ON properties(status);
CREATE INDEX IF NOT EXISTS idx_leads_user         ON leads(user_id);
CREATE INDEX IF NOT EXISTS idx_leads_status       ON leads(status);
CREATE INDEX IF NOT EXISTS idx_agent_runs_user    ON agent_runs(user_id);
CREATE INDEX IF NOT EXISTS idx_agent_runs_status  ON agent_runs(status);
CREATE INDEX IF NOT EXISTS idx_wallets_user       ON sp6_user_wallets(user_id);

-- ─── REALTIME SUBSCRIPTIONS ───────────────────────────────────
-- Enable realtime for agent_runs (powers the live Agent Ledger)
ALTER PUBLICATION supabase_realtime ADD TABLE agent_runs;
ALTER PUBLICATION supabase_realtime ADD TABLE leads;

-- ─── v22 ADDITIONS: Genesis Cycle + God Squad ─────────────────────────────────

-- Genesis cycle run history
CREATE TABLE IF NOT EXISTS genesis_cycles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'running',  -- idle|running|awaiting_approval|complete|aborted
  current_phase TEXT,
  phase_results JSONB DEFAULT '{}',
  total_cost_usd DECIMAL(8,4) DEFAULT 0,
  budget_kill_triggered BOOLEAN DEFAULT FALSE,
  mutations JSONB DEFAULT '[]',
  approval_required BOOLEAN DEFAULT TRUE,
  created_by UUID REFERENCES auth.users(id)
);

-- Proposed mutations queue
CREATE TABLE IF NOT EXISTS genesis_mutations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_id UUID REFERENCES genesis_cycles(id) ON DELETE CASCADE,
  type TEXT NOT NULL,           -- prompt_update|routing_change|new_tool|threshold_adjustment
  target_component TEXT NOT NULL,
  current_value TEXT,
  proposed_value TEXT,
  expected_improvement TEXT,
  risk_level TEXT DEFAULT 'medium',  -- low|medium|high
  status TEXT DEFAULT 'pending',     -- pending|approved|rejected|deployed
  github_pr_url TEXT,
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AIN (Appalachian Intelligence Network) data log
CREATE TABLE IF NOT EXISTS ain_signals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  signal_type TEXT NOT NULL,   -- tax_delinquent|foreclosure|probate|absentee_owner|price_drop
  property_id UUID REFERENCES properties(id),
  distress_score INTEGER CHECK (distress_score BETWEEN 0 AND 100),
  zip_code TEXT,
  county TEXT,
  raw_data JSONB,
  processed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Real data API cache (avoid redundant API calls)
CREATE TABLE IF NOT EXISTS api_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cache_key TEXT UNIQUE NOT NULL,  -- hash of request params
  source TEXT NOT NULL,            -- mls|propstream|attom|wv_county
  data JSONB NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- God Squad agent run log (extends existing agent_runs)
CREATE TABLE IF NOT EXISTS god_squad_runs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id TEXT NOT NULL,          -- gs-01 through gs-25
  agent_codename TEXT NOT NULL,
  agent_tier TEXT NOT NULL,
  genesis_phase TEXT NOT NULL,
  status TEXT DEFAULT 'idle',
  input JSONB,
  output JSONB,
  credits_consumed INTEGER DEFAULT 0,
  cost_usd DECIMAL(6,4) DEFAULT 0,
  duration_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  user_id UUID REFERENCES auth.users(id)
);

-- RLS Policies (god mode tables)
ALTER TABLE genesis_cycles ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_mutations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ain_signals ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE god_squad_runs ENABLE ROW LEVEL SECURITY;

-- Only authenticated users can see their own data
CREATE POLICY "Users see own genesis cycles" ON genesis_cycles FOR ALL USING (auth.uid() = created_by);
CREATE POLICY "Users see own mutations" ON genesis_mutations FOR SELECT USING (
  cycle_id IN (SELECT id FROM genesis_cycles WHERE created_by = auth.uid())
);
CREATE POLICY "Users see own god squad runs" ON god_squad_runs FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Authenticated users see ain signals" ON ain_signals FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users see cache" ON api_cache FOR ALL USING (auth.uid() IS NOT NULL);

-- ─── v22 ADDITIONS: GENESIS HQ (Product Command Center) ───────────────────────
-- NOTE: This is unrelated to the "Genesis Cycle" self-improvement engine above
-- (genesis_cycles / genesis_mutations / app/api/genesis/*). Genesis HQ is a
-- roadmap / kanban / idea-library / mind-map / patent-moat tracker — the
-- founder's personal mission control. Namespaced "genesis_hq_*" to avoid any
-- collision with the existing Genesis Cycle tables and routes.
--
-- There is no org/role table in this schema (atlas-v22 is single-owner,
-- auth.uid() = user_id ownership throughout). All genesis_hq_* content is
-- readable by any authenticated user, but every write (seed/reset/edit/move)
-- is performed server-side through the service-role client after an
-- owner-email check (see lib/genesis-hq/permissions.ts) — never via direct
-- client writes. Audit events are insert/read only via the service-role
-- client, so no authenticated-role policy is defined for that table.

-- ─── PHASES ────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_phases (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        TEXT NOT NULL UNIQUE,
  label       TEXT NOT NULL,
  title       TEXT NOT NULL,
  color       TEXT NOT NULL DEFAULT '#00f5c4',
  status      TEXT NOT NULL DEFAULT 'planned'
              CHECK (status IN ('active','planned','future','complete','archived')),
  eta         TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_by  UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── AREAS ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_areas (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phase_id    UUID NOT NULL REFERENCES genesis_hq_phases(id) ON DELETE CASCADE,
  slug        TEXT NOT NULL UNIQUE,
  title       TEXT NOT NULL,
  icon        TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── TASKS ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_tasks (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phase_id    UUID NOT NULL REFERENCES genesis_hq_phases(id) ON DELETE CASCADE,
  area_id     UUID NOT NULL REFERENCES genesis_hq_areas(id) ON DELETE CASCADE,
  source_key  TEXT NOT NULL UNIQUE,
  text        TEXT NOT NULL,
  done        BOOLEAN NOT NULL DEFAULT FALSE,
  priority    TEXT NOT NULL DEFAULT 'medium'
              CHECK (priority IN ('critical','high','medium','low')),
  sort_order  INTEGER NOT NULL DEFAULT 0,
  due_date    DATE,
  created_by  UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── KANBAN COLUMNS ────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_kanban_columns (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key         TEXT NOT NULL UNIQUE,
  label       TEXT NOT NULL,
  color       TEXT NOT NULL DEFAULT '#444444',
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── KANBAN CARDS ──────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_kanban_cards (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  column_key  TEXT NOT NULL,
  task_id     UUID REFERENCES genesis_hq_tasks(id) ON DELETE SET NULL,
  text        TEXT NOT NULL,
  priority    TEXT NOT NULL DEFAULT 'medium'
              CHECK (priority IN ('critical','high','medium','low')),
  phase_label TEXT,
  area_title  TEXT,
  color       TEXT,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_by  UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── IDEAS ─────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_ideas (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_number    INTEGER UNIQUE,
  category         TEXT NOT NULL
                   CHECK (category IN ('CAPTURE','GENERATE','PRIVACY','CONNECT','PATENT')),
  title            TEXT NOT NULL,
  description      TEXT NOT NULL,
  patent_direction TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'concept',
  score            INTEGER CHECK (score BETWEEN 0 AND 100),
  tags             TEXT[] NOT NULL DEFAULT '{}',
  created_by       UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── MIND MAP NODES ────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_mindmap_nodes (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_key        TEXT NOT NULL UNIQUE,
  label             TEXT NOT NULL,
  x                 NUMERIC NOT NULL,
  y                 NUMERIC NOT NULL,
  radius            NUMERIC NOT NULL,
  color             TEXT NOT NULL,
  parent_source_key TEXT,
  text_color        TEXT DEFAULT '#ffffff',
  sort_order        INTEGER NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── MOAT SECTIONS ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_moat_sections (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug        TEXT NOT NULL UNIQUE,
  icon        TEXT,
  title       TEXT NOT NULL,
  color       TEXT NOT NULL DEFAULT '#00f5c4',
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── MOAT ITEMS ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_moat_items (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_id  UUID NOT NULL REFERENCES genesis_hq_moat_sections(id) ON DELETE CASCADE,
  text        TEXT NOT NULL,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── AUDIT EVENTS ──────────────────────────────────────────────
-- Insert/read only via service-role client (see lib/genesis-hq/permissions.ts).
-- No RLS policy is defined for the authenticated role on purpose.

CREATE TABLE IF NOT EXISTS genesis_hq_audit_events (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action       TEXT NOT NULL,
  entity_type  TEXT NOT NULL,
  entity_id    UUID,
  metadata     JSONB NOT NULL DEFAULT '{}',
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── USER PREFERENCES ──────────────────────────────────────────

CREATE TABLE IF NOT EXISTS genesis_hq_user_preferences (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  default_view     TEXT NOT NULL DEFAULT 'roadmap',
  collapsed_phases JSONB NOT NULL DEFAULT '{}',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── GENESIS HQ INDEXES ─────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_genesis_hq_areas_phase        ON genesis_hq_areas(phase_id);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_tasks_phase        ON genesis_hq_tasks(phase_id);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_tasks_area         ON genesis_hq_tasks(area_id);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_tasks_done         ON genesis_hq_tasks(done);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_kanban_cards_col   ON genesis_hq_kanban_cards(column_key, sort_order);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_kanban_cards_task  ON genesis_hq_kanban_cards(task_id);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_ideas_category     ON genesis_hq_ideas(category);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_ideas_tags         ON genesis_hq_ideas USING gin(tags);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_ideas_fts          ON genesis_hq_ideas USING gin(
  to_tsvector('english', coalesce(title,'') || ' ' || coalesce(description,'') || ' ' || coalesce(patent_direction,''))
);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_moat_items_section ON genesis_hq_moat_items(section_id);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_audit_created      ON genesis_hq_audit_events(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_genesis_hq_audit_user         ON genesis_hq_audit_events(user_id);

-- ─── GENESIS HQ UPDATED_AT TRIGGERS ─────────────────────────────

CREATE TRIGGER set_genesis_hq_phases_updated_at BEFORE UPDATE ON genesis_hq_phases
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_areas_updated_at BEFORE UPDATE ON genesis_hq_areas
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_tasks_updated_at BEFORE UPDATE ON genesis_hq_tasks
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_kanban_columns_updated_at BEFORE UPDATE ON genesis_hq_kanban_columns
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_kanban_cards_updated_at BEFORE UPDATE ON genesis_hq_kanban_cards
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_ideas_updated_at BEFORE UPDATE ON genesis_hq_ideas
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_mindmap_nodes_updated_at BEFORE UPDATE ON genesis_hq_mindmap_nodes
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_moat_sections_updated_at BEFORE UPDATE ON genesis_hq_moat_sections
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_moat_items_updated_at BEFORE UPDATE ON genesis_hq_moat_items
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER set_genesis_hq_user_preferences_updated_at BEFORE UPDATE ON genesis_hq_user_preferences
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ─── GENESIS HQ ROW LEVEL SECURITY ───────────────────────────────

ALTER TABLE genesis_hq_phases            ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_areas             ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_tasks             ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_kanban_columns    ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_kanban_cards      ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_ideas             ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_mindmap_nodes     ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_moat_sections     ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_moat_items        ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_audit_events      ENABLE ROW LEVEL SECURITY;
ALTER TABLE genesis_hq_user_preferences  ENABLE ROW LEVEL SECURITY;

-- Content tables: any authenticated user can read. All writes happen
-- server-side via the service-role client after an owner check, so no
-- write policy is granted to the "authenticated" role.
CREATE POLICY "Authenticated users read genesis hq phases"         ON genesis_hq_phases         FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq areas"          ON genesis_hq_areas          FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq tasks"          ON genesis_hq_tasks          FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq kanban columns" ON genesis_hq_kanban_columns FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq kanban cards"   ON genesis_hq_kanban_cards   FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq ideas"          ON genesis_hq_ideas          FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq mindmap nodes"  ON genesis_hq_mindmap_nodes  FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq moat sections"  ON genesis_hq_moat_sections  FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Authenticated users read genesis hq moat items"     ON genesis_hq_moat_items     FOR SELECT USING (auth.uid() IS NOT NULL);

-- User preferences: each user owns their own row directly.
CREATE POLICY "Users manage own genesis hq preferences" ON genesis_hq_user_preferences
  FOR ALL USING (auth.uid() = user_id);

-- Realtime for live kanban/task updates across sessions
ALTER PUBLICATION supabase_realtime ADD TABLE genesis_hq_tasks;
ALTER PUBLICATION supabase_realtime ADD TABLE genesis_hq_kanban_cards;

