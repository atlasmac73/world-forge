# ATLAS v22 — Complete Deployment Guide
## GitHub Setup → Vercel Live → Production Checklist

---

## STEP 1: Get Your GitHub Token

1. Go to **https://github.com/settings/tokens**
2. Click **"Generate new token (classic)"**
3. Name it: `ATLAS v22 Deploy`
4. Expiration: **No expiration** (or 1 year)
5. Check these scopes:
   - ✅ `repo` (full control of private repos)
   - ✅ `workflow` (update GitHub Actions workflows)
6. Click **Generate token**
7. **COPY IT NOW** — you won't see it again

> Save it somewhere safe. You'll need it in Step 2 and in Vercel.

---

## STEP 2: Push Code to GitHub

Open your terminal and run these commands:

```bash
# 1. Navigate to the atlas-v22 folder you downloaded/unzipped
cd path/to/atlas-v22

# 2. Initialize git (if not already)
git init

# 3. Set your git identity (if first time)
git config user.email "atlasmac73@gmail.com"
git config user.name "Atlas Management"

# 4. Add the remote (your existing repo)
git remote add origin https://github.com/atlasmac73/atlas-v22.git

# 5. Create and switch to main branch
git checkout -b main

# 6. Stage all files
git add .

# 7. Commit
git commit -m "feat: ATLAS v22 — God Mode, 25-Agent God Squad, Genesis Cycle, Real Data APIs"

# 8. Push (you'll be prompted for username/token)
#    Username: atlasmac73
#    Password: [paste your GitHub token from Step 1]
git push -u origin main
```

**If the repo already exists with conflicts:**
```bash
git pull origin main --allow-unrelated-histories
git push -u origin main --force
```

**Create the experiment branch (for Genesis mutations):**
```bash
git checkout -b experiment/genesis-mutations
git push -u origin experiment/genesis-mutations
git checkout main
```

---

## STEP 3: Set Up Supabase

1. Go to **https://supabase.com** → New Project
2. Name: `atlas-v22`
3. Region: **US East (closest to WV)**
4. Save your **database password**
5. Once created, go to **SQL Editor**
6. Paste the entire contents of `supabase/schema.sql`
7. Click **Run**
8. Go to **Settings → API** and copy:
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY`

---

## STEP 4: Deploy to Vercel

### Option A: Vercel CLI (fastest)

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login
# Choose: Continue with GitHub → authorize

# Deploy from your atlas-v22 folder
cd path/to/atlas-v22
vercel

# Answer the prompts:
# Set up and deploy? → Y
# Which scope? → your account
# Link to existing project? → N (first time)
# Project name: atlas-v22
# Directory: ./
# Override settings? → N
```

### Option B: Vercel Dashboard (visual)

1. Go to **https://vercel.com/new**
2. Click **"Import Git Repository"**
3. Connect GitHub if not connected
4. Select `atlasmac73/atlas-v22`
5. Framework preset: **Next.js** (auto-detected)
6. Root directory: `./`
7. **Don't deploy yet** — set env vars first (Step 5)

---

## STEP 5: Add Environment Variables in Vercel

In Vercel project → **Settings → Environment Variables**, add:

### Required (app won't start without these)
| Variable | Value | Where to get |
|----------|-------|--------------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` | console.anthropic.com |
| `NEXT_PUBLIC_SUPABASE_URL` | `https://xxx.supabase.co` | Supabase Settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | `eyJ...` | Supabase Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | `eyJ...` | Supabase Settings → API |

### For God Mode / Genesis Cycle
| Variable | Value |
|----------|-------|
| `GITHUB_TOKEN` | Your token from Step 1 |
| `GITHUB_REPO` | `atlasmac73/atlas-v22` |

### For Real Data (add as you get them)
| Variable | Source |
|----------|--------|
| `NEXT_PUBLIC_MAPBOX_TOKEN` | account.mapbox.com (free tier) |
| `TWILIO_ACCOUNT_SID` | twilio.com/console |
| `TWILIO_AUTH_TOKEN` | twilio.com/console |
| `TWILIO_PHONE_NUMBER` | Buy in Twilio console |
| `STRIPE_SECRET_KEY` | dashboard.stripe.com |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | dashboard.stripe.com |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhooks (after deploy) |
| `MLS_ACCESS_TOKEN` | Apply at WVMLS / your state MLS |
| `PROPSTREAM_API_KEY` | propstream.com → API |
| `ATTOM_API_KEY` | api.gateway.attomdata.com |

**Set all env vars to:** Environments: ✅ Production ✅ Preview ✅ Development

---

## STEP 6: Deploy

```bash
# If using CLI:
vercel --prod

# Or in Vercel dashboard → click "Deploy"
```

Watch the build logs. Common issues:

**TypeScript errors:**
```bash
# Run locally first to check
npm run type-check
```

**Missing modules:**
```bash
npm install
```

**Build success** → You'll get a URL like: `https://atlas-v22.vercel.app`

---

## STEP 7: Configure Stripe Webhooks

1. Go to **Stripe Dashboard → Webhooks**
2. Click **Add endpoint**
3. URL: `https://your-vercel-url.vercel.app/api/stripe/webhook`
4. Events to listen:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
5. Copy the **Signing secret** → add as `STRIPE_WEBHOOK_SECRET` in Vercel
6. Redeploy

---

## STEP 8: Test God Mode

1. Open your deployed app
2. Log in
3. On any page, hold **Shift** and type: `nasdrop`
4. God Mode portal appears in the sidebar (gold, OMEGA badge)
5. Click **TRIGGER CYCLE** to run your first Genesis Cycle

---

## STEP 9: Set Up Local Dev

```bash
# Clone your repo
git clone https://github.com/atlasmac73/atlas-v22.git
cd atlas-v22

# Install deps
npm install

# Set up env
cp .env.example .env.local
# Fill in your keys

# Run dev server
npm run dev
# Open http://localhost:3000
```

---

## API Keys Priority Order

**Get these first (free):**
1. Anthropic API key — console.anthropic.com
2. Supabase — supabase.com (free tier)
3. Mapbox — account.mapbox.com (free tier, 50k loads/month)
4. GitHub token — github.com/settings/tokens

**Get these for monetization:**
5. Stripe — dashboard.stripe.com
6. Twilio — twilio.com ($20 credit to start)

**Get these for real data (apply/pay):**
7. PropStream — propstream.com (~$99/mo)
8. ATTOM Data — api.gateway.attomdata.com (contact sales)
9. WVMLS Access — apply through WV Association of Realtors

**Until you have real data APIs:**
- The app runs on **realistic mock data** automatically
- Mock data generates WV ZIP codes, property data, owner names
- All features work — you'll swap in live data as keys arrive

---

## Production Checklist

- [ ] Code pushed to `atlasmac73/atlas-v22` main branch
- [ ] `experiment/genesis-mutations` branch created
- [ ] Supabase project created + schema.sql executed
- [ ] Vercel project deployed
- [ ] Required env vars set (Anthropic + Supabase)
- [ ] Custom domain added (optional: app.atlasmanagement.com)
- [ ] Stripe webhook configured
- [ ] God Mode tested (Shift + nasdrop)
- [ ] Genesis Cycle first run successful
- [ ] First real user account created

---

## What's New in v22 vs v20

| Feature | v20 | v22 |
|---------|-----|-----|
| Agents | 3 (Investigator, Underwriter, Copywriter) | 25 God Squad agents |
| God Mode | Not present | ✅ Shift+nasdrop unlock |
| Genesis Cycle | Not present | ✅ 6-phase autopoietic loop |
| Real Data APIs | Mock only | ✅ MLS + WV County + PropStream routes |
| Supabase Tables | 6 tables | 11 tables (+ 5 v22) |
| Agent Tiers | None | L6 / L7 / L8 / OMEGA |
| Self-mutation | Not present | ✅ GitHub PR generation |
| Budget Kill | Not present | ✅ $5/cycle hard limit |
| Geographic scope | WV only | WV → 50 States → Global (staged) |

---

## Support

- GitHub repo: https://github.com/atlasmac73/atlas-v22
- Email: atlasmac73@gmail.com
- Vercel docs: https://vercel.com/docs
- Supabase docs: https://supabase.com/docs
