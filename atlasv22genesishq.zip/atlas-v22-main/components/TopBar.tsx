'use client'

import { useAtlasStore } from '@/store/useAtlasStore'
import { Bell, Key, Shield, WifiOff } from 'lucide-react'
import { clsx } from 'clsx'

export function TopBar() {
  const { activePortal, safeMode, offlineMode, setSafeMode, openModal, hasRequiredKeys } = useAtlasStore()

  const portalLabel: Record<string, string> = {
    'dashboard': 'Command Dashboard',
    'deal-navigator': 'Deal Navigator — Property Intelligence',
    'comms-hub': 'Comms Hub — SMS / Email Sequences',
    'market-intel': 'Market Intel — Charleston, WV',
    'agent-lab': 'Agent Lab — Multi-Agent Orchestration',
    'sp6-wallet': 'SP6 Wallet — Credits & Billing',
    'settings': 'Settings',
  }

  return (
    <header className="h-12 flex items-center justify-between px-4 border-b border-atlas-border bg-atlas-panel/50 backdrop-blur shrink-0">
      {/* Left: Breadcrumb */}
      <div className="flex items-center gap-2">
        <span className="text-atlas-muted text-xs font-mono">ATLAS v20</span>
        <span className="text-atlas-border">/</span>
        <span className="text-atlas-text text-sm font-medium">{portalLabel[activePortal]}</span>
      </div>

      {/* Right: Controls */}
      <div className="flex items-center gap-2">
        {/* Offline indicator */}
        {offlineMode && (
          <div className="flex items-center gap-1 text-atlas-gold text-xs">
            <WifiOff size={12} />
            <span>Offline</span>
          </div>
        )}

        {/* API Key status */}
        {!hasRequiredKeys() && (
          <button
            onClick={() => openModal('api-key')}
            className="flex items-center gap-1 text-xs text-atlas-gold hover:text-white transition-colors px-2 py-1 rounded border border-atlas-gold/30 hover:border-atlas-gold"
          >
            <Key size={12} />
            <span>Add API Keys</span>
          </button>
        )}

        {/* Safe Mode Toggle */}
        <button
          onClick={() => setSafeMode(!safeMode)}
          className={clsx(
            'flex items-center gap-1 text-xs px-2 py-1 rounded transition-all',
            safeMode
              ? 'bg-atlas-green/20 text-atlas-green border border-atlas-green/30'
              : 'text-atlas-muted hover:text-atlas-text border border-atlas-border'
          )}
        >
          <Shield size={12} />
          <span>{safeMode ? 'Safe ON' : 'Safe'}</span>
        </button>

        {/* Notifications */}
        <button className="relative text-atlas-muted hover:text-atlas-text transition-colors p-1 rounded">
          <Bell size={16} />
          <span className="absolute top-0 right-0 w-2 h-2 bg-atlas-red rounded-full" />
        </button>

        {/* User Avatar */}
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-atlas-accent to-atlas-purple flex items-center justify-center text-[10px] font-bold text-white">
          AT
        </div>
      </div>
    </header>
  )
}
