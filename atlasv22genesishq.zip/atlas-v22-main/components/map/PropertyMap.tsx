'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { Maximize2, Minimize2, Layers, Filter } from 'lucide-react'
import { clsx } from 'clsx'

interface PropertyMarker {
  id: string
  address: string
  lat: number
  lng: number
  status: 'hot' | 'warm' | 'cold' | 'closed'
  distress_score?: number
  equity_pct?: number
}

interface PropertyMapProps {
  properties?: PropertyMarker[]
  onPropertyClick?: (id: string) => void
  height?: string
}

const STATUS_COLORS = {
  hot: '#ff4444',
  warm: '#ffa500',
  cold: '#00d4ff',
  closed: '#00ff88',
}

// Charleston, WV center coordinates
const DEFAULT_CENTER: [number, number] = [-81.6326, 38.3498]
const DEFAULT_ZOOM = 11

export function PropertyMap({ properties = [], onPropertyClick, height = '400px' }: PropertyMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const markersRef = useRef<mapboxgl.Marker[]>([])
  
  const { mapCenter, mapZoom, setMapCenter, setMapZoom, apiKeys } = useAtlasStore()
  const [isExpanded, setIsExpanded] = useState(false)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [showHeatmap, setShowHeatmap] = useState(false)

  const mapboxToken = apiKeys.mapbox || process.env.NEXT_PUBLIC_MAPBOX_TOKEN

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || map.current) return
    if (!mapboxToken) return

    const initMap = async () => {
      const mapboxgl = (await import('mapbox-gl')).default
      mapboxgl.accessToken = mapboxToken

      map.current = new mapboxgl.Map({
        container: mapContainer.current!,
        style: 'mapbox://styles/mapbox/dark-v11',
        center: mapCenter,
        zoom: mapZoom,
      })

      map.current.addControl(new mapboxgl.NavigationControl(), 'top-right')

      map.current.on('load', () => {
        setMapLoaded(true)
      })

      map.current.on('moveend', () => {
        if (map.current) {
          const center = map.current.getCenter()
          setMapCenter([center.lng, center.lat])
          setMapZoom(map.current.getZoom())
        }
      })
    }

    initMap()

    return () => {
      if (map.current) {
        map.current.remove()
        map.current = null
      }
    }
  }, [mapboxToken])

  // Update markers when properties change
  const updateMarkers = useCallback(async () => {
    if (!map.current || !mapLoaded) return

    const mapboxgl = (await import('mapbox-gl')).default

    // Clear existing markers
    markersRef.current.forEach((marker) => marker.remove())
    markersRef.current = []

    // Add new markers
    properties.forEach((property) => {
      const el = document.createElement('div')
      el.className = 'property-marker'
      el.innerHTML = `
        <div style="
          width: 24px;
          height: 24px;
          background: ${STATUS_COLORS[property.status]};
          border: 2px solid white;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          font-weight: bold;
          color: white;
          box-shadow: 0 2px 8px rgba(0,0,0,0.4);
        ">
          ${property.distress_score ? Math.round(property.distress_score / 10) : '•'}
        </div>
      `

      const marker = new mapboxgl.Marker(el)
        .setLngLat([property.lng, property.lat])
        .setPopup(
          new mapboxgl.Popup({ offset: 25 }).setHTML(`
            <div style="background: #0f0f1a; color: #e0e0e0; padding: 8px; border-radius: 6px; font-size: 12px;">
              <div style="font-weight: bold; margin-bottom: 4px;">${property.address}</div>
              <div style="display: flex; gap: 8px;">
                <span style="color: ${STATUS_COLORS[property.status]};">● ${property.status.toUpperCase()}</span>
                ${property.equity_pct ? `<span style="color: #00ff88;">${property.equity_pct}% Equity</span>` : ''}
              </div>
            </div>
          `)
        )
        .addTo(map.current!)

      el.addEventListener('click', () => {
        if (onPropertyClick) onPropertyClick(property.id)
      })

      markersRef.current.push(marker)
    })
  }, [properties, mapLoaded, onPropertyClick])

  useEffect(() => {
    updateMarkers()
  }, [updateMarkers])

  // Add heatmap layer
  useEffect(() => {
    if (!map.current || !mapLoaded) return

    const sourceId = 'property-heat'
    const layerId = 'property-heatmap'

    if (showHeatmap && properties.length > 0) {
      // Create GeoJSON data
      const geojson = {
        type: 'FeatureCollection' as const,
        features: properties.map((p) => ({
          type: 'Feature' as const,
          properties: { intensity: (p.distress_score || 50) / 100 },
          geometry: {
            type: 'Point' as const,
            coordinates: [p.lng, p.lat],
          },
        })),
      }

      // Add or update source
      if (map.current.getSource(sourceId)) {
        (map.current.getSource(sourceId) as mapboxgl.GeoJSONSource).setData(geojson)
      } else {
        map.current.addSource(sourceId, { type: 'geojson', data: geojson })
      }

      // Add layer if not exists
      if (!map.current.getLayer(layerId)) {
        map.current.addLayer({
          id: layerId,
          type: 'heatmap',
          source: sourceId,
          paint: {
            'heatmap-weight': ['get', 'intensity'],
            'heatmap-intensity': 1,
            'heatmap-color': [
              'interpolate',
              ['linear'],
              ['heatmap-density'],
              0, 'rgba(0,0,0,0)',
              0.2, 'rgba(0,212,255,0.3)',
              0.4, 'rgba(124,58,237,0.5)',
              0.6, 'rgba(255,165,0,0.6)',
              0.8, 'rgba(255,68,68,0.7)',
              1, 'rgba(255,68,68,0.9)',
            ],
            'heatmap-radius': 30,
            'heatmap-opacity': 0.7,
          },
        })
      }
    } else {
      // Remove heatmap layer
      if (map.current.getLayer(layerId)) {
        map.current.removeLayer(layerId)
      }
      if (map.current.getSource(sourceId)) {
        map.current.removeSource(sourceId)
      }
    }
  }, [showHeatmap, properties, mapLoaded])

  if (!mapboxToken) {
    return (
      <div
        className="atlas-panel rounded-xl flex items-center justify-center"
        style={{ height }}
      >
        <div className="text-center text-atlas-muted">
          <Layers size={32} className="mx-auto mb-2 opacity-30" />
          <p className="text-sm">Mapbox token required</p>
          <p className="text-xs mt-1">Add your token in Settings → API Keys</p>
        </div>
      </div>
    )
  }

  return (
    <div
      className={clsx(
        'atlas-panel rounded-xl overflow-hidden relative transition-all',
        isExpanded && 'fixed inset-4 z-50'
      )}
      style={{ height: isExpanded ? 'auto' : height }}
    >
      {/* Map Controls */}
      <div className="absolute top-3 left-3 z-10 flex gap-2">
        <button
          onClick={() => setShowHeatmap(!showHeatmap)}
          className={clsx(
            'flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-xs font-medium transition-all backdrop-blur-sm',
            showHeatmap
              ? 'bg-atlas-accent text-atlas-dark'
              : 'bg-atlas-dark/80 text-atlas-text hover:bg-atlas-dark'
          )}
        >
          <Layers size={12} />
          Heatmap
        </button>
        <button
          className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-xs font-medium bg-atlas-dark/80 text-atlas-text hover:bg-atlas-dark transition-all backdrop-blur-sm"
        >
          <Filter size={12} />
          Filter
        </button>
      </div>

      {/* Expand button */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="absolute top-3 right-12 z-10 p-1.5 rounded-lg bg-atlas-dark/80 text-atlas-text hover:bg-atlas-dark transition-all backdrop-blur-sm"
      >
        {isExpanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
      </button>

      {/* Map container */}
      <div ref={mapContainer} className="w-full h-full" />

      {/* Legend */}
      <div className="absolute bottom-3 left-3 z-10 flex gap-3 px-3 py-2 rounded-lg bg-atlas-dark/90 backdrop-blur-sm text-[10px]">
        {Object.entries(STATUS_COLORS).map(([status, color]) => (
          <div key={status} className="flex items-center gap-1">
            <div
              className="w-2 h-2 rounded-full"
              style={{ backgroundColor: color }}
            />
            <span className="text-atlas-muted uppercase">{status}</span>
          </div>
        ))}
      </div>

      {/* Property count */}
      <div className="absolute bottom-3 right-3 z-10 px-2 py-1 rounded bg-atlas-dark/90 backdrop-blur-sm text-[10px] text-atlas-muted">
        {properties.length} properties
      </div>
    </div>
  )
}
