'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { BarChart3, MapPin, TrendingUp, AlertTriangle } from 'lucide-react'

const TOP_ZIPS = [
  { zip: '25301', label: 'Downtown Charleston', score: 94, equity: 68, delinquent: 142, trend: '+8%' },
  { zip: '25312', label: 'South Hills',         score: 87, equity: 72, delinquent: 89,  trend: '+5%' },
  { zip: '25302', label: 'West Side',           score: 82, equity: 61, delinquent: 76,  trend: '+3%' },
]

const MARKET_METRICS = [
  { label: 'Median Home Price',    value: '$142,500', delta: '+4.2% YoY' },
  { label: 'Days on Market',       value: '38',       delta: '-12 days YoY' },
  { label: 'Tax Delinquent Props', value: '1,847',    delta: 'County-wide' },
  { label: 'Avg Equity (Distress)', value: '64%',     delta: 'High-value zone' },
]

export function MarketIntel() {
  const { setPropertyFilter, propertyFilters } = useAtlasStore()
  const [activeZip, setActiveZip] = useState<string | null>(null)

  return (
    <div className="space-y-4 max-w-5xl">
      {/* Header */}
      <div className="atlas-panel p-4 rounded-xl border border-atlas-gold/20 bg-gradient-to-r from-atlas-gold/5 to-transparent">
        <div className="flex items-center gap-2 mb-1">
          <BarChart3 size={16} className="text-atlas-gold" />
          <h2 className="text-base font-bold text-white">Charleston, WV Metro Market Intelligence</h2>
        </div>
        <p className="text-xs text-atlas-muted">Distressed asset opportunity analysis · Updated hourly</p>
      </div>

      {/* Market Metrics */}
      <div className="grid grid-cols-4 gap-3">
        {MARKET_METRICS.map((m) => (
          <div key={m.label} className="atlas-panel p-3 rounded-xl">
            <div className="text-xl font-bold text-white font-mono">{m.value}</div>
            <div className="text-xs text-atlas-muted mt-0.5">{m.label}</div>
            <div className="text-[11px] text-atlas-gold mt-1">{m.delta}</div>
          </div>
        ))}
      </div>

      {/* Top ZIP Codes */}
      <div className="atlas-panel p-4 rounded-xl">
        <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <TrendingUp size={14} className="text-atlas-accent" />
          Top 3 ZIP Codes — High-Equity Distressed Assets
        </h3>
        <div className="space-y-3">
          {TOP_ZIPS.map((zip, i) => (
            <div
              key={zip.zip}
              onClick={() => { setActiveZip(zip.zip); setPropertyFilter('zipCode', zip.zip) }}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                activeZip === zip.zip
                  ? 'border-atlas-accent bg-atlas-accent/5'
                  : 'border-atlas-border bg-atlas-dark hover:border-atlas-accent/30'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                    i === 0 ? 'bg-atlas-gold/20 text-atlas-gold' :
                    i === 1 ? 'bg-atlas-accent/20 text-atlas-accent' :
                    'bg-atlas-purple/20 text-atlas-purple'
                  }`}>#{i + 1}</div>
                  <div>
                    <div className="font-semibold text-white flex items-center gap-1.5">
                      <MapPin size={12} className="text-atlas-muted" />
                      {zip.zip} · {zip.label}
                    </div>
                    <div className="text-xs text-atlas-muted">{zip.delinquent} tax-delinquent properties</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-atlas-accent font-mono">{zip.score}</div>
                  <div className="text-[10px] text-atlas-muted">Opportunity Score</div>
                </div>
              </div>

              {/* Score Bar */}
              <div className="w-full bg-atlas-border rounded-full h-1.5 mt-2">
                <div
                  className="h-1.5 rounded-full bg-gradient-to-r from-atlas-accent to-atlas-purple"
                  style={{ width: `${zip.score}%` }}
                />
              </div>

              <div className="flex gap-4 mt-2 text-xs text-atlas-muted">
                <span>Avg Equity: <span className="text-atlas-green">{zip.equity}%</span></span>
                <span>YoY Trend: <span className="text-atlas-gold">{zip.trend}</span></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Alert */}
      <div className="atlas-panel p-3 rounded-xl border border-atlas-gold/30 flex items-start gap-3">
        <AlertTriangle size={16} className="text-atlas-gold shrink-0 mt-0.5" />
        <div>
          <p className="text-xs font-semibold text-atlas-gold">Market Insight</p>
          <p className="text-xs text-atlas-muted mt-0.5">
            WV has one of the highest tax-delinquency rates in the US. ZIP 25301 shows a 94/100 opportunity score
            with 142 actionable leads. Recommend launching skip trace + SMS sequence immediately.
          </p>
        </div>
      </div>
    </div>
  )
}
