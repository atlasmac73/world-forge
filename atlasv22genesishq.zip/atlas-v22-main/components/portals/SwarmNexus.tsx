'use client'

import { useState, useEffect } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { 
  Zap, 
  Play, 
  Pause, 
  Square, 
  Target, 
  Users, 
  Bot, 
  Activity,
  CheckCircle,
  Loader2,
  AlertTriangle
} from 'lucide-react'
import { clsx } from 'clsx'
import toast from 'react-hot-toast'

interface SwarmAgent {
  id: string
  name: string
  code: string
  color: string
  credits: number
  selected: boolean
  status: 'idle' | 'running' | 'complete' | 'error'
}

interface SwarmNode {
  id: number
  status: 'idle' | 'alive' | 'done'
}

const SWARM_AGENTS: SwarmAgent[] = [
  { id: 'skip-tracer', name: 'Skip Tracer', code: 'ST', color: '#00d4ff', credits: 10, selected: true, status: 'idle' },
  { id: 'loi-drafter', name: 'LOI Drafter', code: 'LD', color: '#a78bfa', credits: 8, selected: true, status: 'idle' },
  { id: 'distress-scorer', name: 'Distress Scorer', code: 'DS', color: '#f59e0b', credits: 5, selected: true, status: 'idle' },
  { id: 'comps-analyst', name: 'Comps Analyst', code: 'CA', color: '#22c55e', credits: 12, selected: false, status: 'idle' },
  { id: 'sms-agent', name: 'SMS Agent', code: 'SA', color: '#ec4899', credits: 3, selected: false, status: 'idle' },
  { id: 'rehab-estimator', name: 'Rehab Estimator', code: 'RE', color: '#f97316', credits: 8, selected: false, status: 'idle' },
  { id: 'title-searcher', name: 'Title Searcher', code: 'TS', color: '#06b6d4', credits: 15, selected: false, status: 'idle' },
  { id: 'buyer-matcher', name: 'Buyer Matcher', code: 'BM', color: '#84cc16', credits: 6, selected: false, status: 'idle' },
]

const TARGETS = [
  { id: 'tax-delinquent-wv', label: 'WV Tax Delinquent (Top 100)', count: 100 },
  { id: 'pre-foreclosure-wv', label: 'WV Pre-Foreclosure (Top 50)', count: 50 },
  { id: 'high-equity-25301', label: 'High Equity ZIP 25301', count: 75 },
  { id: 'vacant-properties', label: 'Vacant Properties (All ZIPs)', count: 120 },
  { id: 'custom-list', label: 'Custom Lead List', count: 0 },
]

export function SwarmNexus() {
  const { wallet, consumeCredits, addAgentRun } = useAtlasStore()
  const [agents, setAgents] = useState(SWARM_AGENTS)
  const [target, setTarget] = useState(TARGETS[0].id)
  const [nodeCount, setNodeCount] = useState(50)
  const [swarmMode, setSwarmMode] = useState<'silent' | 'auto' | 'manual'>('auto')
  const [isDeploying, setIsDeploying] = useState(false)
  const [progress, setProgress] = useState(0)
  const [swarmStatus, setSwarmStatus] = useState<'idle' | 'running' | 'complete'>('idle')
  const [nodes, setNodes] = useState<SwarmNode[]>([])
  const [dialogue, setDialogue] = useState<string[]>([])

  const selectedAgents = agents.filter(a => a.selected)
  const totalCredits = selectedAgents.reduce((sum, a) => sum + a.credits, 0) * Math.ceil(nodeCount / 10)
  const targetData = TARGETS.find(t => t.id === target)

  function toggleAgent(id: string) {
    setAgents(agents.map(a => a.id === id ? { ...a, selected: !a.selected } : a))
  }

  function addDialogue(msg: string) {
    setDialogue(prev => [...prev.slice(-20), `[${new Date().toLocaleTimeString()}] ${msg}`])
  }

  async function deploySwarm() {
    if (selectedAgents.length === 0) {
      toast.error('Select at least one agent')
      return
    }

    if (!consumeCredits(totalCredits)) {
      toast.error('Insufficient credits')
      return
    }

    setIsDeploying(true)
    setSwarmStatus('running')
    setProgress(0)
    setDialogue([])

    // Initialize nodes
    const initialNodes = Array.from({ length: Math.min(nodeCount, 100) }, (_, i) => ({
      id: i,
      status: 'idle' as const
    }))
    setNodes(initialNodes)

    addDialogue('🚀 Swarm deployment initiated...')
    addDialogue(`📊 Target: ${targetData?.label} (${nodeCount} leads)`)
    addDialogue(`🤖 Agents: ${selectedAgents.map(a => a.code).join(', ')}`)

    // Log to agent runs
    const runId = crypto.randomUUID()
    addAgentRun({
      id: runId,
      agent_type: 'orchestrator',
      status: 'running',
      input: `Swarm: ${target} × ${nodeCount} leads × ${selectedAgents.length} agents`,
      credits_consumed: totalCredits,
      created_at: new Date().toISOString(),
    })

    // Simulate swarm deployment
    for (let i = 0; i < 100; i++) {
      await new Promise(r => setTimeout(r, 80))
      setProgress(i + 1)

      // Update node statuses
      const nodesAlive = Math.floor((i / 100) * initialNodes.length)
      setNodes(prev => prev.map((n, idx) => ({
        ...n,
        status: idx < nodesAlive ? (i > 90 ? 'done' : 'alive') : 'idle'
      })))

      // Update agent statuses
      if (i === 10) {
        setAgents(prev => prev.map(a => a.selected ? { ...a, status: 'running' } : a))
        addDialogue('🔍 Skip Tracer: Initializing owner lookup...')
      }
      if (i === 30) addDialogue('📝 LOI Drafter: Generating personalized letters...')
      if (i === 50) addDialogue('📊 Distress Scorer: Analyzing 47 signals...')
      if (i === 70) addDialogue('✅ Skip Tracer: Found 89% match rate')
      if (i === 85) addDialogue('📧 SMS Agent: Queued 42 outreach messages')
      if (i === 95) {
        setAgents(prev => prev.map(a => a.selected ? { ...a, status: 'complete' } : a))
        addDialogue('🎯 All agents complete. Results ready.')
      }
    }

    setSwarmStatus('complete')
    setIsDeploying(false)
    toast.success(`Swarm complete! ${nodeCount} leads processed.`)
  }

  function stopSwarm() {
    setIsDeploying(false)
    setSwarmStatus('idle')
    setProgress(0)
    setAgents(agents.map(a => ({ ...a, status: 'idle' })))
    addDialogue('⏹️ Swarm stopped by user')
    toast('Swarm stopped')
  }

  return (
    <div className="space-y-4 max-w-5xl">
      {/* Header */}
      <div className="atlas-panel p-4 rounded-xl border border-atlas-red/20 bg-gradient-to-r from-atlas-red/5 to-transparent">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-atlas-red/20 flex items-center justify-center">
              <Activity size={20} className="text-atlas-red" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Swarm Nexus</h2>
              <p className="text-xs text-atlas-muted">Multi-Agent Parallel Deployment Engine</p>
            </div>
          </div>
          <div className={clsx(
            'px-3 py-1.5 rounded-full text-xs font-bold font-mono',
            swarmStatus === 'running' ? 'bg-atlas-green/20 text-atlas-green animate-pulse' :
            swarmStatus === 'complete' ? 'bg-atlas-accent/20 text-atlas-accent' :
            'bg-atlas-red/20 text-atlas-red'
          )}>
            ● {swarmStatus.toUpperCase()}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Left Column - Configuration */}
        <div className="space-y-4">
          {/* Target Selection */}
          <div className="atlas-panel p-4 rounded-xl">
            <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
              <Target size={14} className="text-atlas-red" />
              Target List
            </h3>
            <select
              value={target}
              onChange={(e) => setTarget(e.target.value)}
              className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text focus:outline-none focus:border-atlas-accent"
            >
              {TARGETS.map(t => (
                <option key={t.id} value={t.id}>{t.label}</option>
              ))}
            </select>
          </div>

          {/* Node Count */}
          <div className="atlas-panel p-4 rounded-xl">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-atlas-muted">Lead Count</span>
              <span className="text-lg font-bold text-atlas-red font-mono">{nodeCount}</span>
            </div>
            <input
              type="range"
              min="10"
              max="500"
              step="10"
              value={nodeCount}
              onChange={(e) => setNodeCount(parseInt(e.target.value))}
              className="w-full accent-atlas-red"
            />
          </div>

          {/* Agent Selection */}
          <div className="atlas-panel p-4 rounded-xl">
            <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
              <Bot size={14} className="text-atlas-purple" />
              Select Agents
            </h3>
            <div className="flex flex-wrap gap-2">
              {agents.map(agent => (
                <button
                  key={agent.id}
                  onClick={() => toggleAgent(agent.id)}
                  className={clsx(
                    'w-11 h-11 rounded-lg text-xs font-bold transition-all relative',
                    agent.selected 
                      ? 'border-2 scale-105' 
                      : 'border border-atlas-border opacity-50 hover:opacity-80',
                    agent.status === 'running' && 'animate-pulse'
                  )}
                  style={{
                    backgroundColor: agent.selected ? `${agent.color}20` : 'transparent',
                    borderColor: agent.selected ? agent.color : undefined,
                    color: agent.color
                  }}
                  title={`${agent.name} (${agent.credits} credits)`}
                >
                  {agent.code}
                  {agent.status === 'complete' && (
                    <CheckCircle size={10} className="absolute -top-1 -right-1 text-atlas-green" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Cost Estimate */}
          <div className="atlas-panel p-4 rounded-xl">
            <div className="flex justify-between text-xs mb-2">
              <span className="text-atlas-muted">Estimated Cost</span>
              <span className="text-atlas-gold font-bold font-mono">{totalCredits} credits</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-atlas-muted">Your Balance</span>
              <span className={clsx(
                'font-mono font-bold',
                wallet.credits_limit_daily - wallet.credits_used_today >= totalCredits 
                  ? 'text-atlas-green' 
                  : 'text-atlas-red'
              )}>
                {wallet.credits_limit_daily - wallet.credits_used_today} credits
              </span>
            </div>
          </div>

          {/* Deploy Button */}
          <button
            onClick={isDeploying ? stopSwarm : deploySwarm}
            disabled={selectedAgents.length === 0}
            className={clsx(
              'w-full py-4 rounded-xl font-bold text-white transition-all flex items-center justify-center gap-2',
              isDeploying 
                ? 'bg-atlas-red hover:bg-atlas-red/80' 
                : 'bg-gradient-to-r from-atlas-red to-orange-500 hover:opacity-90',
              selectedAgents.length === 0 && 'opacity-50 cursor-not-allowed'
            )}
          >
            {isDeploying ? (
              <>
                <Square size={16} />
                STOP SWARM
              </>
            ) : (
              <>
                <Zap size={16} />
                DEPLOY SWARM
              </>
            )}
          </button>
        </div>

        {/* Middle Column - Progress & Nodes */}
        <div className="space-y-4">
          {/* Progress */}
          {isDeploying && (
            <div className="atlas-panel p-4 rounded-xl">
              <div className="flex justify-between text-xs mb-2">
                <span className="text-atlas-muted">Progress</span>
                <span className="text-atlas-red font-mono font-bold">{progress}%</span>
              </div>
              <div className="w-full bg-atlas-border rounded-full h-2">
                <div
                  className="h-2 rounded-full bg-gradient-to-r from-atlas-red to-orange-500 transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Node Grid */}
          <div className="atlas-panel p-4 rounded-xl">
            <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
              <Users size={14} className="text-atlas-accent" />
              Swarm Nodes ({nodes.filter(n => n.status !== 'idle').length}/{nodes.length})
            </h3>
            <div className="flex flex-wrap gap-1">
              {nodes.slice(0, 100).map(node => (
                <div
                  key={node.id}
                  className={clsx(
                    'w-2.5 h-2.5 rounded-full transition-all',
                    node.status === 'alive' && 'bg-atlas-green shadow-[0_0_6px_rgba(0,255,136,0.5)]',
                    node.status === 'done' && 'bg-atlas-accent',
                    node.status === 'idle' && 'bg-atlas-border'
                  )}
                />
              ))}
            </div>
          </div>

          {/* Agent Status */}
          <div className="atlas-panel p-4 rounded-xl">
            <h3 className="text-sm font-semibold text-atlas-text mb-3">Agent Status</h3>
            <div className="space-y-2">
              {agents.filter(a => a.selected).map(agent => (
                <div
                  key={agent.id}
                  className="flex items-center gap-2 p-2 rounded-lg bg-atlas-dark border border-atlas-border text-xs"
                >
                  <div
                    className={clsx(
                      'w-2 h-2 rounded-full',
                      agent.status === 'running' && 'bg-atlas-green animate-pulse',
                      agent.status === 'complete' && 'bg-atlas-accent',
                      agent.status === 'idle' && 'bg-atlas-muted'
                    )}
                  />
                  <span style={{ color: agent.color }}>{agent.name}</span>
                  <span className="ml-auto text-atlas-muted capitalize">{agent.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column - Dialogue */}
        <div className="atlas-panel p-4 rounded-xl">
          <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
            <Activity size={14} className="text-atlas-green" />
            Agent Dialogue
          </h3>
          <div className="bg-atlas-dark rounded-lg border border-atlas-border h-80 overflow-y-auto p-3 font-mono text-xs space-y-1">
            {dialogue.length === 0 ? (
              <span className="text-atlas-muted">Deploy a swarm to see real-time agent dialogue...</span>
            ) : (
              dialogue.map((msg, i) => (
                <div key={i} className="text-atlas-text leading-relaxed">{msg}</div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Swarm Mode */}
      <div className="atlas-panel p-4 rounded-xl">
        <div className="flex items-center gap-4">
          <span className="text-xs text-atlas-muted">Execution Mode:</span>
          {['silent', 'auto', 'manual'].map(mode => (
            <button
              key={mode}
              onClick={() => setSwarmMode(mode as typeof swarmMode)}
              className={clsx(
                'px-4 py-2 rounded-lg text-xs font-bold transition-all',
                swarmMode === mode
                  ? 'bg-atlas-accent text-atlas-dark'
                  : 'bg-atlas-dark border border-atlas-border text-atlas-muted hover:text-atlas-text'
              )}
            >
              {mode === 'silent' && '🔇'} {mode === 'auto' && '⚡'} {mode === 'manual' && '🎮'} {mode.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
