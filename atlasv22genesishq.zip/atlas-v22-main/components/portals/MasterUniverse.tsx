import { useState, useEffect, useRef } from "react";

// ─── DATA ─────────────────────────────────────────────────────────────────────

const PORTALS = [
  // CORE REAL ESTATE (v22 live)
  { id: 1, name: "Investor Portal", tier: "CORE", status: "live", version: "v22", desc: "Lead revenue product. Distress scoring, deal pipeline, investor CRM. 70% complete.", domain: "real-estate", priority: 1 },
  { id: 2, name: "Agent Portal", tier: "CORE", status: "live", version: "v22", desc: "MLS integration, buyer matching, commission tracking, lead assignment.", domain: "real-estate", priority: 1 },
  { id: 3, name: "Contractor Portal", tier: "CORE", status: "live", version: "v22", desc: "Rehab bids, job dispatch, contractor ratings, scope of work generator.", domain: "real-estate", priority: 1 },
  { id: 4, name: "Homeowner / PM Portal", tier: "CORE", status: "live", version: "v22", desc: "Property management, equity tracker, rental income, maintenance requests.", domain: "real-estate", priority: 1 },
  { id: 5, name: "War Room", tier: "CORE", status: "live", version: "v22", desc: "Live signal dashboard. All agent activity, deal flow, SMS replies, real-time ops.", domain: "operations", priority: 1 },
  { id: 6, name: "God Mode", tier: "OMEGA", status: "live", version: "v22", desc: "Shift+nasdrop unlock. Genesis Cycle control, 25-agent God Squad, mutation approval.", domain: "system", priority: 1 },
  { id: 7, name: "Agent Lab", tier: "CORE", status: "live", version: "v22", desc: "Build, test, and deploy AI agents. Agent factory. Spawn agents from agents.", domain: "ai", priority: 1 },
  { id: 8, name: "Swarm Nexus", tier: "CORE", status: "live", version: "v22", desc: "Multi-agent orchestration. Parallel swarm execution, task routing, agent mesh.", domain: "ai", priority: 1 },
  { id: 9, name: "Signal Stack", tier: "CORE", status: "live", version: "v22", desc: "AIN data feed. Tax delinquency signals, foreclosure alerts, market triggers.", domain: "intelligence", priority: 1 },
  { id: 10, name: "Comms Hub", tier: "CORE", status: "live", version: "v22", desc: "7-touch SMS/email sequences, call log, Twilio integration, outreach campaigns.", domain: "comms", priority: 1 },
  { id: 11, name: "SP6 Wallet", tier: "CORE", status: "live", version: "v22", desc: "Credit system, billing gate, Stripe, daily limits, plan management.", domain: "billing", priority: 1 },
  // EXPANSION (v23-v25 built)
  { id: 12, name: "Deal Navigator", tier: "EXPANSION", status: "built", version: "v22", desc: "GPS driving for dollars, Mapbox heatmaps, property pin drop, mobile-first.", domain: "real-estate", priority: 2 },
  { id: 13, name: "Market Intel", tier: "EXPANSION", status: "built", version: "v22", desc: "ZIP code scoring, neighborhood analytics, opportunity density maps.", domain: "intelligence", priority: 2 },
  { id: 14, name: "Voice Agent", tier: "EXPANSION", status: "built", version: "v22", desc: "Neural call AI. Inbound/outbound seller calls, qualification trees, transcripts.", domain: "comms", priority: 2 },
  { id: 15, name: "LOI Forge", tier: "EXPANSION", status: "planned", version: "v23", desc: "Automated Letter of Intent + Purchase Agreement generator. WV law compliant.", domain: "legal", priority: 2 },
  // v24-v28 PORTALS
  { id: 16, name: "Transmedia Studio", tier: "FRANCHISE", status: "planned", version: "v24", desc: "Book, film, music, YouTube content creation hub. ATLAS Code narrative engine.", domain: "media", priority: 3 },
  { id: 17, name: "World Information Hub", tier: "FRANCHISE", status: "planned", version: "v24", desc: "Global real estate intelligence. 195 countries. AIN worldwide flywheel.", domain: "intelligence", priority: 3 },
  { id: 18, name: "Franchise Territory Manager", tier: "FRANCHISE", status: "planned", version: "v25", desc: "Territory licensing, franchise onboarding, royalty tracking, territory maps.", domain: "franchise", priority: 3 },
  { id: 19, name: "Appalachian Intelligence Network", tier: "AIN", status: "planned", version: "v25", desc: "AIN flywheel. 55 WV counties → 50 states → global. Self-reinforcing data moat.", domain: "intelligence", priority: 2 },
  // GAME UNIVERSE PORTALS
  { id: 20, name: "ATLAS World Engine", tier: "METAVERSE", status: "vision", version: "v34", desc: "1:1 real-scale physics simulation. Real GPS coordinates → virtual world mesh. Unreal Engine 5 / custom physics.", domain: "game", priority: 4 },
  { id: 21, name: "Forza Mode Portal", tier: "METAVERSE", status: "vision", version: "v34", desc: "Real WV roads, terrain, elevation data → driveable game world. User-owned vehicles as NFT assets.", domain: "game", priority: 4 },
  { id: 22, name: "GTA Mode Portal", tier: "METAVERSE", status: "vision", version: "v34", desc: "Open-world Appalachia. Real property data as in-game real estate. Buy, develop, rent virtual properties.", domain: "game", priority: 4 },
  { id: 23, name: "Minecraft Mode Portal", tier: "METAVERSE", status: "vision", version: "v34", desc: "Voxel world from real terrain data. Build on real parcels. Cross-world object transfer protocol.", domain: "game", priority: 4 },
  { id: 24, name: "World Mesh Gateway", tier: "METAVERSE", status: "vision", version: "v34", desc: "Join other users via GPS location. Mesh worlds together. Send virtual objects between dimensions.", domain: "game", priority: 4 },
  { id: 25, name: "Reality Simulator", tier: "METAVERSE", status: "vision", version: "v34", desc: "1:1 physics engine. Real material properties, gravity, fluid dynamics, structural simulation.", domain: "game", priority: 4 },
  // SUPER APP PORTALS
  { id: 26, name: "Agent OS Super App", tier: "SUPER-APP", status: "planned", version: "v26", desc: "255+ AI agents. Full autonomous operations. Every business function automated.", domain: "ai", priority: 3 },
  { id: 27, name: "Neo4j Knowledge Graph", tier: "SUPER-APP", status: "planned", version: "v26", desc: "Graph intelligence. Property → owner → lien → contractor → buyer relationship mapping.", domain: "intelligence", priority: 3 },
  { id: 28, name: "LangGraph Genesis Engine", tier: "SUPER-APP", status: "built", version: "v23", desc: "State machine. SENSE→INTERPRET→MUTATE→SIMULATE→PROMOTE→LEARN cycle automation.", domain: "ai", priority: 2 },
  { id: 29, name: "n8n Automation Bridge", tier: "SUPER-APP", status: "planned", version: "v26", desc: "External workflow automation. Zapier-killer. n8n webhook orchestration.", domain: "operations", priority: 3 },
  { id: 30, name: "Stripe Revenue Engine", tier: "SUPER-APP", status: "built", version: "v22", desc: "SP6 credit billing, subscription management, franchise fee collection.", domain: "billing", priority: 2 },
  // REMAINING TO REACH 50
  { id: 31, name: "Skip Trace Command", tier: "INTELLIGENCE", status: "planned", version: "v25", desc: "Owner lookup, phone/email append, lien scan, bankruptcy check. AI-powered SKIPTRACE-X.", domain: "intelligence", priority: 2 },
  { id: 32, name: "Probate Intelligence", tier: "INTELLIGENCE", status: "planned", version: "v25", desc: "Automated probate notice scraping. Heir property detection. Compassionate outreach sequences.", domain: "intelligence", priority: 2 },
  { id: 33, name: "Tax Sale Monitor", tier: "INTELLIGENCE", status: "planned", version: "v25", desc: "County tax sale calendar. Bid tracking, redemption period alerts, title cure estimator.", domain: "intelligence", priority: 2 },
  { id: 34, name: "Pre-Foreclosure Radar", tier: "INTELLIGENCE", status: "planned", version: "v26", desc: "NOD → NOS → Auction pipeline. 90-day window optimization. Automated seller contact.", domain: "intelligence", priority: 3 },
  { id: 35, name: "Wholesale Exchange", tier: "MARKETPLACE", status: "planned", version: "v26", desc: "Buyer network marketplace. Deal assignment board. JV partner matching.", domain: "marketplace", priority: 3 },
  { id: 36, name: "MLS Data Bridge", tier: "MARKETPLACE", status: "planned", version: "v25", desc: "WVMLS RESO API. Live listing data. DOM alerts, price reduction detection.", domain: "marketplace", priority: 2 },
  { id: 37, name: "Rehab Command Center", tier: "OPERATIONS", status: "planned", version: "v25", desc: "REHAB-AI estimates. Contractor dispatch. Progress photo AI, scope of work builder.", domain: "operations", priority: 2 },
  { id: 38, name: "Title & Closing Hub", tier: "OPERATIONS", status: "planned", version: "v26", desc: "TITLEBOT. Title search, cloud cure, heir property, WV closing checklist.", domain: "legal", priority: 3 },
  { id: 39, name: "Compliance Sentinel", tier: "LEGAL", status: "planned", version: "v26", desc: "COMPLIANCE agent. WV licensing, Dodd-Frank, fair housing, CFPB monitoring.", domain: "legal", priority: 3 },
  { id: 40, name: "Deal Simulator Pro", tier: "FINANCE", status: "planned", version: "v25", desc: "Monte Carlo 1000-run deal modeling. Best/worst/expected case. Risk-adjusted ROI.", domain: "finance", priority: 2 },
  { id: 41, name: "Investor Relations Portal", tier: "FINANCE", status: "planned", version: "v27", desc: "Fund raise dashboard, LP reporting, deal flow for investors, K-1 document automation.", domain: "finance", priority: 3 },
  { id: 42, name: "ATLAS Analytics", tier: "INTELLIGENCE", status: "planned", version: "v27", desc: "Full platform analytics. Conversion funnels, credit ROI, agent performance benchmarking.", domain: "intelligence", priority: 3 },
  { id: 43, name: "Social Proof Engine", tier: "MARKETING", status: "planned", version: "v27", desc: "Auto-generate testimonials, deal case studies, before/after property content.", domain: "marketing", priority: 3 },
  { id: 44, name: "YouTube Intelligence Studio", tier: "MEDIA", status: "planned", version: "v27", desc: "AI-script WV real estate content. Auto-edit, upload, SEO optimize YouTube docs.", domain: "media", priority: 3 },
  { id: 45, name: "Book Engine", tier: "MEDIA", status: "planned", version: "v28", desc: "The ATLAS Code — 16-chapter book. AI co-author, publish to Amazon KDP, audiobook gen.", domain: "media", priority: 3 },
  { id: 46, name: "Music Anthem Studio", tier: "MEDIA", status: "planned", version: "v28", desc: "Original ATLAS brand anthem. AI composition, studio production, Spotify distribution.", domain: "media", priority: 4 },
  { id: 47, name: "Interactive Story Engine", tier: "FRANCHISE", status: "vision", version: "v30", desc: "The ATLAS Code as choose-your-own-adventure game. Real data integration into narrative.", domain: "game", priority: 4 },
  { id: 48, name: "Global Franchise HQ", tier: "FRANCHISE", status: "vision", version: "v32", desc: "195-country territory management. Multi-language, multi-currency, local compliance.", domain: "franchise", priority: 4 },
  { id: 49, name: "ATLAS Academy", tier: "EDUCATION", status: "planned", version: "v29", desc: "Training platform. Wholesaling courses, agent certification, Appalachian market mastery.", domain: "education", priority: 3 },
  { id: 50, name: "ZEUS Command Bridge", tier: "OMEGA", status: "vision", version: "v34", desc: "The apex. ZEUS orchestrates all 49 portals, all 255+ agents, all markets simultaneously.", domain: "system", priority: 4 },
];

const GAME_UNIVERSE = {
  concept: "ATLAS World — 1:1 Real-Scale Reality Engine",
  tagline: "Every real property. Every real road. Every real physics law. Fully playable.",
  modes: [
    {
      name: "FORZA MODE",
      icon: "🏎️",
      color: "#ff6b35",
      desc: "Real WV roads extracted from OSM + LIDAR elevation data. Every curve, grade, and surface rendered at 1:1 scale. User vehicles = NFT assets tradeable across worlds.",
      tech: ["Unreal Engine 5", "OpenStreetMap API", "USGS LIDAR", "Nanite terrain", "NFT vehicle ownership"],
      features: ["Real Appalachian roads", "Actual elevation physics", "Weather from real weather API", "Race on roads you own IRL", "Cross-world vehicle import"]
    },
    {
      name: "GTA MODE",
      icon: "🏙️",
      color: "#a855f7",
      desc: "Open-world Charleston WV and all 55 counties. Real property data feeds the game economy. Buy a distressed property IRL, own it in-game. Develop it in-game, sell IRL.",
      tech: ["Procedural building gen", "Real parcel data", "Supabase property sync", "Real economic data", "Player-owned real estate NFTs"],
      features: ["Real distressed properties as in-game buyables", "Virtual-to-real deal pipeline", "Gang territory = ZIP code market share", "Mission = real acquisition task", "AI-generated NPCs from real owner personas"]
    },
    {
      name: "MINECRAFT MODE",
      icon: "⬛",
      color: "#00ff88",
      desc: "Voxel Appalachia. Real terrain converted to voxel chunks. Build on real parcel coordinates. Objects you build can be exported to other worlds or minted as NFTs.",
      tech: ["Voxel terrain from USGS", "Real parcel boundary chunks", "Cross-world object protocol", "WebGL voxel engine", "NFT object minting"],
      features: ["Build on real land parcels", "Voxel rehab simulator", "Send objects between worlds", "Collaborative world building", "Real material physics properties"]
    },
    {
      name: "REALITY SIMULATOR",
      icon: "🌍",
      color: "#00d4ff",
      desc: "1:1 physics simulation engine. Real material properties (WV sandstone, clay, timber). Real fluid dynamics, structural load calculations, gravity. The most accurate real-world simulator ever built.",
      tech: ["Custom physics engine", "Real material property database", "Fluid dynamics GPU", "Structural FEM solver", "Real climate data integration"],
      features: ["1:1 scale accuracy", "Real material strength/failure", "Flood simulation (real topography)", "Structural load testing before building", "Environmental impact modeling"]
    }
  ],
  crossWorldProtocol: {
    name: "ATLAS World Mesh Protocol",
    desc: "Any user, anywhere on Earth, can join using their real GPS coordinates. Their real location becomes their spawn point. Worlds mesh together — your GTA character can walk into your friend's Minecraft world. Objects are transferable between all modes.",
    features: [
      "GPS = spawn coordinates (opt-in)",
      "Real-time user proximity meshing",
      "Object transfer protocol (OTP) — send any item between worlds",
      "Persistent inventory across all modes",
      "Real property ownership = in-game real estate deed",
      "Cross-world economy (one currency)",
    ]
  }
};

const TRANSMEDIA = {
  franchise: "THE ATLAS CODE — Transmedia Universe",
  tagline: "One origin story. Seven media formats. One interconnected world.",
  layers: [
    { id: 1, format: "📚 BOOK", title: "The ATLAS Code", status: "outlined", desc: "16-chapter origin story. Nalone's journey from Charleston WV to building a global AI real estate empire. Chapters 1-16 mapped. Amazon KDP self-publish + major publisher pitch.", milestone: "Q2 2026" },
    { id: 2, format: "🎬 FILM", title: "ATLAS: The Rise", status: "vision", desc: "Feature film adaptation. The AI revolution in Appalachian real estate. Documentary-hybrid style. Sundance → Netflix pipeline.", milestone: "2027" },
    { id: 3, format: "🎵 MUSIC", title: "ATLAS Brand Anthem", status: "planned", desc: "Original score + brand anthem. AI-assisted composition but human-produced. Theme music for all ATLAS products, trailers, and portals.", milestone: "Q3 2026" },
    { id: 4, format: "📺 YOUTUBE", title: "ATLAS Documentary Series", status: "planned", desc: "12-episode YouTube doc. Building ATLAS in public. Real deals, real code, real failures. 1M subscriber target Year 1.", milestone: "Q2 2026" },
    { id: 5, format: "🎮 GAME", title: "ATLAS World", status: "vision", desc: "The full game universe. Forza + GTA + Minecraft + Reality Simulator. Real-world property data. See Game Universe section.", milestone: "2027-2028" },
    { id: 6, format: "🎭 INTERACTIVE", title: "The ATLAS Code: Interactive", status: "vision", desc: "Choose-your-own-adventure game based on the book. Real data integration. Your real city becomes the game world. Decisions affect real deal outcomes.", milestone: "2028" },
    { id: 7, format: "🌐 FRANCHISE", title: "ATLAS Global Territories", status: "planned", desc: "195-country franchise expansion. Stage 1: WV → Stage 2: 50 states → Stage 3: Anglophone → Stage 4: Global. Each territory = transmedia bundle.", milestone: "2026-2030" },
  ]
};

const PATENTS = [
  { id: "ATLAS-2026-001", name: "Genesis Cycle™", desc: "Autopoietic self-improving AI system. SENSE→INTERPRET→MUTATE→SIMULATE→PROMOTE→LEARN.", status: "filed", date: "March 2026" },
  { id: "ATLAS-2026-002", name: "AI Skip Trace Intelligence System™", desc: "Multi-source owner location and contact intelligence using AI agent orchestration.", status: "filed", date: "March 2026" },
  { id: "ATLAS-2026-003", name: "Appalachian Intelligence Network™", desc: "Self-reinforcing regional real estate data flywheel with autonomous signal detection.", status: "filed", date: "March 2026" },
  { id: "ATLAS-2026-004", name: "Autopoietic Code Generation System™", desc: "AI system that generates, tests, deploys, and improves its own code autonomously.", status: "filed", date: "March 2026" },
];

const BUILD_ROADMAP = [
  { version: "v20", name: "GodMode Base", status: "complete", portals: 11, agents: 3, desc: "Foundation: Next.js, Supabase, Zustand, Zero-Trust Gateway" },
  { version: "v22", name: "God Squad Launch", status: "complete", portals: 12, agents: 25, desc: "25 God Squad agents, Genesis Cycle, Real Data APIs, Shift+nasdrop" },
  { version: "v23", name: "Genesis Live", status: "next", portals: 14, agents: 25, desc: "LangGraph Genesis Engine, LOI Forge, 15-minute heartbeat cron" },
  { version: "v24", name: "Transmedia Portal", status: "planned", portals: 16, agents: 40, desc: "Transmedia Studio + World Information Hub launch" },
  { version: "v25", name: "Data Dominance", status: "planned", portals: 22, agents: 60, desc: "MLS live, Skip Trace Command, Tax Sale Monitor, Rehab Command" },
  { version: "v26", name: "Super App", status: "planned", portals: 30, agents: 120, desc: "255 agent target, Neo4j graph, n8n automation, Agent OS" },
  { version: "v27", name: "Revenue Scale", status: "planned", portals: 36, agents: 180, desc: "Investor Relations, Analytics, Social Proof, YouTube Studio" },
  { version: "v28", name: "Media Empire", status: "planned", portals: 40, agents: 220, desc: "Book Engine, Music Studio, ATLAS Academy launch" },
  { version: "v30", name: "Franchise Global", status: "vision", portals: 44, agents: 255, desc: "Interactive Story Engine, 50-state expansion begins" },
  { version: "v32", name: "World Mesh Alpha", status: "vision", portals: 47, agents: 300, desc: "GPS world meshing, cross-user reality, object transfer protocol" },
  { version: "v34", name: "ATLAS WORLD", status: "vision", portals: 50, agents: 400, desc: "All 4 game modes live. 1:1 physics. 195 countries. ZEUS at the apex." },
];

const TIER_COLORS = {
  "CORE": "#00d4ff", "OMEGA": "#ffd700", "EXPANSION": "#00ff88",
  "FRANCHISE": "#a855f7", "AIN": "#ff6b35", "METAVERSE": "#ff4488",
  "SUPER-APP": "#3b82f6", "INTELLIGENCE": "#06b6d4", "MARKETPLACE": "#10b981",
  "OPERATIONS": "#f59e0b", "LEGAL": "#ef4444", "FINANCE": "#8b5cf6",
  "MARKETING": "#ec4899", "MEDIA": "#f97316", "EDUCATION": "#84cc16",
};

const STATUS_STYLES = {
  live:    { bg: "rgba(0,255,136,0.15)", border: "#00ff88", text: "#00ff88", label: "● LIVE" },
  built:   { bg: "rgba(0,212,255,0.15)", border: "#00d4ff", text: "#00d4ff", label: "✓ BUILT" },
  planned: { bg: "rgba(168,85,247,0.15)", border: "#a855f7", text: "#a855f7", label: "◎ PLANNED" },
  vision:  { bg: "rgba(255,100,135,0.1)", border: "#ff4488", text: "#ff4488", label: "◈ VISION" },
};

// ─── COMPONENTS ───────────────────────────────────────────────────────────────

function SectionHeader({ title, subtitle, accent = "#00d4ff", count }) {
  return (
    <div style={{ marginBottom: 24, borderLeft: `3px solid ${accent}`, paddingLeft: 16 }}>
      <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
        <h2 style={{ margin: 0, fontSize: 22, fontWeight: 900, color: "#fff", letterSpacing: 2, fontFamily: "'Space Mono', monospace", textTransform: "uppercase" }}>{title}</h2>
        {count !== undefined && (
          <span style={{ fontSize: 11, fontFamily: "monospace", color: accent, background: `${accent}20`, border: `1px solid ${accent}40`, borderRadius: 4, padding: "2px 8px" }}>{count}</span>
        )}
      </div>
      {subtitle && <p style={{ margin: "4px 0 0", fontSize: 12, color: "#64748b", fontFamily: "monospace" }}>{subtitle}</p>}
    </div>
  );
}

function PortalCard({ portal, onClick, isSelected }) {
  const tierColor = TIER_COLORS[portal.tier] || "#64748b";
  const statusStyle = STATUS_STYLES[portal.status];
  return (
    <div
      onClick={() => onClick(portal)}
      style={{
        background: isSelected ? `${tierColor}10` : "rgba(15,15,26,0.8)",
        border: `1px solid ${isSelected ? tierColor : "rgba(255,255,255,0.06)"}`,
        borderRadius: 10,
        padding: "12px 14px",
        cursor: "pointer",
        transition: "all 0.15s",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div style={{ position: "absolute", top: 0, right: 0, width: 60, height: 60, background: `radial-gradient(circle, ${tierColor}08, transparent)`, borderRadius: "0 10px 0 0" }} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ fontFamily: "monospace", fontSize: 10, color: "#334155", fontWeight: "bold" }}>#{portal.id.toString().padStart(2, "0")}</span>
          <span style={{ fontSize: 9, fontWeight: 800, color: tierColor, background: `${tierColor}15`, border: `1px solid ${tierColor}30`, borderRadius: 3, padding: "1px 6px", fontFamily: "monospace", letterSpacing: 0.5 }}>{portal.tier}</span>
        </div>
        <span style={{ fontSize: 9, fontWeight: 700, color: statusStyle.text, background: statusStyle.bg, border: `1px solid ${statusStyle.border}40`, borderRadius: 3, padding: "2px 6px", fontFamily: "monospace" }}>{statusStyle.label}</span>
      </div>
      <div style={{ fontSize: 13, fontWeight: 700, color: "#f1f5f9", marginBottom: 4, lineHeight: 1.3 }}>{portal.name}</div>
      <div style={{ fontSize: 10, color: "#475569", lineHeight: 1.5 }}>{portal.desc}</div>
      <div style={{ marginTop: 8, display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: 9, color: tierColor, fontFamily: "monospace" }}>{portal.version}</span>
        <span style={{ fontSize: 9, color: "#334155", fontFamily: "monospace" }}>{portal.domain}</span>
      </div>
    </div>
  );
}

function GameModeCard({ mode }) {
  return (
    <div style={{ background: "rgba(15,15,26,0.9)", border: `1px solid ${mode.color}30`, borderRadius: 14, padding: 20, position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: -20, right: -20, width: 100, height: 100, background: `radial-gradient(circle, ${mode.color}15, transparent)`, borderRadius: "50%" }} />
      <div style={{ fontSize: 32, marginBottom: 10 }}>{mode.icon}</div>
      <div style={{ fontSize: 16, fontWeight: 900, color: mode.color, fontFamily: "'Space Mono', monospace", letterSpacing: 1, marginBottom: 8 }}>{mode.name}</div>
      <div style={{ fontSize: 11, color: "#94a3b8", lineHeight: 1.6, marginBottom: 14 }}>{mode.desc}</div>
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 9, color: "#475569", fontFamily: "monospace", marginBottom: 6, letterSpacing: 1 }}>TECH STACK</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
          {mode.tech.map(t => (
            <span key={t} style={{ fontSize: 9, color: mode.color, background: `${mode.color}10`, border: `1px solid ${mode.color}20`, borderRadius: 3, padding: "2px 6px", fontFamily: "monospace" }}>{t}</span>
          ))}
        </div>
      </div>
      <div>
        <div style={{ fontSize: 9, color: "#475569", fontFamily: "monospace", marginBottom: 6, letterSpacing: 1 }}>FEATURES</div>
        {mode.features.map(f => (
          <div key={f} style={{ fontSize: 10, color: "#64748b", display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
            <span style={{ color: mode.color, fontSize: 8 }}>◆</span> {f}
          </div>
        ))}
      </div>
    </div>
  );
}

function RoadmapItem({ item, index }) {
  const statusColors = { complete: "#00ff88", next: "#ffd700", planned: "#a855f7", vision: "#ff4488" };
  const color = statusColors[item.status];
  return (
    <div style={{ display: "flex", gap: 16, position: "relative" }}>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flexShrink: 0 }}>
        <div style={{ width: 36, height: 36, borderRadius: "50%", background: `${color}20`, border: `2px solid ${color}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 900, color, fontFamily: "monospace", zIndex: 1 }}>{item.version.replace('v','')}</div>
        {index < BUILD_ROADMAP.length - 1 && <div style={{ width: 2, flex: 1, background: `linear-gradient(${color}40, transparent)`, minHeight: 24 }} />}
      </div>
      <div style={{ paddingBottom: 20, flex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <span style={{ fontSize: 14, fontWeight: 800, color: "#f1f5f9" }}>{item.name}</span>
          <span style={{ fontSize: 9, color, background: `${color}15`, border: `1px solid ${color}30`, borderRadius: 3, padding: "2px 8px", fontFamily: "monospace", textTransform: "uppercase" }}>{item.status}</span>
        </div>
        <div style={{ fontSize: 11, color: "#64748b", marginBottom: 6 }}>{item.desc}</div>
        <div style={{ display: "flex", gap: 12, fontSize: 10, fontFamily: "monospace" }}>
          <span style={{ color: "#00d4ff" }}>{item.portals} portals</span>
          <span style={{ color: "#a855f7" }}>{item.agents} agents</span>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function ATLASMasterUniverse() {
  const [activeTab, setActiveTab] = useState("portals");
  const [selectedPortal, setSelectedPortal] = useState(null);
  const [filterTier, setFilterTier] = useState("ALL");
  const [filterStatus, setFilterStatus] = useState("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [pulse, setPulse] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setPulse(p => p + 1), 2000);
    return () => clearInterval(t);
  }, []);

  const tabs = [
    { id: "portals", label: "50 PORTALS", count: 50 },
    { id: "game", label: "GAME UNIVERSE", count: 4 },
    { id: "transmedia", label: "TRANSMEDIA", count: 7 },
    { id: "patents", label: "PATENTS", count: 4 },
    { id: "roadmap", label: "ROADMAP", count: 11 },
  ];

  const allTiers = ["ALL", ...Array.from(new Set(PORTALS.map(p => p.tier)))];
  const allStatuses = ["ALL", "live", "built", "planned", "vision"];

  const filteredPortals = PORTALS.filter(p => {
    if (filterTier !== "ALL" && p.tier !== filterTier) return false;
    if (filterStatus !== "ALL" && p.status !== filterStatus) return false;
    if (searchQuery && !p.name.toLowerCase().includes(searchQuery.toLowerCase()) && !p.desc.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const stats = {
    live: PORTALS.filter(p => p.status === "live").length,
    built: PORTALS.filter(p => p.status === "built").length,
    planned: PORTALS.filter(p => p.status === "planned").length,
    vision: PORTALS.filter(p => p.status === "vision").length,
  };

  return (
    <div style={{ minHeight: "100vh", background: "#080810", color: "#e2e8f0", fontFamily: "'Inter', system-ui, sans-serif", backgroundImage: "linear-gradient(rgba(0,212,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(0,212,255,0.02) 1px, transparent 1px)", backgroundSize: "40px 40px" }}>

      {/* HEADER */}
      <div style={{ borderBottom: "1px solid rgba(0,212,255,0.1)", padding: "20px 28px", position: "sticky", top: 0, background: "rgba(8,8,16,0.95)", backdropFilter: "blur(12px)", zIndex: 100 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", maxWidth: 1400, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg, #00d4ff, #a855f7)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 0 30px rgba(0,212,255,0.3)", fontSize: 22 }}>⚡</div>
            <div>
              <div style={{ fontSize: 22, fontWeight: 900, letterSpacing: 4, fontFamily: "'Space Mono', monospace", background: "linear-gradient(135deg, #00d4ff, #a855f7, #ffd700)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>ATLAS OS</div>
              <div style={{ fontSize: 10, color: "#475569", fontFamily: "monospace", letterSpacing: 2 }}>MASTER UNIVERSE DOCUMENT — v22 → v34</div>
            </div>
          </div>
          {/* Live stats */}
          <div style={{ display: "flex", gap: 16 }}>
            {[
              { label: "LIVE", value: stats.live, color: "#00ff88" },
              { label: "BUILT", value: stats.built, color: "#00d4ff" },
              { label: "PLANNED", value: stats.planned, color: "#a855f7" },
              { label: "VISION", value: stats.vision, color: "#ff4488" },
              { label: "TOTAL", value: 50, color: "#ffd700" },
            ].map(s => (
              <div key={s.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 20, fontWeight: 900, color: s.color, fontFamily: "monospace" }}>{s.value}</div>
                <div style={{ fontSize: 8, color: "#334155", fontFamily: "monospace", letterSpacing: 1 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* TABS */}
      <div style={{ borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "0 28px", maxWidth: 1400, margin: "0 auto" }}>
        <div style={{ display: "flex", gap: 4 }}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                background: "none", border: "none", cursor: "pointer", padding: "14px 20px",
                fontSize: 11, fontFamily: "monospace", fontWeight: 700, letterSpacing: 1.5,
                color: activeTab === tab.id ? "#00d4ff" : "#475569",
                borderBottom: activeTab === tab.id ? "2px solid #00d4ff" : "2px solid transparent",
                transition: "all 0.15s", whiteSpace: "nowrap",
              }}
            >
              {tab.label} <span style={{ opacity: 0.6, fontSize: 9 }}>({tab.count})</span>
            </button>
          ))}
        </div>
      </div>

      {/* CONTENT */}
      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "28px 28px" }}>

        {/* ── PORTALS TAB ─────────────────────────────────────────────────── */}
        {activeTab === "portals" && (
          <div>
            <SectionHeader title="The 50-Portal ATLAS Universe" subtitle="From v22 (live today) → v34 (the apex). Every portal, every version, every domain." accent="#00d4ff" count="50 portals" />

            {/* Filters */}
            <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap", alignItems: "center" }}>
              <input
                placeholder="Search portals..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, padding: "8px 14px", color: "#e2e8f0", fontSize: 12, fontFamily: "monospace", outline: "none", width: 200 }}
              />
              <div style={{ display: "flex", gap: 4 }}>
                {allStatuses.map(s => (
                  <button key={s} onClick={() => setFilterStatus(s)}
                    style={{ background: filterStatus === s ? `${STATUS_STYLES[s]?.bg || "rgba(255,255,255,0.1)"}` : "transparent", border: `1px solid ${filterStatus === s ? (STATUS_STYLES[s]?.border || "#fff") : "rgba(255,255,255,0.1)"}`, borderRadius: 5, padding: "4px 10px", cursor: "pointer", fontSize: 9, fontFamily: "monospace", fontWeight: 700, color: filterStatus === s ? (STATUS_STYLES[s]?.text || "#fff") : "#475569", letterSpacing: 0.5 }}>
                    {s.toUpperCase()}
                  </button>
                ))}
              </div>
              <div style={{ fontSize: 11, color: "#475569", fontFamily: "monospace", marginLeft: "auto" }}>{filteredPortals.length} portals shown</div>
            </div>

            {/* Portal grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 12 }}>
              {filteredPortals.map(portal => (
                <PortalCard key={portal.id} portal={portal} onClick={setSelectedPortal} isSelected={selectedPortal?.id === portal.id} />
              ))}
            </div>

            {/* Selected portal detail */}
            {selectedPortal && (
              <div style={{ marginTop: 24, background: `${TIER_COLORS[selectedPortal.tier]}08`, border: `1px solid ${TIER_COLORS[selectedPortal.tier]}30`, borderRadius: 14, padding: 24 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontSize: 9, fontFamily: "monospace", color: TIER_COLORS[selectedPortal.tier], marginBottom: 6, letterSpacing: 2 }}>PORTAL #{selectedPortal.id.toString().padStart(2, "0")} — {selectedPortal.tier}</div>
                    <div style={{ fontSize: 22, fontWeight: 900, color: "#f8fafc", marginBottom: 8 }}>{selectedPortal.name}</div>
                    <div style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.7, maxWidth: 600 }}>{selectedPortal.desc}</div>
                  </div>
                  <button onClick={() => setSelectedPortal(null)} style={{ background: "none", border: "none", color: "#475569", cursor: "pointer", fontSize: 20 }}>✕</button>
                </div>
                <div style={{ display: "flex", gap: 20, marginTop: 16, fontSize: 11, fontFamily: "monospace" }}>
                  <span style={{ color: "#475569" }}>Version: <span style={{ color: TIER_COLORS[selectedPortal.tier] }}>{selectedPortal.version}</span></span>
                  <span style={{ color: "#475569" }}>Domain: <span style={{ color: "#e2e8f0" }}>{selectedPortal.domain}</span></span>
                  <span style={{ color: "#475569" }}>Priority: <span style={{ color: "#ffd700" }}>P{selectedPortal.priority}</span></span>
                  <span style={{ color: STATUS_STYLES[selectedPortal.status].text }}>{STATUS_STYLES[selectedPortal.status].label}</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── GAME UNIVERSE TAB ──────────────────────────────────────────── */}
        {activeTab === "game" && (
          <div>
            <SectionHeader title="ATLAS World — Game Universe" subtitle="1:1 real-scale physics. Real GPS. Real property data. Four interconnected game worlds." accent="#ff4488" />

            {/* Concept banner */}
            <div style={{ background: "linear-gradient(135deg, rgba(255,68,136,0.1), rgba(0,212,255,0.1))", border: "1px solid rgba(255,68,136,0.2)", borderRadius: 14, padding: 24, marginBottom: 28 }}>
              <div style={{ fontSize: 20, fontWeight: 900, fontFamily: "'Space Mono', monospace", color: "#fff", marginBottom: 8 }}>{GAME_UNIVERSE.concept}</div>
              <div style={{ fontSize: 14, color: "#ff4488", fontStyle: "italic", marginBottom: 16 }}>"{GAME_UNIVERSE.tagline}"</div>
              <div style={{ background: "rgba(0,0,0,0.3)", borderRadius: 10, padding: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#ffd700", fontFamily: "monospace", letterSpacing: 2, marginBottom: 12 }}>ATLAS WORLD MESH PROTOCOL</div>
                <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 12 }}>{GAME_UNIVERSE.crossWorldProtocol.desc}</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                  {GAME_UNIVERSE.crossWorldProtocol.features.map(f => (
                    <div key={f} style={{ fontSize: 11, color: "#64748b", display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ color: "#ffd700", fontSize: 8 }}>◆</span> {f}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
              {GAME_UNIVERSE.modes.map(mode => <GameModeCard key={mode.name} mode={mode} />)}
            </div>

            {/* Cross-world object protocol diagram */}
            <div style={{ marginTop: 28, background: "rgba(15,15,26,0.9)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 14, padding: 24 }}>
              <div style={{ fontSize: 13, fontWeight: 700, fontFamily: "monospace", color: "#ffd700", letterSpacing: 2, marginBottom: 16 }}>CROSS-WORLD OBJECT TRANSFER PROTOCOL</div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, flexWrap: "wrap" }}>
                {["🏎️ FORZA", "🏙️ GTA", "⬛ MINECRAFT", "🌍 REALITY"].map((mode, i, arr) => (
                  <div key={mode} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ background: "rgba(255,215,0,0.1)", border: "1px solid rgba(255,215,0,0.3)", borderRadius: 8, padding: "10px 16px", fontSize: 12, fontWeight: 700, color: "#ffd700", fontFamily: "monospace" }}>{mode}</div>
                    {i < arr.length - 1 && <div style={{ fontSize: 16, color: "#334155" }}>⇄</div>}
                  </div>
                ))}
              </div>
              <div style={{ textAlign: "center", marginTop: 16, fontSize: 11, color: "#475569", fontFamily: "monospace" }}>
                Any object created in any world can be exported, traded, or imported into any other world.<br />
                Real property ownership = in-game real estate deed valid across ALL modes.
              </div>
            </div>
          </div>
        )}

        {/* ── TRANSMEDIA TAB ─────────────────────────────────────────────── */}
        {activeTab === "transmedia" && (
          <div>
            <SectionHeader title="The ATLAS Code — Transmedia Franchise" subtitle="One story. Seven formats. One interconnected universe spanning real estate → entertainment → technology." accent="#f97316" />

            <div style={{ background: "linear-gradient(135deg, rgba(249,115,22,0.1), rgba(168,85,247,0.1))", border: "1px solid rgba(249,115,22,0.2)", borderRadius: 14, padding: 24, marginBottom: 28 }}>
              <div style={{ fontSize: 24, fontWeight: 900, color: "#fff", fontFamily: "'Space Mono', monospace", marginBottom: 6 }}>{TRANSMEDIA.franchise}</div>
              <div style={{ fontSize: 13, color: "#f97316", fontStyle: "italic" }}>"{TRANSMEDIA.tagline}"</div>
            </div>

            <div style={{ display: "grid", gap: 12 }}>
              {TRANSMEDIA.layers.map((layer, i) => (
                <div key={layer.id} style={{ background: "rgba(15,15,26,0.8)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 20, display: "flex", gap: 20, alignItems: "flex-start" }}>
                  <div style={{ width: 48, height: 48, borderRadius: 12, background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>{layer.format.split(" ")[0]}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4 }}>
                      <div>
                        <span style={{ fontSize: 10, fontFamily: "monospace", color: "#475569", marginRight: 8 }}>{layer.format.split(" ").slice(1).join(" ")}</span>
                        <span style={{ fontSize: 15, fontWeight: 800, color: "#f8fafc" }}>{layer.title}</span>
                      </div>
                      <span style={{ fontSize: 9, fontFamily: "monospace", color: STATUS_STYLES[layer.status]?.text || "#fff", background: STATUS_STYLES[layer.status]?.bg, border: `1px solid ${STATUS_STYLES[layer.status]?.border}40`, borderRadius: 3, padding: "2px 8px" }}>{layer.status.toUpperCase()}</span>
                    </div>
                    <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.6, marginBottom: 8 }}>{layer.desc}</div>
                    <div style={{ fontSize: 10, fontFamily: "monospace", color: "#ffd700" }}>🎯 {layer.milestone}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* The interconnection */}
            <div style={{ marginTop: 28, background: "rgba(15,15,26,0.9)", border: "1px solid rgba(249,115,22,0.2)", borderRadius: 14, padding: 24 }}>
              <div style={{ fontSize: 13, fontWeight: 700, fontFamily: "monospace", color: "#f97316", letterSpacing: 2, marginBottom: 16 }}>HOW IT ALL CONNECTS</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, fontSize: 12, color: "#64748b", lineHeight: 1.7 }}>
                <div>
                  <div style={{ color: "#f97316", fontWeight: 700, marginBottom: 8, fontFamily: "monospace" }}>REAL ESTATE → MEDIA</div>
                  Real deals closed on the ATLAS platform become chapters in the book, scenes in the film, missions in the game, and episodes in the YouTube series. Every acquisition is a story beat.
                </div>
                <div>
                  <div style={{ color: "#a855f7", fontWeight: 700, marginBottom: 8, fontFamily: "monospace" }}>MEDIA → REAL ESTATE</div>
                  Book readers become platform users. Game players discover real distressed properties. YouTube viewers join franchise territories. Every media touchpoint feeds the acquisition funnel.
                </div>
                <div>
                  <div style={{ color: "#00ff88", fontWeight: 700, marginBottom: 8, fontFamily: "monospace" }}>GAME → REAL WORLD</div>
                  In-game real estate transactions mirror real property opportunities. A player buys a virtual distressed house → gets connected to the real ATLAS deal pipeline for that actual property.
                </div>
                <div>
                  <div style={{ color: "#ffd700", fontWeight: 700, marginBottom: 8, fontFamily: "monospace" }}>FRANCHISE → GLOBAL</div>
                  Every territory expansion (WV → 50 states → 195 countries) unlocks new game regions, new book chapters, new YouTube markets, new music in local languages.
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── PATENTS TAB ────────────────────────────────────────────────── */}
        {activeTab === "patents" && (
          <div>
            <SectionHeader title="USPTO Provisional Patents" subtitle="4 filed March 2026. Sole inventor: Nalone Stallings. Micro-entity status. Dockets ATLAS-2026-001 through 004." accent="#00ff88" count="4 filed" />
            <div style={{ display: "grid", gap: 14 }}>
              {PATENTS.map(patent => (
                <div key={patent.id} style={{ background: "rgba(0,255,136,0.03)", border: "1px solid rgba(0,255,136,0.15)", borderRadius: 12, padding: 22 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div style={{ fontSize: 10, fontFamily: "monospace", color: "#00ff88", letterSpacing: 2 }}>{patent.id}</div>
                    <div style={{ display: "flex", gap: 10, fontSize: 10, fontFamily: "monospace" }}>
                      <span style={{ color: "#00ff88", background: "rgba(0,255,136,0.1)", border: "1px solid rgba(0,255,136,0.3)", borderRadius: 3, padding: "2px 8px" }}>✓ {patent.status.toUpperCase()}</span>
                      <span style={{ color: "#475569" }}>{patent.date}</span>
                    </div>
                  </div>
                  <div style={{ fontSize: 18, fontWeight: 900, color: "#f8fafc", marginBottom: 8 }}>{patent.name}</div>
                  <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.7 }}>{patent.desc}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 20, background: "rgba(255,215,0,0.05)", border: "1px solid rgba(255,215,0,0.15)", borderRadius: 12, padding: 20, fontSize: 12, color: "#64748b", lineHeight: 1.7 }}>
              <div style={{ color: "#ffd700", fontWeight: 700, fontFamily: "monospace", marginBottom: 8, letterSpacing: 1 }}>NEXT: 500 PATENTABLE SKILLS</div>
              Your Drive contains "500 Patentable AI Agent Skills COMPLETE" — these should be clustered into continuation patents and design patents as ATLAS scales. Each of the 4 provisionals should be converted to full utility patents within 12 months of filing.
            </div>
          </div>
        )}

        {/* ── ROADMAP TAB ─────────────────────────────────────────────────── */}
        {activeTab === "roadmap" && (
          <div>
            <SectionHeader title="Build Roadmap: v22 → v34" subtitle="From 12 live portals today to the full 50-portal ATLAS World. Every version mapped." accent="#a855f7" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0, maxWidth: 900 }}>
              {BUILD_ROADMAP.map((item, i) => <RoadmapItem key={item.version} item={item} index={i} />)}
            </div>

            {/* The ZEUS vision */}
            <div style={{ marginTop: 28, background: "linear-gradient(135deg, rgba(255,215,0,0.08), rgba(255,68,136,0.08))", border: "1px solid rgba(255,215,0,0.25)", borderRadius: 14, padding: 28, textAlign: "center" }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>⚡</div>
              <div style={{ fontSize: 22, fontWeight: 900, fontFamily: "'Space Mono', monospace", color: "#ffd700", letterSpacing: 3, marginBottom: 8 }}>ZEUS AT THE APEX</div>
              <div style={{ fontSize: 13, color: "#94a3b8", maxWidth: 600, margin: "0 auto", lineHeight: 1.8 }}>
                At v34, ZEUS orchestrates all 50 portals, all 400+ agents, all 195 country markets, all 4 game worlds, and the full transmedia franchise — simultaneously, autonomously, within a $5/cycle budget kill switch. The ultimate autopoietic real estate intelligence platform.
              </div>
              <div style={{ marginTop: 20, display: "flex", justifyContent: "center", gap: 20, fontSize: 12, fontFamily: "monospace" }}>
                <span style={{ color: "#00d4ff" }}>50 portals</span>
                <span style={{ color: "#a855f7" }}>400+ agents</span>
                <span style={{ color: "#ffd700" }}>195 countries</span>
                <span style={{ color: "#ff4488" }}>4 game worlds</span>
                <span style={{ color: "#00ff88" }}>1 genesis cycle</span>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
