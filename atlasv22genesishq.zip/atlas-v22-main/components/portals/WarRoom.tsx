'use client'

import { useState, useEffect } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { 
  Activity, 
  AlertTriangle, 
  Bell, 
  CheckCircle, 
  Clock, 
  DollarSign, 
  Home, 
  MessageSquare, 
  Phone, 
  TrendingUp, 
  Users,
  Zap,
  Target,
  Radio
} from 'lucide-react'
import { clsx } from 'clsx'

interface Signal {
  id: string
  type: 'lead' | 'call' | 'sms' | 'agent' | 'alert'
  title: string
  subtitle: string
  time: string
  priority: 'high' | 'medium' | 'low'
  actionable?: boolean
}

interface MetricCard {
  label: string
  value: string
  delta: string
  trend: 'up' | 'down' | 'neutral'
  icon: React.ReactNode
}

const LIVE_SIGNALS: Signal[] = [
  { id: '1', type: 'lead', title: '🔥 Hot Lead Detected', subtitle: '412 Elm St — 92 distress score', time: '2m ago', priority: 'high', actionable: true },
  { id: '2', type: 'sms', title: '📱 SMS Reply Received', subtitle: 'John Smith: "Yes, I\'m interested"', time: '5m ago', priority: 'high', actionable: true },
  { id: '3', type: 'agent', title: '🤖 Investigator Complete', subtitle: '3 new properties analyzed', time: '8m ago', priority: 'medium' },
  { id: '4', type: 'call', title: '📞 Missed Call', subtitle: '+1 (304) 555-0142', time: '12m ago', priority: 'medium', actionable: true },
  { id: '5', type: 'alert', title: '⚠️ Credit Warning', subtitle: '23% daily credits remaining', time: '15m ago', priority: 'low' },
  { id: '6', type: 'lead', title: '📊 New Tax Delinquent List', subtitle: '47 properties in ZIP 25301', time: '1h ago', priority: 'medium' },
]

const METRICS: MetricCard[] = [
  { label: 'Active Leads', value: '142', delta: '+12 today', trend: 'up', icon: <Users size={18} /> },
  { label: 'Response Rate', value: '34%', delta: '+8% week', trend: 'up', icon: <MessageSquare size={18} /> },
  { label: 'Deals in Pipeline', value: '$2.4M', delta: '6 properties', trend: 'up', icon: <DollarSign size={18} /> },
  { label: 'Agent Uptime', value: '99.2%', delta: 'All systems', trend: 'neutral', icon: <Activity size={18} /> },
]

const ACTIVE_OPERATIONS = [
  { id: '1', name: 'Skip Trace Batch', target: 'ZIP 25301', progress: 78, status: 'running', agent: 'ST' },
  { id: '2', name: 'SMS Sequence #7', target: '23 leads', progress: 45, status: 'running', agent: 'SA' },
  { id: '3', name: 'Comps Analysis', target: '412 Elm St', progress: 100, status: 'complete', agent: 'CA' },
  { id: '4', name: 'LOI Generation', target: '5 properties', progress: 62, status: 'running', agent: 'LD' },
]

export function WarRoom() {
  const { wallet, agentRuns, openModal } = useAtlasStore()
  const [signals, setSignals] = useState(LIVE_SIGNALS)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [isLive, setIsLive] = useState(true)

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  // Simulate live signal updates
  useEffect(() => {
    if (!isLive) return
    const interval = setInterval(() => {
      const newSignal: Signal = {
        id: Date.now().toString(),
        type: ['lead', 'sms', 'agent', 'call'][Math.floor(Math.random() * 4)] as Signal['type'],
        title: ['🔥 New Hot Lead', '📱 SMS Reply', '🤖 Agent Complete', '📞 Incoming Call'][Math.floor(Math.random() * 4)],
        subtitle: 'Real-time update',
        time: 'Just now',
        priority: ['high', 'medium', 'low'][Math.floor(Math.random() * 3)] as Signal['priority'],
        actionable: Math.random() > 0.5
      }
      setSignals(prev => [newSignal, ...prev.slice(0, 9)])
    }, 15000)
    return () => clearInterval(interval)
  }, [isLive])

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="atlas-panel p-4 rounded-xl border border-atlas-gold/20 bg-gradient-to-r from-atlas-gold/5 to-transparent">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-atlas-gold/20 flex items-center justify-center animate-pulse">
              <Radio size={20} className="text-atlas-gold" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">War Room</h2>
              <p className="text-xs text-atlas-muted">Real-Time Operations Center</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-2xl font-bold text-atlas-gold font-mono">
                {currentTime.toLocaleTimeString()}
              </div>
              <div className="text-xs text-atlas-muted">
                {currentTime.toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
              </div>
            </div>
            <button
              onClick={() => setIsLive(!isLive)}
              className={clsx(
                'px-3 py-1.5 rounded-full text-xs font-bold font-mono flex items-center gap-2',
                isLive 
                  ? 'bg-atlas-green/20 text-atlas-green border border-atlas-green/30' 
                  : 'bg-atlas-muted/20 text-atlas-muted border border-atlas-border'
              )}
            >
              <span className={clsx('w-2 h-2 rounded-full', isLive ? 'bg-atlas-green animate-pulse' : 'bg-atlas-muted')} />
              {isLive ? 'LIVE' : 'PAUSED'}
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-4 gap-3">
        {METRICS.map(metric => (
          <div key={metric.label} className="atlas-panel p-4 rounded-xl">
            <div className="flex items-start justify-between mb-2">
              <span className={clsx(
                'p-2 rounded-lg',
                metric.trend === 'up' ? 'bg-atlas-green/20 text-atlas-green' :
                metric.trend === 'down' ? 'bg-atlas-red/20 text-atlas-red' :
                'bg-atlas-accent/20 text-atlas-accent'
              )}>
                {metric.icon}
              </span>
              <TrendingUp size={14} className={clsx(
                metric.trend === 'up' ? 'text-atlas-green' :
                metric.trend === 'down' ? 'text-atlas-red rotate-180' :
                'text-atlas-muted'
              )} />
            </div>
            <div className="text-2xl font-bold text-white font-mono">{metric.value}</div>
            <div className="text-xs text-atlas-muted mt-0.5">{metric.label}</div>
            <div className={clsx(
              'text-[11px] mt-1',
              metric.trend === 'up' ? 'text-atlas-green' :
              metric.trend === 'down' ? 'text-atlas-red' :
              'text-atlas-muted'
            )}>
              {metric.delta}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Live Signals */}
        <div className="col-span-2 atlas-panel p-4 rounded-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-atlas-text flex items-center gap-2">
              <Bell size={14} className="text-atlas-accent" />
              Live Signals
            </h3>
            <span className="text-xs text-atlas-muted">{signals.length} active</span>
          </div>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {signals.map(signal => (
              <div
                key={signal.id}
                className={clsx(
                  'flex items-center gap-3 p-3 rounded-lg border transition-all',
                  signal.priority === 'high' 
                    ? 'bg-atlas-red/5 border-atlas-red/30' 
                    : 'bg-atlas-dark border-atlas-border hover:border-atlas-accent/30'
                )}
              >
                <div className={clsx(
                  'w-2 h-2 rounded-full shrink-0',
                  signal.priority === 'high' ? 'bg-atlas-red animate-pulse' :
                  signal.priority === 'medium' ? 'bg-atlas-gold' :
                  'bg-atlas-muted'
                )} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-atlas-text font-medium">{signal.title}</div>
                  <div className="text-xs text-atlas-muted truncate">{signal.subtitle}</div>
                </div>
                <div className="text-[10px] text-atlas-muted shrink-0">{signal.time}</div>
                {signal.actionable && (
                  <button className="px-2 py-1 rounded text-[10px] bg-atlas-accent/20 text-atlas-accent hover:bg-atlas-accent/30 transition-all">
                    Action
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Active Operations */}
        <div className="atlas-panel p-4 rounded-xl">
          <h3 className="text-sm font-semibold text-atlas-text mb-4 flex items-center gap-2">
            <Activity size={14} className="text-atlas-purple" />
            Active Operations
          </h3>
          <div className="space-y-3">
            {ACTIVE_OPERATIONS.map(op => (
              <div key={op.id} className="p-3 rounded-lg bg-atlas-dark border border-atlas-border">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-atlas-purple/20 text-atlas-purple text-[10px] font-bold flex items-center justify-center">
                      {op.agent}
                    </span>
                    <span className="text-xs text-atlas-text font-medium">{op.name}</span>
                  </div>
                  {op.status === 'complete' ? (
                    <CheckCircle size={14} className="text-atlas-green" />
                  ) : (
                    <span className="text-[10px] text-atlas-gold">{op.progress}%</span>
                  )}
                </div>
                <div className="text-[10px] text-atlas-muted mb-2">{op.target}</div>
                <div className="w-full bg-atlas-border rounded-full h-1">
                  <div
                    className={clsx(
                      'h-1 rounded-full transition-all',
                      op.status === 'complete' ? 'bg-atlas-green' : 'bg-atlas-purple'
                    )}
                    style={{ width: `${op.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="atlas-panel p-4 rounded-xl">
        <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <Zap size={14} className="text-atlas-gold" />
          Quick Actions
        </h3>
        <div className="grid grid-cols-6 gap-2">
          {[
            { label: 'Call Next Lead', icon: <Phone size={16} />, color: 'atlas-green' },
            { label: 'Send SMS Blast', icon: <MessageSquare size={16} />, color: 'atlas-accent' },
            { label: 'Run Skip Trace', icon: <Users size={16} />, color: 'atlas-purple' },
            { label: 'Deploy Swarm', icon: <Activity size={16} />, color: 'atlas-red' },
            { label: 'View Heatmap', icon: <Target size={16} />, color: 'atlas-gold' },
            { label: 'Generate LOI', icon: <Home size={16} />, color: 'atlas-green' },
          ].map(action => (
            <button
              key={action.label}
              className={`flex flex-col items-center gap-2 p-3 rounded-lg bg-atlas-dark border border-atlas-border hover:border-${action.color}/30 transition-all`}
            >
              <span className={`text-${action.color}`}>{action.icon}</span>
              <span className="text-[10px] text-atlas-muted text-center">{action.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
