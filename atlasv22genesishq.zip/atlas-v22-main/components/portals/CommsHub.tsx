'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { MessageSquare, Mail, Phone, Send, Users } from 'lucide-react'
import toast from 'react-hot-toast'

const SMS_SEQUENCE = [
  { touch: 1, delay: '0d',  channel: 'SMS',   template: "Hi {name}, I saw your property at {address}. I buy homes as-is in WV — no repairs, no fees. Interested in a fair cash offer? Reply YES or call me anytime. - Atlas Investments" },
  { touch: 2, delay: '3d',  channel: 'SMS',   template: "Hey {name}, following up on {address}. Cash buyers are rare in this market — I can close in 7 days. No obligation quote. Reply STOP to opt out." },
  { touch: 3, delay: '7d',  channel: 'Email', template: "Subject: Cash offer for {address}\n\nHi {name},\n\nI wanted to reach out about your property at {address}. We specialize in purchasing tax-delinquent properties in WV with cash offers — no repairs needed, fast close.\n\nWould you be open to a brief call this week?\n\nBest,\nAtlas Investments" },
  { touch: 4, delay: '10d', channel: 'SMS',   template: "{name}, I know life gets busy. Still interested in a no-hassle cash offer for {address}? I can work around your timeline. Just reply YES." },
  { touch: 5, delay: '14d', channel: 'SMS',   template: "Final follow-up {name}. If you've been struggling with property taxes on {address}, I can help resolve that quickly with a cash purchase. Reply INFO for details." },
  { touch: 6, delay: '21d', channel: 'Email', template: "Subject: Re: {address} — One last thought\n\nHi {name},\n\nI understand selling can feel overwhelming. Our process takes 7 days, we pay closing costs, and you walk away debt-free.\n\nNo pressure — just want you to know the option is there.\n\nAtlas Investments" },
  { touch: 7, delay: '30d', channel: 'SMS',   template: "Hi {name} — checking in one last time on {address}. If now isn't right, that's okay. Whenever you're ready, I'm here. - Atlas Investments" },
]

export function CommsHub() {
  const { leads, openModal } = useAtlasStore()
  const [activeTab, setActiveTab] = useState<'sequence' | 'leads' | 'blast'>('sequence')
  const [selectedLead, setSelectedLead] = useState('')
  const [launching, setLaunching] = useState(false)

  async function launchSequence() {
    if (!selectedLead) { toast.error('Select a lead first'); return }
    setLaunching(true)
    await new Promise((r) => setTimeout(r, 1500))
    toast.success('7-touch WV sequence launched!')
    setLaunching(false)
  }

  return (
    <div className="space-y-4 max-w-4xl">
      {/* Tabs */}
      <div className="flex gap-1 atlas-panel p-1 rounded-xl w-fit">
        {[
          { id: 'sequence', label: '7-Touch Sequence', icon: <MessageSquare size={14} /> },
          { id: 'leads',    label: 'Lead Pipeline',    icon: <Users size={14} /> },
          { id: 'blast',    label: 'Blast Campaign',   icon: <Send size={14} /> },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm transition-all ${
              activeTab === tab.id
                ? 'bg-atlas-accent text-atlas-dark font-semibold'
                : 'text-atlas-muted hover:text-atlas-text'
            }`}
          >
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {/* Sequence View */}
      {activeTab === 'sequence' && (
        <div className="space-y-3">
          <div className="atlas-panel p-4 rounded-xl">
            <h3 className="text-sm font-semibold text-atlas-text mb-1">WV Tax-Delinquent Owner Sequence</h3>
            <p className="text-xs text-atlas-muted mb-3">7-touch SMS/Email drip tailored for WV distressed property owners</p>
            <div className="flex gap-3">
              <select
                value={selectedLead}
                onChange={(e) => setSelectedLead(e.target.value)}
                className="flex-1 bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text focus:outline-none focus:border-atlas-accent"
              >
                <option value="">Select a lead...</option>
                {leads.map((l) => <option key={l.id} value={l.id}>{l.name} — {l.phone}</option>)}
                <option value="demo">Demo Lead — John Smith (304-555-0100)</option>
              </select>
              <button
                onClick={launchSequence}
                disabled={launching}
                className="px-4 py-2 rounded-lg bg-atlas-green text-atlas-dark text-sm font-semibold hover:bg-atlas-green/80 disabled:opacity-50 transition-all"
              >
                {launching ? 'Launching...' : 'Launch Sequence'}
              </button>
            </div>
          </div>

          {/* Timeline */}
          <div className="space-y-2">
            {SMS_SEQUENCE.map((touch) => (
              <div key={touch.touch} className="atlas-panel p-4 rounded-xl flex gap-4">
                <div className="flex flex-col items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    touch.channel === 'SMS' ? 'bg-atlas-green/20 text-atlas-green' : 'bg-atlas-accent/20 text-atlas-accent'
                  }`}>
                    {touch.touch}
                  </div>
                  {touch.touch < SMS_SEQUENCE.length && <div className="w-0.5 h-4 bg-atlas-border mt-1" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {touch.channel === 'SMS' ? <MessageSquare size={12} className="text-atlas-green" /> : <Mail size={12} className="text-atlas-accent" />}
                    <span className="text-xs font-semibold text-white">{touch.channel} · Day {touch.delay.replace('d', '')}</span>
                  </div>
                  <p className="text-xs text-atlas-muted leading-relaxed font-mono bg-atlas-dark rounded p-2 border border-atlas-border">
                    {touch.template}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Leads Tab */}
      {activeTab === 'leads' && (
        <div className="atlas-panel p-4 rounded-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-atlas-text">Lead Pipeline</h3>
            <button className="text-xs text-atlas-accent hover:underline">+ Add Lead</button>
          </div>
          {leads.length === 0 ? (
            <div className="text-center py-8 text-atlas-muted text-sm">
              <Users size={32} className="mx-auto mb-2 opacity-30" />
              No leads yet. Analyze a property to generate leads automatically.
            </div>
          ) : (
            <div className="space-y-2">
              {leads.map((lead) => (
                <div key={lead.id} className="flex items-center gap-3 p-3 rounded-lg bg-atlas-dark border border-atlas-border">
                  <div className="flex-1">
                    <div className="text-sm font-medium text-white">{lead.name}</div>
                    <div className="text-xs text-atlas-muted">{lead.phone} · Touch {lead.touch_sequence}/7</div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => openModal('neural-call', { name: lead.name, phone: lead.phone })}
                      className="p-1.5 rounded bg-atlas-green/20 text-atlas-green hover:bg-atlas-green/30 transition-all">
                      <Phone size={12} />
                    </button>
                    <button className="p-1.5 rounded bg-atlas-accent/20 text-atlas-accent hover:bg-atlas-accent/30 transition-all">
                      <MessageSquare size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
