'use client'

import { useAtlasStore } from '@/store/useAtlasStore'
import { Wallet, CreditCard, TrendingUp, Zap } from 'lucide-react'

export function SP6Wallet() {
  const { wallet, agentRuns, openModal } = useAtlasStore()
  const pct = (wallet.credits_used_today / wallet.credits_limit_daily) * 100

  return (
    <div className="space-y-4 max-w-3xl">
      {/* Balance Card */}
      <div className="atlas-panel p-6 rounded-xl border border-atlas-gold/20 bg-gradient-to-br from-atlas-gold/5 to-transparent">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-atlas-gold/20 flex items-center justify-center">
              <Wallet size={24} className="text-atlas-gold" />
            </div>
            <div>
              <div className="text-lg font-bold text-white">SP6 Credit Wallet</div>
              <div className={`text-xs font-bold uppercase px-2 py-0.5 rounded mt-0.5 w-fit ${
                wallet.plan === 'enterprise' ? 'bg-atlas-gold/20 text-atlas-gold' :
                wallet.plan === 'pro' ? 'bg-atlas-purple/20 text-atlas-purple' :
                'bg-atlas-muted/20 text-atlas-muted'
              }`}>{wallet.plan} plan</div>
            </div>
          </div>
          <button
            onClick={() => openModal('stripe-checkout')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-atlas-gold text-atlas-dark font-semibold text-sm hover:bg-atlas-gold/80 transition-all"
          >
            <CreditCard size={14} /> Upgrade Plan
          </button>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div>
            <div className="text-3xl font-bold text-white font-mono">
              {wallet.credits_limit_daily - wallet.credits_used_today}
            </div>
            <div className="text-xs text-atlas-muted mt-0.5">Credits Remaining</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-atlas-accent font-mono">{wallet.credits_used_today}</div>
            <div className="text-xs text-atlas-muted mt-0.5">Used Today</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-atlas-gold font-mono">{wallet.credits_limit_daily}</div>
            <div className="text-xs text-atlas-muted mt-0.5">Daily Limit</div>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex justify-between text-xs text-atlas-muted mb-1">
            <span>Daily usage</span>
            <span>{pct.toFixed(0)}%</span>
          </div>
          <div className="w-full bg-atlas-border rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all ${pct > 80 ? 'bg-atlas-red' : pct > 60 ? 'bg-atlas-gold' : 'bg-gradient-to-r from-atlas-accent to-atlas-purple'}`}
              style={{ width: `${Math.min(pct, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Credit Costs */}
      <div className="atlas-panel p-4 rounded-xl">
        <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <Zap size={14} className="text-atlas-accent" />
          Credit Costs by Tool
        </h3>
        <div className="grid grid-cols-2 gap-2">
          {[
            { tool: 'Copilot Message',    cost: 2  },
            { tool: 'Property Analysis',  cost: 5  },
            { tool: 'Market Heatmap',     cost: 8  },
            { tool: 'Skip Trace',         cost: 10 },
            { tool: 'SMS Sequence',       cost: 3  },
            { tool: 'Full Dossier Pod',   cost: 25 },
            { tool: 'Investigator Agent', cost: 15 },
            { tool: 'Underwriter Agent',  cost: 20 },
          ].map(({ tool, cost }) => (
            <div key={tool} className="flex justify-between items-center px-3 py-2 rounded-lg bg-atlas-dark border border-atlas-border text-xs">
              <span className="text-atlas-text">{tool}</span>
              <span className="text-atlas-accent font-mono font-bold">{cost} cr</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Spend */}
      <div className="atlas-panel p-4 rounded-xl">
        <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <TrendingUp size={14} className="text-atlas-purple" />
          Recent Credit Activity
        </h3>
        {agentRuns.filter((r) => r.credits_consumed).length === 0 ? (
          <div className="text-center py-4 text-atlas-muted text-xs">No credit activity yet</div>
        ) : (
          <div className="space-y-1.5">
            {agentRuns.filter((r) => r.credits_consumed).slice(0, 10).map((run) => (
              <div key={run.id} className="flex justify-between items-center text-xs px-3 py-2 rounded bg-atlas-dark border border-atlas-border">
                <span className="text-atlas-text">{run.agent_type} · {run.input?.slice(0, 30)}...</span>
                <span className="text-atlas-red font-mono">-{run.credits_consumed} cr</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
