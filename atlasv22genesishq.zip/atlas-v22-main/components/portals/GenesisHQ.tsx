'use client'

/**
 * ATLAS v22 — Genesis HQ Portal
 * Thin wrapper so the portal map in app/page.tsx stays consistent with the
 * other portals. All logic lives in components/genesis-hq/*.
 */

import { GenesisHqCommandCenter } from '@/components/genesis-hq/GenesisHqCommandCenter'

export function GenesisHQ() {
  return <GenesisHqCommandCenter />
}
