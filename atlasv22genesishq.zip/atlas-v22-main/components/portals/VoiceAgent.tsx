'use client'

import { useState, useEffect, useRef } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { 
  Mic, 
  MicOff, 
  Phone, 
  PhoneOff, 
  Volume2, 
  VolumeX,
  MessageSquare,
  Zap,
  AlertCircle,
  CheckCircle,
  ChevronRight,
  User
} from 'lucide-react'
import { clsx } from 'clsx'
import toast from 'react-hot-toast'

interface CoachingTip {
  id: string
  type: 'suggestion' | 'warning' | 'success'
  message: string
  timestamp: number
}

interface CallScript {
  stage: string
  prompts: string[]
}

const CALL_SCRIPTS: CallScript[] = [
  {
    stage: 'Introduction',
    prompts: [
      "Hi, is this [OWNER NAME]?",
      "My name is [YOUR NAME] with Atlas Investments.",
      "I'm reaching out about your property at [ADDRESS]."
    ]
  },
  {
    stage: 'Build Rapport',
    prompts: [
      "How long have you owned the property?",
      "Are you currently living there or is it a rental?",
      "I noticed the property might need some attention - is that right?"
    ]
  },
  {
    stage: 'Qualify Motivation',
    prompts: [
      "Have you considered selling the property?",
      "What would need to happen for you to consider an offer?",
      "Is there a timeline you're working with?"
    ]
  },
  {
    stage: 'Present Solution',
    prompts: [
      "We buy properties as-is for cash - no repairs needed.",
      "We can close in as little as 7 days.",
      "We cover all closing costs."
    ]
  },
  {
    stage: 'Handle Objections',
    prompts: [
      "I understand you want to think about it. What concerns do you have?",
      "If the price was right, would you be ready to move forward?",
      "What would make this a no-brainer for you?"
    ]
  },
  {
    stage: 'Close',
    prompts: [
      "Based on what you've told me, I'd like to make you an offer.",
      "Can I send you a written offer today?",
      "What's the best email to send that to?"
    ]
  }
]

export function VoiceAgent() {
  const { wallet, consumeCredits, leads } = useAtlasStore()
  const [isCallActive, setIsCallActive] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isSpeakerOn, setIsSpeakerOn] = useState(true)
  const [callDuration, setCallDuration] = useState(0)
  const [currentStage, setCurrentStage] = useState(0)
  const [coachingTips, setCoachingTips] = useState<CoachingTip[]>([])
  const [transcript, setTranscript] = useState<string[]>([])
  const [selectedLead, setSelectedLead] = useState<string>('')
  
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // Timer for call duration
  useEffect(() => {
    if (isCallActive) {
      timerRef.current = setInterval(() => {
        setCallDuration(d => d + 1)
      }, 1000)
    } else {
      if (timerRef.current) clearInterval(timerRef.current)
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [isCallActive])

  // Simulate AI coaching tips
  useEffect(() => {
    if (!isCallActive) return
    
    const tips = [
      { delay: 5000, type: 'suggestion' as const, message: "Remember to use their first name to build rapport" },
      { delay: 15000, type: 'suggestion' as const, message: "Mirror their tone and pace of speaking" },
      { delay: 30000, type: 'warning' as const, message: "You've been talking for a while - ask an open-ended question" },
      { delay: 45000, type: 'success' as const, message: "Good question! Let them finish before responding" },
      { delay: 60000, type: 'suggestion' as const, message: "Transition to qualifying their motivation" },
    ]
    
    const timeouts = tips.map(tip => 
      setTimeout(() => {
        setCoachingTips(prev => [...prev, {
          id: Date.now().toString(),
          type: tip.type,
          message: tip.message,
          timestamp: Date.now()
        }])
      }, tip.delay)
    )
    
    return () => timeouts.forEach(clearTimeout)
  }, [isCallActive])

  function formatDuration(seconds: number): string {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  function startCall() {
    if (!consumeCredits(5)) {
      toast.error('Insufficient credits for voice call')
      return
    }
    setIsCallActive(true)
    setCallDuration(0)
    setCoachingTips([])
    setTranscript([])
    setCurrentStage(0)
    toast.success('Call started - AI coaching active')
  }

  function endCall() {
    setIsCallActive(false)
    toast('Call ended', { icon: '📞' })
  }

  function addToTranscript(speaker: 'you' | 'them', text: string) {
    setTranscript(prev => [...prev, `${speaker === 'you' ? '👤 You' : '🏠 Owner'}: ${text}`])
  }

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="atlas-panel p-6 rounded-xl border border-atlas-green/20 bg-gradient-to-r from-atlas-green/5 to-transparent text-center">
        <div className="w-20 h-20 rounded-full bg-atlas-green/20 border-2 border-atlas-green/40 flex items-center justify-center mx-auto mb-4">
          <Phone size={32} className={clsx(
            'text-atlas-green',
            isCallActive && 'animate-pulse'
          )} />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Voice Agent</h2>
        <p className="text-atlas-muted text-sm">AI-Powered Call Coaching for Seller Conversations</p>
        
        {/* Call Status */}
        <div className={clsx(
          'inline-flex items-center gap-2 px-4 py-2 rounded-full mt-4 text-sm font-mono',
          isCallActive 
            ? 'bg-atlas-green/20 text-atlas-green' 
            : 'bg-atlas-muted/20 text-atlas-muted'
        )}>
          <span className={clsx(
            'w-2 h-2 rounded-full',
            isCallActive ? 'bg-atlas-green animate-pulse' : 'bg-atlas-muted'
          )} />
          {isCallActive ? `LIVE ${formatDuration(callDuration)}` : 'READY'}
        </div>
      </div>

      {/* Lead Selection */}
      {!isCallActive && (
        <div className="atlas-panel p-4 rounded-xl">
          <h3 className="text-sm font-semibold text-atlas-text mb-3">Select Lead to Call</h3>
          <select
            value={selectedLead}
            onChange={(e) => setSelectedLead(e.target.value)}
            className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text focus:outline-none focus:border-atlas-accent"
          >
            <option value="">Choose a lead...</option>
            {leads.map(lead => (
              <option key={lead.id} value={lead.id}>{lead.name} — {lead.phone}</option>
            ))}
            <option value="demo">Demo: John Smith — (304) 555-0142</option>
          </select>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4">
        {/* Call Controls */}
        <div className="atlas-panel p-6 rounded-xl">
          <h3 className="text-sm font-semibold text-atlas-text mb-4 text-center">Call Controls</h3>
          
          <div className="flex justify-center gap-4 mb-6">
            {isCallActive ? (
              <>
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className={clsx(
                    'w-14 h-14 rounded-full border-2 flex items-center justify-center transition-all',
                    isMuted 
                      ? 'bg-atlas-red/20 border-atlas-red text-atlas-red' 
                      : 'border-atlas-border text-atlas-muted hover:border-atlas-text hover:text-atlas-text'
                  )}
                >
                  {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
                </button>
                <button
                  onClick={endCall}
                  className="w-14 h-14 rounded-full bg-atlas-red text-white flex items-center justify-center hover:bg-atlas-red/80 transition-all"
                >
                  <PhoneOff size={24} />
                </button>
                <button
                  onClick={() => setIsSpeakerOn(!isSpeakerOn)}
                  className={clsx(
                    'w-14 h-14 rounded-full border-2 flex items-center justify-center transition-all',
                    !isSpeakerOn 
                      ? 'bg-atlas-muted/20 border-atlas-muted text-atlas-muted' 
                      : 'border-atlas-border text-atlas-text hover:border-atlas-accent'
                  )}
                >
                  {isSpeakerOn ? <Volume2 size={24} /> : <VolumeX size={24} />}
                </button>
              </>
            ) : (
              <button
                onClick={startCall}
                className="px-8 py-4 rounded-full bg-atlas-green text-white font-semibold flex items-center gap-3 hover:bg-atlas-green/80 transition-all"
              >
                <Phone size={24} />
                Start Call (5 credits)
              </button>
            )}
          </div>

          {/* Quick Stats */}
          {isCallActive && (
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2 rounded-lg bg-atlas-dark">
                <div className="text-lg font-bold text-atlas-accent font-mono">{currentStage + 1}/6</div>
                <div className="text-[10px] text-atlas-muted">Stage</div>
              </div>
              <div className="p-2 rounded-lg bg-atlas-dark">
                <div className="text-lg font-bold text-atlas-green font-mono">{coachingTips.length}</div>
                <div className="text-[10px] text-atlas-muted">Tips</div>
              </div>
              <div className="p-2 rounded-lg bg-atlas-dark">
                <div className="text-lg font-bold text-atlas-gold font-mono">{formatDuration(callDuration)}</div>
                <div className="text-[10px] text-atlas-muted">Duration</div>
              </div>
            </div>
          )}
        </div>

        {/* AI Coaching Tips */}
        <div className="atlas-panel p-4 rounded-xl">
          <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
            <Zap size={14} className="text-atlas-gold" />
            AI Coaching
          </h3>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {coachingTips.length === 0 ? (
              <div className="text-center py-4 text-atlas-muted text-xs">
                Start a call to receive real-time AI coaching tips
              </div>
            ) : (
              coachingTips.map(tip => (
                <div
                  key={tip.id}
                  className={clsx(
                    'p-2 rounded-lg text-xs animate-fade-in flex items-start gap-2',
                    tip.type === 'suggestion' && 'bg-atlas-accent/10 border border-atlas-accent/30',
                    tip.type === 'warning' && 'bg-atlas-gold/10 border border-atlas-gold/30',
                    tip.type === 'success' && 'bg-atlas-green/10 border border-atlas-green/30'
                  )}
                >
                  {tip.type === 'suggestion' && <MessageSquare size={12} className="text-atlas-accent shrink-0 mt-0.5" />}
                  {tip.type === 'warning' && <AlertCircle size={12} className="text-atlas-gold shrink-0 mt-0.5" />}
                  {tip.type === 'success' && <CheckCircle size={12} className="text-atlas-green shrink-0 mt-0.5" />}
                  <span className="text-atlas-text">{tip.message}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Call Script */}
      <div className="atlas-panel p-4 rounded-xl">
        <h3 className="text-sm font-semibold text-atlas-text mb-3">Call Script Guide</h3>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {CALL_SCRIPTS.map((script, i) => (
            <button
              key={script.stage}
              onClick={() => setCurrentStage(i)}
              className={clsx(
                'px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all',
                currentStage === i
                  ? 'bg-atlas-accent text-atlas-dark'
                  : 'bg-atlas-dark border border-atlas-border text-atlas-muted hover:text-atlas-text'
              )}
            >
              {i + 1}. {script.stage}
            </button>
          ))}
        </div>
        
        <div className="mt-4 space-y-2">
          {CALL_SCRIPTS[currentStage].prompts.map((prompt, i) => (
            <div
              key={i}
              className="flex items-start gap-2 p-2 rounded-lg bg-atlas-dark border border-atlas-border cursor-pointer hover:border-atlas-accent/30 transition-all"
              onClick={() => addToTranscript('you', prompt)}
            >
              <ChevronRight size={14} className="text-atlas-accent shrink-0 mt-0.5" />
              <span className="text-sm text-atlas-text">{prompt}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Live Transcript */}
      {isCallActive && transcript.length > 0 && (
        <div className="atlas-panel p-4 rounded-xl">
          <h3 className="text-sm font-semibold text-atlas-text mb-3">Live Transcript</h3>
          <div className="bg-atlas-dark rounded-lg border border-atlas-border p-3 max-h-32 overflow-y-auto space-y-1 font-mono text-xs">
            {transcript.map((line, i) => (
              <div key={i} className="text-atlas-text">{line}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
