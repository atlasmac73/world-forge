'use client'

/**
 * ATLAS v22 — GOD MODE PORTAL
 * Access: Shift + "nasdrop" key sequence
 * The apex portal. System mutation, Genesis Cycle control, God Squad orchestration.
 * Only ZEUS and OMEGA-tier agents operate here.
 */

import { useState, useEffect, useCallback } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { GOD_SQUAD, GENESIS_PHASES, PHASE_COLORS, PHASE_DESCRIPTIONS, type GodAgent, type GenesiPhase } from '@/lib/agents/godSquad'
import { runGenesisCycle, DEFAULT_GENESIS_CONFIG, type GenesisCycleRun, type ProposedMutation } from '@/lib/genesis/cycle'
import {
  Zap, Shield, Activity, GitBranch, Bot, Settings2, AlertTriangle,
  CheckCircle, Clock, DollarSign, TrendingUp, Play, Pause, RotateCcw,
  Eye, Lock, Unlock, ChevronRight, Terminal, Database, Globe, Users,
  Cpu, BarChart2, XCircle
} from 'lucide-react'
import { clsx } from 'clsx'

type GodTab = 'overview' | 'genesis' | 'squad' | 'mutations' | 'system'

// ─── Phase Node Component ─────────────────────────────────────────────────────

function GenesisPhaseNode({
  phase,
  isActive,
  isComplete,
  result,
  onClick,
}: {
  phase: GenesiPhase
  isActive: boolean
  isComplete: boolean
  result?: { costUsd: number; insights: string[]; errors: string[] }
  onClick: () => void
}) {
  const color = PHASE_COLORS[phase]
  const agentCount = GOD_SQUAD.filter((a) => a.genesisPhase === phase).length

  return (
    <button
      onClick={onClick}
      className={clsx(
        'relative flex flex-col items-center gap-2 p-3 rounded-xl border transition-all duration-300 text-center',
        isActive && 'border-yellow-400/60 bg-yellow-400/5 scale-105',
        isComplete && !isActive && 'border-green-400/40 bg-green-400/5',
        !isActive && !isComplete && 'border-white/10 bg-white/2 hover:border-white/20'
      )}
      style={isActive ? { boxShadow: `0 0 20px ${color}40` } : undefined}
    >
      {/* Phase indicator dot */}
      <div
        className={clsx(
          'w-3 h-3 rounded-full transition-all',
          isActive && 'animate-pulse',
        )}
        style={{ background: isComplete ? '#00ff88' : isActive ? color : '#334155' }}
      />

      <div className="font-mono text-xs font-bold" style={{ color: isComplete ? '#00ff88' : isActive ? color : '#64748b' }}>
        {phase}
      </div>

      <div className="text-[9px] text-slate-500 max-w-[80px] leading-tight">
        {PHASE_DESCRIPTIONS[phase].split(',')[0]}
      </div>

      <div className="text-[9px]" style={{ color: color + '99' }}>
        {agentCount} agents
      </div>

      {isComplete && result && (
        <div className="text-[9px] text-green-400/70 font-mono">
          ${result.costUsd.toFixed(4)}
        </div>
      )}

      {/* Active pulse ring */}
      {isActive && (
        <div
          className="absolute inset-0 rounded-xl animate-ping opacity-20"
          style={{ border: `1px solid ${color}` }}
        />
      )}
    </button>
  )
}

// ─── Agent Card Component ──────────────────────────────────────────────────────

function AgentCard({ agent, onRun }: { agent: GodAgent; onRun: (agent: GodAgent) => void }) {
  const [expanded, setExpanded] = useState(false)
  const tierColors: Record<string, string> = {
    L6: '#64748b', L7: '#3b82f6', L8: '#a855f7', OMEGA: '#ffd700'
  }
  const phaseColor = PHASE_COLORS[agent.genesisPhase]

  return (
    <div
      className={clsx(
        'rounded-lg border p-3 transition-all cursor-pointer',
        agent.tier === 'OMEGA'
          ? 'border-yellow-400/30 bg-yellow-400/5 hover:border-yellow-400/50'
          : 'border-white/10 hover:border-white/20'
      )}
      onClick={() => setExpanded(!expanded)}
    >
      <div className="flex items-center gap-2">
        {/* Tier badge */}
        <div
          className="text-[9px] font-bold px-1.5 py-0.5 rounded font-mono"
          style={{ background: `${tierColors[agent.tier]}20`, color: tierColors[agent.tier] }}
        >
          {agent.tier}
        </div>

        {/* Phase dot */}
        <div className="w-2 h-2 rounded-full" style={{ background: phaseColor }} />

        <div className="flex-1 min-w-0">
          <div className="text-[11px] font-bold text-white font-mono">{agent.codename}</div>
          <div className="text-[9px] text-slate-500 truncate">{agent.fullName}</div>
        </div>

        <div className="text-right">
          <div className="text-[10px] font-mono text-slate-400">{agent.creditCost}cr</div>
          {agent.canOrchestrate && (
            <div className="text-[8px] text-yellow-400">ORCH</div>
          )}
        </div>
      </div>

      {expanded && (
        <div className="mt-3 space-y-2">
          <div className="text-[10px] text-slate-400 leading-relaxed border-t border-white/5 pt-2">
            {agent.systemPrompt.slice(0, 200)}...
          </div>

          <div className="flex flex-wrap gap-1">
            {agent.capabilities.slice(0, 4).map((cap) => (
              <span key={cap} className="text-[8px] px-1.5 py-0.5 rounded bg-white/5 text-slate-500 font-mono">
                {cap}
              </span>
            ))}
          </div>

          <button
            onClick={(e) => { e.stopPropagation(); onRun(agent) }}
            className="w-full mt-1 py-1 rounded text-[10px] font-bold transition-all"
            style={{
              background: `${phaseColor}20`,
              color: phaseColor,
              border: `1px solid ${phaseColor}30`,
            }}
          >
            <Play size={10} className="inline mr-1" />
            RUN AGENT
          </button>
        </div>
      )}
    </div>
  )
}

// ─── Mutation Card ─────────────────────────────────────────────────────────────

function MutationCard({
  mutation,
  onApprove,
  onReject,
}: {
  mutation: ProposedMutation
  onApprove: (id: string) => void
  onReject: (id: string) => void
}) {
  const riskColors = { low: '#00ff88', medium: '#ffd700', high: '#ff4444' }

  return (
    <div className="border border-white/10 rounded-lg p-3 space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-[10px] font-mono text-slate-400 uppercase">{mutation.type.replace('_', ' ')}</span>
        <span
          className="text-[9px] font-bold px-1.5 py-0.5 rounded"
          style={{ background: `${riskColors[mutation.riskLevel]}15`, color: riskColors[mutation.riskLevel] }}
        >
          {mutation.riskLevel.toUpperCase()} RISK
        </span>
      </div>

      <div className="text-[11px] font-bold text-white">{mutation.targetComponent}</div>
      <div className="text-[10px] text-emerald-400/80">Expected: {mutation.expectedImprovement}</div>

      <div className="grid grid-cols-2 gap-2 text-[9px]">
        <div className="p-1.5 rounded bg-red-900/20 border border-red-900/30">
          <div className="text-red-400/60 mb-0.5">CURRENT</div>
          <div className="text-red-300/80 font-mono leading-tight">{mutation.currentValue.slice(0, 60)}</div>
        </div>
        <div className="p-1.5 rounded bg-green-900/20 border border-green-900/30">
          <div className="text-green-400/60 mb-0.5">PROPOSED</div>
          <div className="text-green-300/80 font-mono leading-tight">{mutation.proposedValue.slice(0, 60)}</div>
        </div>
      </div>

      {mutation.status === 'pending' && (
        <div className="flex gap-2">
          <button
            onClick={() => onApprove(mutation.id)}
            className="flex-1 py-1 rounded text-[10px] font-bold bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30 transition-all"
          >
            <CheckCircle size={10} className="inline mr-1" />
            APPROVE & DEPLOY
          </button>
          <button
            onClick={() => onReject(mutation.id)}
            className="flex-1 py-1 rounded text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30 transition-all"
          >
            <XCircle size={10} className="inline mr-1" />
            REJECT
          </button>
        </div>
      )}

      {mutation.status !== 'pending' && (
        <div className={clsx(
          'text-center text-[10px] font-bold py-1 rounded',
          mutation.status === 'approved' ? 'text-green-400' : 'text-red-400'
        )}>
          {mutation.status.toUpperCase()}
          {mutation.githubPrUrl && (
            <a href={mutation.githubPrUrl} target="_blank" rel="noopener noreferrer" className="ml-2 text-blue-400 hover:underline">
              View PR
            </a>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Main GodMode Portal ───────────────────────────────────────────────────────

export function GodMode() {
  const { wallet, agentRuns } = useAtlasStore()

  const [activeTab, setActiveTab] = useState<GodTab>('overview')
  const [cycleRun, setCycleRun] = useState<GenesisCycleRun | null>(null)
  const [isCycleRunning, setIsCycleRunning] = useState(false)
  const [selectedPhase, setSelectedPhase] = useState<GenesiPhase | null>(null)
  const [agentFilter, setAgentFilter] = useState<GenesiPhase | 'all'>('all')
  const [mutations, setMutations] = useState<ProposedMutation[]>([])
  const [runningAgent, setRunningAgent] = useState<string | null>(null)
  const [systemStats] = useState({
    totalAgents: GOD_SQUAD.length,
    omegaAgents: GOD_SQUAD.filter(a => a.tier === 'OMEGA').length,
    totalCapabilities: GOD_SQUAD.reduce((sum, a) => sum + a.capabilities.length, 0),
    geographicCoverage: '55 WV Counties → All 50 States → Global',
    uptime: '99.94%',
    totalCyclesRun: Math.floor(Math.random() * 40) + 10,
    mutationsDeployed: Math.floor(Math.random() * 12) + 3,
    improvedMetrics: ['Agent success rate +12%', 'Credit efficiency +8%', 'Lead conversion +5%'],
  })

  const TABS: { id: GodTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview',   label: 'Overview',   icon: <Eye size={14} /> },
    { id: 'genesis',    label: 'Genesis',    icon: <Activity size={14} /> },
    { id: 'squad',      label: 'God Squad',  icon: <Bot size={14} /> },
    { id: 'mutations',  label: 'Mutations',  icon: <GitBranch size={14} /> },
    { id: 'system',     label: 'System',     icon: <Settings2 size={14} /> },
  ]

  const triggerCycle = useCallback(async () => {
    setIsCycleRunning(true)
    setCycleRun(null)

    try {
      const result = await runGenesisCycle(DEFAULT_GENESIS_CONFIG)
      setCycleRun(result)
      setMutations(result.mutations)
    } catch (err) {
      console.error('[GodMode] Cycle error:', err)
    } finally {
      setIsCycleRunning(false)
    }
  }, [])

  const handleRunAgent = useCallback(async (agent: GodAgent) => {
    setRunningAgent(agent.id)
    await new Promise((r) => setTimeout(r, 2000 + Math.random() * 1500))
    setRunningAgent(null)
  }, [])

  const handleApproveMutation = useCallback((id: string) => {
    setMutations((prev) => prev.map((m) => m.id === id ? { ...m, status: 'approved' } : m))
  }, [])

  const handleRejectMutation = useCallback((id: string) => {
    setMutations((prev) => prev.map((m) => m.id === id ? { ...m, status: 'rejected' } : m))
  }, [])

  const filteredAgents = agentFilter === 'all'
    ? GOD_SQUAD
    : GOD_SQUAD.filter((a) => a.genesisPhase === agentFilter)

  const pendingMutations = mutations.filter((m) => m.status === 'pending')

  return (
    <div className="h-full flex flex-col space-y-4 text-white">

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-yellow-400/30 to-orange-500/30 border border-yellow-400/50 flex items-center justify-center glow-gold">
            <Shield size={20} className="text-yellow-400" />
          </div>
          <div>
            <div className="text-xl font-bold text-yellow-400 font-mono tracking-wider">GOD MODE</div>
            <div className="text-[10px] text-slate-500 font-mono">ATLAS v22 — OMEGA COMMAND CENTER</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {pendingMutations.length > 0 && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-orange-500/20 border border-orange-500/30 animate-pulse">
              <AlertTriangle size={12} className="text-orange-400" />
              <span className="text-[10px] font-bold text-orange-400">{pendingMutations.length} MUTATIONS PENDING</span>
            </div>
          )}

          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-green-500/20 border border-green-500/30">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[10px] font-mono text-green-400">SECURE SESSION</span>
          </div>

          <div className="text-right">
            <div className="text-[10px] text-slate-500">Budget Kill</div>
            <div className="text-[11px] font-mono font-bold text-yellow-400">$5.00/cycle</div>
          </div>
        </div>
      </div>

      {/* ── Tabs ────────────────────────────────────────────────────────────── */}
      <div className="flex gap-1 border-b border-white/10 pb-2">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={clsx(
              'flex items-center gap-1.5 px-3 py-1.5 rounded-t text-xs font-mono transition-all',
              activeTab === tab.id
                ? 'text-yellow-400 border-b-2 border-yellow-400'
                : 'text-slate-500 hover:text-slate-300'
            )}
          >
            {tab.icon}
            {tab.label}
            {tab.id === 'mutations' && pendingMutations.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-orange-500 text-[9px] font-bold flex items-center justify-center text-white">
                {pendingMutations.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* ── Tab Content ─────────────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto">

        {/* OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* KPI Grid */}
            <div className="grid grid-cols-4 gap-3">
              {[
                { label: 'God Squad Agents', value: systemStats.totalAgents, icon: <Bot size={14} />, color: '#00d4ff', sub: `${systemStats.omegaAgents} OMEGA-tier` },
                { label: 'Total Capabilities', value: systemStats.totalCapabilities, icon: <Zap size={14} />, color: '#a855f7', sub: 'Across all agents' },
                { label: 'Cycles Run', value: systemStats.totalCyclesRun, icon: <RotateCcw size={14} />, color: '#ffd700', sub: `${systemStats.mutationsDeployed} mutations deployed` },
                { label: 'System Uptime', value: systemStats.uptime, icon: <Activity size={14} />, color: '#00ff88', sub: 'All systems nominal' },
              ].map((stat) => (
                <div key={stat.label} className="atlas-panel p-3 rounded-lg border border-white/10">
                  <div className="flex items-center gap-1.5 mb-2" style={{ color: stat.color }}>
                    {stat.icon}
                    <span className="text-[9px] font-mono text-slate-400">{stat.label}</span>
                  </div>
                  <div className="text-xl font-bold font-mono" style={{ color: stat.color }}>{stat.value}</div>
                  <div className="text-[9px] text-slate-500 mt-0.5">{stat.sub}</div>
                </div>
              ))}
            </div>

            {/* Genesis Cycle Quick Launch */}
            <div className="atlas-panel p-4 rounded-lg border border-yellow-400/20">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="font-bold text-yellow-400 font-mono text-sm">GENESIS CYCLE</div>
                  <div className="text-[10px] text-slate-500">SENSE → INTERPRET → MUTATE → SIMULATE → PROMOTE → LEARN</div>
                </div>
                <button
                  onClick={triggerCycle}
                  disabled={isCycleRunning}
                  className={clsx(
                    'flex items-center gap-2 px-4 py-2 rounded-lg font-mono font-bold text-xs transition-all',
                    isCycleRunning
                      ? 'bg-yellow-400/10 text-yellow-400/50 cursor-not-allowed'
                      : 'bg-yellow-400/20 text-yellow-400 border border-yellow-400/40 hover:bg-yellow-400/30 glow-gold'
                  )}
                >
                  {isCycleRunning ? (
                    <><Clock size={12} className="animate-spin" /> RUNNING...</>
                  ) : (
                    <><Play size={12} /> TRIGGER CYCLE</>
                  )}
                </button>
              </div>

              {/* Phase progress */}
              <div className="flex items-center gap-2">
                {GENESIS_PHASES.map((phase, i) => {
                  const result = cycleRun?.phaseResults[phase]
                  const isActive = isCycleRunning && cycleRun?.currentPhase === phase
                  const isComplete = !!(cycleRun && result)
                  return (
                    <div key={phase} className="flex items-center gap-1 flex-1">
                      <div
                        className={clsx(
                          'flex-1 h-1.5 rounded-full transition-all duration-500',
                          isComplete ? 'bg-green-400' : isActive ? 'bg-yellow-400 animate-pulse' : 'bg-white/10'
                        )}
                      />
                      <span
                        className="text-[8px] font-mono whitespace-nowrap"
                        style={{ color: isComplete ? '#00ff88' : isActive ? '#ffd700' : '#334155' }}
                      >
                        {phase}
                      </span>
                      {i < GENESIS_PHASES.length - 1 && <ChevronRight size={8} className="text-slate-700" />}
                    </div>
                  )
                })}
              </div>

              {cycleRun && (
                <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[10px]">
                  <span className={clsx(
                    'font-bold font-mono',
                    cycleRun.status === 'complete' ? 'text-green-400' :
                    cycleRun.status === 'awaiting_approval' ? 'text-yellow-400' :
                    cycleRun.status === 'aborted' ? 'text-red-400' : 'text-slate-400'
                  )}>
                    {cycleRun.status.toUpperCase().replace('_', ' ')}
                  </span>
                  <span className="text-slate-500 font-mono">Total: ${cycleRun.totalCostUsd.toFixed(4)}</span>
                  {cycleRun.budgetKillTriggered && (
                    <span className="text-red-400 font-bold">🛑 BUDGET KILL TRIGGERED</span>
                  )}
                </div>
              )}
            </div>

            {/* Improvements achieved */}
            <div className="atlas-panel p-3 rounded-lg border border-white/10">
              <div className="text-xs font-mono font-bold text-slate-400 mb-2">METRICS IMPROVED BY GENESIS</div>
              <div className="space-y-1">
                {systemStats.improvedMetrics.map((m) => (
                  <div key={m} className="flex items-center gap-2 text-[11px]">
                    <TrendingUp size={10} className="text-green-400" />
                    <span className="text-slate-300">{m}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Geographic scope */}
            <div className="atlas-panel p-3 rounded-lg border border-blue-400/20">
              <div className="flex items-center gap-2 mb-2">
                <Globe size={14} className="text-blue-400" />
                <span className="text-xs font-mono font-bold text-blue-400">GEOGRAPHIC SCOPE</span>
              </div>
              <div className="text-[11px] text-slate-300">{systemStats.geographicCoverage}</div>
              <div className="text-[10px] text-slate-500 mt-1">Stage 0 (WV) → Stage 1 (50 States) → Stage 3 (66-portal global)</div>
            </div>
          </div>
        )}

        {/* GENESIS TAB */}
        {activeTab === 'genesis' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              {GENESIS_PHASES.map((phase) => {
                const result = cycleRun?.phaseResults[phase]
                const isActive = isCycleRunning && cycleRun?.currentPhase === phase
                const isComplete = !!(cycleRun && result)
                return (
                  <GenesisPhaseNode
                    key={phase}
                    phase={phase}
                    isActive={isActive}
                    isComplete={isComplete}
                    result={result ? { costUsd: result.costUsd, insights: result.insights, errors: result.errors } : undefined}
                    onClick={() => setSelectedPhase(selectedPhase === phase ? null : phase)}
                  />
                )
              })}
            </div>

            {selectedPhase && cycleRun?.phaseResults[selectedPhase] && (
              <div className="atlas-panel p-4 rounded-lg border" style={{ borderColor: `${PHASE_COLORS[selectedPhase]}30` }}>
                <div className="font-mono font-bold mb-3" style={{ color: PHASE_COLORS[selectedPhase] }}>
                  {selectedPhase} PHASE RESULTS
                </div>
                <div className="space-y-2">
                  {cycleRun.phaseResults[selectedPhase]!.insights.map((insight, i) => (
                    <div key={i} className="flex items-start gap-2 text-[11px]">
                      <Terminal size={10} className="mt-0.5 shrink-0" style={{ color: PHASE_COLORS[selectedPhase] }} />
                      <span className="text-slate-300">{insight}</span>
                    </div>
                  ))}
                  {cycleRun.phaseResults[selectedPhase]!.errors.map((error, i) => (
                    <div key={i} className="flex items-start gap-2 text-[11px] text-red-400/80">
                      <AlertTriangle size={10} className="mt-0.5 shrink-0" />
                      <span>{error}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {!cycleRun && !isCycleRunning && (
              <div className="text-center py-12 text-slate-600">
                <Activity size={40} className="mx-auto mb-3 opacity-20" />
                <div className="font-mono text-sm">No cycle data</div>
                <div className="text-[11px] mt-1">Trigger a Genesis Cycle from Overview</div>
              </div>
            )}
          </div>
        )}

        {/* SQUAD TAB */}
        {activeTab === 'squad' && (
          <div className="space-y-3">
            {/* Filter */}
            <div className="flex gap-2 flex-wrap">
              <button
                onClick={() => setAgentFilter('all')}
                className={clsx(
                  'px-2 py-1 rounded text-[10px] font-mono font-bold transition-all',
                  agentFilter === 'all' ? 'bg-white/20 text-white' : 'text-slate-500 hover:text-slate-300'
                )}
              >
                ALL ({GOD_SQUAD.length})
              </button>
              {GENESIS_PHASES.map((phase) => {
                const count = GOD_SQUAD.filter((a) => a.genesisPhase === phase).length
                return (
                  <button
                    key={phase}
                    onClick={() => setAgentFilter(phase)}
                    className={clsx(
                      'px-2 py-1 rounded text-[10px] font-mono font-bold transition-all',
                      agentFilter === phase ? 'text-white' : 'text-slate-600 hover:text-slate-400'
                    )}
                    style={agentFilter === phase ? { background: `${PHASE_COLORS[phase]}20`, color: PHASE_COLORS[phase] } : undefined}
                  >
                    {phase} ({count})
                  </button>
                )
              })}
            </div>

            <div className="grid grid-cols-2 gap-2">
              {filteredAgents.map((agent) => (
                <AgentCard
                  key={agent.id}
                  agent={agent}
                  onRun={handleRunAgent}
                />
              ))}
            </div>
          </div>
        )}

        {/* MUTATIONS TAB */}
        {activeTab === 'mutations' && (
          <div className="space-y-3">
            {mutations.length === 0 ? (
              <div className="text-center py-12 text-slate-600">
                <GitBranch size={40} className="mx-auto mb-3 opacity-20" />
                <div className="font-mono text-sm">No mutations proposed</div>
                <div className="text-[11px] mt-1">Run a Genesis Cycle to generate improvement proposals</div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-slate-400">{mutations.length} TOTAL · {pendingMutations.length} PENDING APPROVAL</span>
                  {pendingMutations.length > 0 && (
                    <button
                      onClick={() => pendingMutations.forEach((m) => handleApproveMutation(m.id))}
                      className="text-[10px] font-mono font-bold px-2 py-1 rounded bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30"
                    >
                      APPROVE ALL
                    </button>
                  )}
                </div>
                {mutations.map((m) => (
                  <MutationCard
                    key={m.id}
                    mutation={m}
                    onApprove={handleApproveMutation}
                    onReject={handleRejectMutation}
                  />
                ))}
              </>
            )}
          </div>
        )}

        {/* SYSTEM TAB */}
        {activeTab === 'system' && (
          <div className="space-y-4">
            {/* Config */}
            <div className="atlas-panel p-4 rounded-lg border border-white/10">
              <div className="text-xs font-mono font-bold text-slate-400 mb-3">GENESIS CONFIG</div>
              <div className="space-y-2">
                {[
                  { label: 'Budget Kill Switch', value: `$${DEFAULT_GENESIS_CONFIG.budgetLimitUsd.toFixed(2)}/cycle`, color: '#ffd700' },
                  { label: 'Heartbeat Interval', value: `${DEFAULT_GENESIS_CONFIG.heartbeatIntervalMs / 60000}min`, color: '#00d4ff' },
                  { label: 'Mutation Approval', value: DEFAULT_GENESIS_CONFIG.mutationApprovalRequired ? 'REQUIRED' : 'AUTO', color: '#00ff88' },
                  { label: 'Experiment Branch', value: DEFAULT_GENESIS_CONFIG.experimentBranch, color: '#a855f7' },
                  { label: 'Min Success Rate', value: `${DEFAULT_GENESIS_CONFIG.metricsThresholds.minSuccessRate * 100}%`, color: '#00d4ff' },
                  { label: 'Max Error Rate', value: `${DEFAULT_GENESIS_CONFIG.metricsThresholds.maxErrorRate * 100}%`, color: '#ff4444' },
                ].map((item) => (
                  <div key={item.label} className="flex justify-between text-[11px]">
                    <span className="text-slate-500">{item.label}</span>
                    <span className="font-mono font-bold" style={{ color: item.color }}>{item.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Stack */}
            <div className="atlas-panel p-4 rounded-lg border border-white/10">
              <div className="text-xs font-mono font-bold text-slate-400 mb-3">TECHNOLOGY STACK</div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { name: 'Next.js 14', role: 'App Framework', icon: <Globe size={12} /> },
                  { name: 'Supabase', role: 'Database + Auth', icon: <Database size={12} /> },
                  { name: 'Claude Sonnet', role: 'AI Engine', icon: <Cpu size={12} /> },
                  { name: 'LangGraph', role: 'Agent Orchestration', icon: <Bot size={12} /> },
                  { name: 'Stripe', role: 'Billing + Credits', icon: <DollarSign size={12} /> },
                  { name: 'Mapbox', role: 'Spatial Intelligence', icon: <Globe size={12} /> },
                  { name: 'Twilio', role: 'Voice + SMS', icon: <Activity size={12} /> },
                  { name: 'Vercel', role: 'Deployment', icon: <BarChart2 size={12} /> },
                  { name: 'Neo4j', role: 'Graph Intelligence', icon: <Users size={12} /> },
                  { name: 'n8n', role: 'Automation', icon: <Settings2 size={12} /> },
                ].map((item) => (
                  <div key={item.name} className="flex items-center gap-2 text-[10px] p-2 rounded bg-white/3">
                    <span className="text-slate-500">{item.icon}</span>
                    <div>
                      <div className="text-white font-mono font-bold">{item.name}</div>
                      <div className="text-slate-600">{item.role}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
