'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { Bot, Play, Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react'
import { clsx } from 'clsx'
import toast from 'react-hot-toast'

const AGENT_PODS = [
  {
    id: 'dossier',
    name: 'Property Dossier Pod',
    description: 'Investigator → Underwriter → Copywriter chain. Full deal analysis from a single address.',
    credits: 25,
    agents: ['🔍 Investigator', '📊 Underwriter', '✍️ Copywriter'],
    color: 'atlas-accent',
  },
  {
    id: 'skip-trace',
    name: 'Skip Trace Pod',
    description: 'Deep owner lookup via n8n webhook. Returns phone, email, address history.',
    credits: 10,
    agents: ['🔍 Investigator'],
    color: 'atlas-purple',
    requiresPro: true,
  },
  {
    id: 'market-scan',
    name: 'Market Scan Pod',
    description: 'Scans target ZIP codes for high-equity distressed assets. Returns ranked list.',
    credits: 8,
    agents: ['📡 Market Scanner', '📊 Underwriter'],
    color: 'atlas-gold',
  },
]

export function AgentLab() {
  const { agentRuns, wallet, consumeCredits, addAgentRun, updateAgentRun } = useAtlasStore()
  const [running, setRunning] = useState<string | null>(null)
  const [input, setInput] = useState('')

  async function runPod(podId: string, credits: number) {
    if (!input.trim()) { toast.error('Enter an address or ZIP code'); return }
    if (!consumeCredits(credits)) { toast.error('Credit limit reached'); return }

    const runId = crypto.randomUUID()
    setRunning(podId)
    addAgentRun({
      id: runId,
      agent_type: 'orchestrator',
      status: 'running',
      input,
      credits_consumed: credits,
      created_at: new Date().toISOString(),
    })

    try {
      const res = await fetch('/api/agents/dossier', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address: input, pod: podId }),
      })
      const data = await res.json()
      updateAgentRun(runId, { status: 'completed', output: JSON.stringify(data), completed_at: new Date().toISOString() })
      toast.success(`${podId} pod completed!`)
    } catch {
      updateAgentRun(runId, { status: 'failed' })
      toast.error('Agent pod failed — check API keys')
    } finally {
      setRunning(null)
    }
  }

  return (
    <div className="space-y-4 max-w-4xl">
      {/* Input */}
      <div className="atlas-panel p-4 rounded-xl">
        <h2 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <Bot size={14} className="text-atlas-accent" />
          Agent Lab — Multi-Agent Orchestration
        </h2>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter address or ZIP code to run agent pods against..."
          className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-4 py-2.5 text-sm text-atlas-text placeholder-atlas-muted focus:outline-none focus:border-atlas-accent transition-colors"
        />
      </div>

      {/* Agent Pods */}
      <div className="grid grid-cols-3 gap-3">
        {AGENT_PODS.map((pod) => (
          <div key={pod.id} className="atlas-panel p-4 rounded-xl flex flex-col">
            <div className="flex items-start justify-between mb-2">
              <h3 className={`text-sm font-bold text-${pod.color}`}>{pod.name}</h3>
              {pod.requiresPro && wallet.plan === 'free' && (
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-atlas-purple/20 text-atlas-purple font-bold">PRO</span>
              )}
            </div>
            <p className="text-xs text-atlas-muted flex-1 mb-3">{pod.description}</p>
            <div className="flex flex-wrap gap-1 mb-3">
              {pod.agents.map((a) => (
                <span key={a} className="text-[10px] px-2 py-0.5 rounded bg-atlas-dark border border-atlas-border text-atlas-muted">
                  {a}
                </span>
              ))}
            </div>
            <button
              onClick={() => runPod(pod.id, pod.credits)}
              disabled={!!running || (pod.requiresPro && wallet.plan === 'free')}
              className={clsx(
                'w-full py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all',
                running === pod.id ? 'bg-atlas-border text-atlas-muted' :
                pod.requiresPro && wallet.plan === 'free' ? 'bg-atlas-border text-atlas-muted cursor-not-allowed' :
                `bg-${pod.color}/20 text-${pod.color} hover:bg-${pod.color}/30 border border-${pod.color}/30`
              )}
            >
              {running === pod.id
                ? <><Loader2 size={14} className="animate-spin" /> Running...</>
                : <><Play size={14} /> Run ({pod.credits} credits)</>
              }
            </button>
          </div>
        ))}
      </div>

      {/* Agent Run Ledger */}
      <div className="atlas-panel p-4 rounded-xl">
        <h3 className="text-sm font-semibold text-atlas-text mb-3">Agent Run Ledger</h3>
        {agentRuns.length === 0 ? (
          <div className="text-center py-6 text-atlas-muted text-xs">
            <Clock size={24} className="mx-auto mb-2 opacity-30" />
            No agent runs yet. Run a pod above to see results here.
          </div>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {agentRuns.map((run) => (
              <div key={run.id} className="flex items-center gap-3 p-2.5 rounded-lg bg-atlas-dark border border-atlas-border text-xs">
                {run.status === 'completed' ? <CheckCircle size={14} className="text-atlas-green shrink-0" /> :
                 run.status === 'failed'    ? <XCircle size={14} className="text-atlas-red shrink-0" /> :
                 <Loader2 size={14} className="text-atlas-accent animate-spin shrink-0" />}
                <div className="flex-1 truncate">
                  <span className="text-atlas-text font-medium">{run.agent_type}</span>
                  <span className="text-atlas-muted ml-2 truncate">{run.input}</span>
                </div>
                <span className="text-atlas-muted shrink-0 font-mono">
                  {run.credits_consumed ? `-${run.credits_consumed}cr` : ''}
                </span>
                <span className="text-atlas-muted shrink-0">
                  {new Date(run.created_at).toLocaleTimeString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
