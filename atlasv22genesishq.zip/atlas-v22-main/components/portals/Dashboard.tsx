'use client'

import { useAtlasStore } from '@/store/useAtlasStore'
import { TrendingUp, Home, Users, Bot, Zap, ArrowRight } from 'lucide-react'
import { clsx } from 'clsx'

const STAT_CARDS = [
  { label: 'Active Properties',  value: '247',   delta: '+12 this week', icon: <Home size={18} />,        color: 'atlas-accent'  },
  { label: 'Hot Leads',          value: '38',    delta: '+5 today',      icon: <TrendingUp size={18} />,  color: 'atlas-red'     },
  { label: 'Leads Contacted',    value: '142',   delta: '73% response',  icon: <Users size={18} />,       color: 'atlas-green'   },
  { label: 'Agent Runs Today',   value: '91',    delta: '1,820 credits', icon: <Bot size={18} />,         color: 'atlas-purple'  },
]

const RECENT_ACTIVITY = [
  { text: 'Investigator completed dossier for 412 Elm St, Charleston',         time: '2m ago',  type: 'agent'    },
  { text: 'Skip trace returned owner data for 5 properties in ZIP 25301',      time: '8m ago',  type: 'tool'     },
  { text: 'SMS sequence launched for 23 tax-delinquent owners',                time: '15m ago', type: 'comms'    },
  { text: 'Market heatmap updated — 25301 score jumped to 94',                 time: '1h ago',  type: 'intel'    },
  { text: 'Underwriter completed deal analysis: ARV $187k, equity 68%',        time: '2h ago',  type: 'agent'    },
]

const typeColor: Record<string, string> = {
  agent:  'text-atlas-purple',
  tool:   'text-atlas-accent',
  comms:  'text-atlas-green',
  intel:  'text-atlas-gold',
}

export function Dashboard() {
  const { setActivePortal, wallet } = useAtlasStore()

  return (
    <div className="space-y-4 max-w-6xl">
      {/* Welcome Banner */}
      <div className="atlas-panel p-4 rounded-xl border border-atlas-accent/20 bg-gradient-to-r from-atlas-accent/5 to-transparent">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white flex items-center gap-2">
              <Zap size={20} className="text-atlas-accent" />
              ATLAS v20 Command Center
            </h1>
            <p className="text-atlas-muted text-sm mt-0.5">
              Charleston, WV Metro · Real Estate AI Intelligence Platform
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-atlas-accent font-mono">{wallet.credits_limit_daily - wallet.credits_used_today}</div>
            <div className="text-xs text-atlas-muted">credits remaining</div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-3">
        {STAT_CARDS.map((stat) => (
          <div key={stat.label} className="atlas-panel p-4 rounded-xl">
            <div className={`text-${stat.color} mb-2`}>{stat.icon}</div>
            <div className="text-2xl font-bold text-white font-mono">{stat.value}</div>
            <div className="text-xs text-atlas-muted mt-0.5">{stat.label}</div>
            <div className={`text-[11px] text-${stat.color} mt-1`}>{stat.delta}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Quick Actions */}
        <div className="atlas-panel p-4 rounded-xl col-span-1">
          <h2 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
            <Zap size={14} className="text-atlas-accent" />
            Quick Actions
          </h2>
          <div className="space-y-2">
            {[
              { label: 'Analyze New Property',   portal: 'deal-navigator' as const, color: 'atlas-accent'  },
              { label: 'Launch SMS Campaign',     portal: 'comms-hub'      as const, color: 'atlas-green'   },
              { label: 'View Market Heatmap',     portal: 'market-intel'   as const, color: 'atlas-gold'    },
              { label: 'Run Agent Pod',           portal: 'agent-lab'      as const, color: 'atlas-purple'  },
            ].map((action) => (
              <button
                key={action.label}
                onClick={() => setActivePortal(action.portal)}
                className={clsx(
                  'w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs transition-all',
                  'bg-atlas-dark hover:bg-atlas-border text-atlas-text border border-atlas-border hover:border-atlas-accent/30'
                )}
              >
                <span>{action.label}</span>
                <ArrowRight size={12} className={`text-${action.color}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="atlas-panel p-4 rounded-xl col-span-2">
          <h2 className="text-sm font-semibold text-atlas-text mb-3">Recent Activity</h2>
          <div className="space-y-2">
            {RECENT_ACTIVITY.map((item, i) => (
              <div key={i} className="flex items-start gap-3 text-xs py-1.5 border-b border-atlas-border/50 last:border-0">
                <span className={`${typeColor[item.type]} shrink-0 mt-0.5`}>●</span>
                <span className="text-atlas-text flex-1">{item.text}</span>
                <span className="text-atlas-muted shrink-0">{item.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
