'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { 
  Target, 
  Zap, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle,
  Home,
  DollarSign,
  Calendar,
  FileText,
  Users,
  Activity
} from 'lucide-react'
import { clsx } from 'clsx'
import toast from 'react-hot-toast'

interface Signal {
  id: string
  label: string
  points: number
  category: 'distress' | 'equity' | 'motivation' | 'timing'
  enabled: boolean
  icon: React.ReactNode
}

const SIGNALS: Signal[] = [
  // Distress Signals
  { id: 'tax-delinquent', label: 'Tax Delinquent', points: 25, category: 'distress', enabled: false, icon: <DollarSign size={14} /> },
  { id: 'pre-foreclosure', label: 'Pre-Foreclosure', points: 30, category: 'distress', enabled: false, icon: <AlertTriangle size={14} /> },
  { id: 'code-violation', label: 'Code Violation', points: 15, category: 'distress', enabled: false, icon: <FileText size={14} /> },
  { id: 'vacant', label: 'Vacant Property', points: 20, category: 'distress', enabled: false, icon: <Home size={14} /> },
  
  // Equity Signals
  { id: 'high-equity', label: 'High Equity (60%+)', points: 20, category: 'equity', enabled: false, icon: <TrendingUp size={14} /> },
  { id: 'free-clear', label: 'Free & Clear', points: 25, category: 'equity', enabled: false, icon: <CheckCircle size={14} /> },
  { id: 'low-mortgage', label: 'Low Mortgage Balance', points: 15, category: 'equity', enabled: false, icon: <DollarSign size={14} /> },
  
  // Motivation Signals
  { id: 'absentee-owner', label: 'Absentee Owner', points: 15, category: 'motivation', enabled: false, icon: <Users size={14} /> },
  { id: 'inherited', label: 'Inherited Property', points: 20, category: 'motivation', enabled: false, icon: <FileText size={14} /> },
  { id: 'divorce', label: 'Divorce Filing', points: 25, category: 'motivation', enabled: false, icon: <Users size={14} /> },
  { id: 'tired-landlord', label: 'Tired Landlord', points: 15, category: 'motivation', enabled: false, icon: <Home size={14} /> },
  
  // Timing Signals
  { id: 'long-dom', label: 'Long Days on Market', points: 10, category: 'timing', enabled: false, icon: <Calendar size={14} /> },
  { id: 'expired-listing', label: 'Expired Listing', points: 15, category: 'timing', enabled: false, icon: <Calendar size={14} /> },
  { id: 'fsbo', label: 'FSBO', points: 10, category: 'timing', enabled: false, icon: <Home size={14} /> },
]

const CATEGORY_COLORS = {
  distress: { bg: 'bg-atlas-red/20', border: 'border-atlas-red/30', text: 'text-atlas-red' },
  equity: { bg: 'bg-atlas-green/20', border: 'border-atlas-green/30', text: 'text-atlas-green' },
  motivation: { bg: 'bg-atlas-purple/20', border: 'border-atlas-purple/30', text: 'text-atlas-purple' },
  timing: { bg: 'bg-atlas-gold/20', border: 'border-atlas-gold/30', text: 'text-atlas-gold' },
}

export function SignalStack() {
  const { consumeCredits, addAgentRun } = useAtlasStore()
  const [signals, setSignals] = useState(SIGNALS)
  const [address, setAddress] = useState('')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<{
    score: number
    grade: string
    verdict: string
    triggered: boolean
  } | null>(null)

  const totalScore = signals.filter(s => s.enabled).reduce((sum, s) => sum + s.points, 0)
  const enabledCount = signals.filter(s => s.enabled).length

  function toggleSignal(id: string) {
    setSignals(signals.map(s => s.id === id ? { ...s, enabled: !s.enabled } : s))
    setResult(null)
  }

  function getGrade(score: number): string {
    if (score >= 80) return 'A'
    if (score >= 60) return 'B'
    if (score >= 40) return 'C'
    if (score >= 20) return 'D'
    return 'F'
  }

  function getVerdict(score: number): string {
    if (score >= 80) return '🔥 CRITICAL — Deploy 4-Agent Pod Immediately'
    if (score >= 60) return '⚡ HOT — High Priority Lead'
    if (score >= 40) return '🌡️ WARM — Worth Following Up'
    if (score >= 20) return '❄️ COOL — Monitor Only'
    return '🧊 COLD — Low Priority'
  }

  async function runSignalStack() {
    if (!address.trim()) {
      toast.error('Enter a property address')
      return
    }

    if (enabledCount === 0) {
      toast.error('Enable at least one signal')
      return
    }

    if (!consumeCredits(8)) {
      toast.error('Insufficient credits')
      return
    }

    setIsAnalyzing(true)

    // Log agent run
    addAgentRun({
      id: crypto.randomUUID(),
      agent_type: 'orchestrator',
      status: 'running',
      input: `Signal Stack: ${address}`,
      credits_consumed: 8,
      created_at: new Date().toISOString(),
    })

    // Simulate analysis
    await new Promise(r => setTimeout(r, 2000))

    const score = Math.min(totalScore + Math.floor(Math.random() * 10), 100)
    const triggered = score >= 80

    setResult({
      score,
      grade: getGrade(score),
      verdict: getVerdict(score),
      triggered
    })

    setIsAnalyzing(false)
    toast.success('Signal analysis complete!')
  }

  const groupedSignals = {
    distress: signals.filter(s => s.category === 'distress'),
    equity: signals.filter(s => s.category === 'equity'),
    motivation: signals.filter(s => s.category === 'motivation'),
    timing: signals.filter(s => s.category === 'timing'),
  }

  return (
    <div className="space-y-4 max-w-4xl">
      {/* Header */}
      <div className="atlas-panel p-4 rounded-xl border border-atlas-purple/20 bg-gradient-to-r from-atlas-purple/5 to-transparent">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-atlas-purple/20 flex items-center justify-center">
            <Target size={20} className="text-atlas-purple" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Signal Stack Engine</h2>
            <p className="text-xs text-atlas-muted">Multi-Factor Lead Scoring System</p>
          </div>
        </div>
      </div>

      {/* Address Input */}
      <div className="atlas-panel p-4 rounded-xl">
        <div className="flex gap-3">
          <input
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Enter property address (e.g., 412 Elm St, Charleston, WV 25301)"
            className="flex-1 bg-atlas-dark border border-atlas-border rounded-lg px-4 py-2.5 text-sm text-atlas-text placeholder-atlas-muted focus:outline-none focus:border-atlas-accent"
          />
          <button
            onClick={runSignalStack}
            disabled={isAnalyzing}
            className="px-5 py-2.5 rounded-lg bg-atlas-purple text-white font-semibold text-sm hover:bg-atlas-purple/80 disabled:opacity-50 transition-all flex items-center gap-2"
          >
            {isAnalyzing ? (
              <>
                <Activity size={16} className="animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Zap size={16} />
                Run Stack (8 cr)
              </>
            )}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {/* Signal Categories */}
        {Object.entries(groupedSignals).map(([category, categorySignals]) => {
          const colors = CATEGORY_COLORS[category as keyof typeof CATEGORY_COLORS]
          const categoryTotal = categorySignals.filter(s => s.enabled).reduce((sum, s) => sum + s.points, 0)
          
          return (
            <div key={category} className="atlas-panel p-4 rounded-xl">
              <div className="flex items-center justify-between mb-3">
                <h3 className={clsx('text-xs font-bold uppercase', colors.text)}>
                  {category}
                </h3>
                <span className={clsx('text-xs font-mono px-1.5 py-0.5 rounded', colors.bg, colors.text)}>
                  +{categoryTotal}
                </span>
              </div>
              <div className="space-y-2">
                {categorySignals.map(signal => (
                  <button
                    key={signal.id}
                    onClick={() => toggleSignal(signal.id)}
                    className={clsx(
                      'w-full flex items-center gap-2 p-2 rounded-lg text-xs transition-all text-left',
                      signal.enabled
                        ? `${colors.bg} ${colors.border} border ${colors.text}`
                        : 'bg-atlas-dark border border-atlas-border text-atlas-muted hover:text-atlas-text'
                    )}
                  >
                    {signal.icon}
                    <span className="flex-1">{signal.label}</span>
                    <span className="font-mono">+{signal.points}</span>
                  </button>
                ))}
              </div>
            </div>
          )
        })}
      </div>

      {/* Score Display */}
      <div className="atlas-panel p-6 rounded-xl">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs text-atlas-muted uppercase tracking-wider mb-1">Total Signal Score</div>
            <div className="flex items-baseline gap-3">
              <span className={clsx(
                'text-5xl font-bold font-mono',
                totalScore >= 80 ? 'text-atlas-red' :
                totalScore >= 60 ? 'text-atlas-gold' :
                totalScore >= 40 ? 'text-atlas-accent' :
                'text-atlas-muted'
              )}>
                {totalScore}
              </span>
              <span className="text-atlas-muted">/100</span>
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-xs text-atlas-muted mb-1">{enabledCount} signals enabled</div>
            <div className="w-48 bg-atlas-border rounded-full h-2">
              <div
                className={clsx(
                  'h-2 rounded-full transition-all',
                  totalScore >= 80 ? 'bg-atlas-red' :
                  totalScore >= 60 ? 'bg-atlas-gold' :
                  totalScore >= 40 ? 'bg-atlas-accent' :
                  'bg-atlas-muted'
                )}
                style={{ width: `${totalScore}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Result */}
      {result && (
        <div className={clsx(
          'atlas-panel p-6 rounded-xl border animate-fade-in',
          result.triggered 
            ? 'border-atlas-red/30 bg-atlas-red/5' 
            : 'border-atlas-border'
        )}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className={clsx(
                'w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold',
                result.grade === 'A' ? 'bg-atlas-red/20 text-atlas-red' :
                result.grade === 'B' ? 'bg-atlas-gold/20 text-atlas-gold' :
                result.grade === 'C' ? 'bg-atlas-accent/20 text-atlas-accent' :
                'bg-atlas-muted/20 text-atlas-muted'
              )}>
                {result.grade}
              </div>
              <div>
                <div className="text-lg font-bold text-white">Score: {result.score}/100</div>
                <div className="text-sm text-atlas-muted">{result.verdict}</div>
              </div>
            </div>
            
            {result.triggered && (
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-atlas-red/20 border border-atlas-red/30">
                <Zap size={16} className="text-atlas-red" />
                <span className="text-sm font-bold text-atlas-red">AGENT POD TRIGGERED</span>
              </div>
            )}
          </div>

          {result.triggered && (
            <div className="p-4 rounded-lg bg-atlas-dark border border-atlas-border mt-4">
              <div className="text-xs text-atlas-muted mb-2">Auto-Deploying 4-Agent Pod:</div>
              <div className="flex gap-2">
                {['Investigator', 'Underwriter', 'Copywriter', 'SMS Agent'].map(agent => (
                  <span
                    key={agent}
                    className="px-2 py-1 rounded text-[10px] bg-atlas-purple/20 text-atlas-purple border border-atlas-purple/30"
                  >
                    {agent}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
