'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { Search, MapPin, TrendingUp, FileText, Loader2, AlertCircle } from 'lucide-react'
import { clsx } from 'clsx'
import toast from 'react-hot-toast'

interface DossierResult {
  address: string
  owner: string
  equity_pct: number
  arv: number
  distress_score: number
  tax_delinquent: boolean
  recommended_offer: number
  sms_draft: string
  notes: string
}

export function DealNavigator() {
  const { consumeCredits, addAgentRun } = useAtlasStore()
  const [address, setAddress] = useState('')
  const [loading, setLoading] = useState(false)
  const [dossier, setDossier] = useState<DossierResult | null>(null)

  async function analyzeProperty() {
    if (!address.trim()) { toast.error('Enter a property address'); return }
    if (!consumeCredits(25)) { toast.error('Daily credit limit reached. Upgrade to Pro.'); return }

    setLoading(true)
    setDossier(null)

    const runId = crypto.randomUUID()
    addAgentRun({
      id: runId,
      agent_type: 'orchestrator',
      status: 'running',
      input: address,
      created_at: new Date().toISOString(),
    })

    try {
      const res = await fetch('/api/agents/dossier', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ address }),
      })
      const data = await res.json()
      setDossier(data)
      toast.success('Property dossier complete!')
    } catch {
      toast.error('Agent pipeline failed. Check API keys.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4 max-w-4xl">
      <div className="atlas-panel p-4 rounded-xl">
        <h2 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <MapPin size={14} className="text-atlas-accent" />
          Property Intelligence — Address Analysis
        </h2>
        <div className="flex gap-3">
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && analyzeProperty()}
            placeholder="Enter property address (e.g. 412 Elm St, Charleston, WV 25301)"
            className="flex-1 bg-atlas-dark border border-atlas-border rounded-lg px-4 py-2.5 text-sm text-atlas-text placeholder-atlas-muted focus:outline-none focus:border-atlas-accent transition-colors"
          />
          <button
            onClick={analyzeProperty}
            disabled={loading}
            className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-atlas-accent text-atlas-dark font-semibold text-sm hover:bg-atlas-accent/80 disabled:opacity-50 transition-all"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : <Search size={16} />}
            {loading ? 'Analyzing...' : 'Analyze (25 credits)'}
          </button>
        </div>
        <p className="text-[11px] text-atlas-muted mt-2">
          Runs: Investigator → Underwriter → Copywriter pipeline to produce a full Property Dossier
        </p>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="atlas-panel p-6 rounded-xl text-center space-y-3">
          <Loader2 size={32} className="animate-spin text-atlas-accent mx-auto" />
          <p className="text-atlas-text font-medium">Agent pipeline running...</p>
          <div className="flex justify-center gap-4 text-xs text-atlas-muted">
            {['🔍 Investigator', '📊 Underwriter', '✍️ Copywriter'].map((step) => (
              <span key={step} className="animate-pulse">{step}</span>
            ))}
          </div>
        </div>
      )}

      {/* Dossier Result */}
      {dossier && (
        <div className="space-y-3 animate-fade-in">
          {/* Header */}
          <div className="atlas-panel p-4 rounded-xl border border-atlas-accent/20">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-bold text-white">{dossier.address}</h3>
                <p className="text-atlas-muted text-sm">Owner: {dossier.owner}</p>
              </div>
              <div className={clsx(
                'px-3 py-1.5 rounded-full text-sm font-bold',
                dossier.distress_score > 70 ? 'badge-hot' :
                dossier.distress_score > 40 ? 'badge-warm' : 'badge-cold'
              )}>
                {dossier.distress_score}/100 Distress
              </div>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'ARV',       value: `$${dossier.arv.toLocaleString()}`,              color: 'atlas-text'   },
              { label: 'Equity',    value: `${dossier.equity_pct}%`,                        color: 'atlas-green'  },
              { label: 'Offer',     value: `$${dossier.recommended_offer.toLocaleString()}`, color: 'atlas-accent' },
              { label: 'Tax Del.',  value: dossier.tax_delinquent ? 'YES' : 'NO',           color: dossier.tax_delinquent ? 'atlas-red' : 'atlas-muted' },
            ].map((m) => (
              <div key={m.label} className="atlas-panel p-3 rounded-lg text-center">
                <div className={`text-xl font-bold text-${m.color} font-mono`}>{m.value}</div>
                <div className="text-xs text-atlas-muted mt-0.5">{m.label}</div>
              </div>
            ))}
          </div>

          {/* Analysis Notes */}
          <div className="atlas-panel p-4 rounded-xl">
            <h4 className="text-sm font-semibold text-atlas-text mb-2 flex items-center gap-2">
              <TrendingUp size={14} className="text-atlas-purple" />
              Underwriter Notes
            </h4>
            <p className="text-sm text-atlas-text leading-relaxed">{dossier.notes}</p>
          </div>

          {/* SMS Draft */}
          <div className="atlas-panel p-4 rounded-xl">
            <h4 className="text-sm font-semibold text-atlas-text mb-2 flex items-center gap-2">
              <FileText size={14} className="text-atlas-green" />
              Copywriter — SMS Draft (Touch 1)
            </h4>
            <div className="bg-atlas-dark rounded-lg p-3 text-sm text-atlas-text border border-atlas-border font-mono leading-relaxed">
              {dossier.sms_draft}
            </div>
            <button
              onClick={() => { navigator.clipboard.writeText(dossier.sms_draft); toast.success('Copied!') }}
              className="mt-2 text-xs text-atlas-accent hover:underline"
            >
              Copy to clipboard
            </button>
          </div>
        </div>
      )}

      {/* Empty State */}
      {!loading && !dossier && (
        <div className="atlas-panel p-8 rounded-xl text-center">
          <AlertCircle size={32} className="text-atlas-muted mx-auto mb-3" />
          <p className="text-atlas-muted text-sm">Enter an address above to generate a full Property Dossier</p>
        </div>
      )}
    </div>
  )
}
