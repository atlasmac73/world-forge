'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { 
  Settings as SettingsIcon, 
  Key, 
  Bell, 
  Shield, 
  Database, 
  Palette, 
  User,
  Save,
  Eye,
  EyeOff,
  CheckCircle,
  AlertCircle,
  RefreshCw
} from 'lucide-react'
import toast from 'react-hot-toast'
import { clsx } from 'clsx'

type SettingsTab = 'api-keys' | 'notifications' | 'security' | 'database' | 'appearance' | 'profile'

const TABS: { id: SettingsTab; label: string; icon: React.ReactNode }[] = [
  { id: 'api-keys',      label: 'API Keys',      icon: <Key size={16} /> },
  { id: 'profile',       label: 'Profile',       icon: <User size={16} /> },
  { id: 'notifications', label: 'Notifications', icon: <Bell size={16} /> },
  { id: 'security',      label: 'Security',      icon: <Shield size={16} /> },
  { id: 'database',      label: 'Database',      icon: <Database size={16} /> },
  { id: 'appearance',    label: 'Appearance',    icon: <Palette size={16} /> },
]

export function Settings() {
  const { apiKeys, setApiKey, safeMode, setSafeMode, wallet } = useAtlasStore()
  const [activeTab, setActiveTab] = useState<SettingsTab>('api-keys')
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [form, setForm] = useState({
    anthropic: apiKeys.anthropic ?? '',
    mapbox: apiKeys.mapbox ?? '',
    twilio_sid: apiKeys.twilio_sid ?? '',
    twilio_token: apiKeys.twilio_token ?? '',
    supabase_url: apiKeys.supabase_url ?? '',
    supabase_key: apiKeys.supabase_key ?? '',
  })
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    smsAlerts: false,
    agentComplete: true,
    creditLow: true,
    weeklyReport: true,
  })

  function saveApiKeys() {
    Object.entries(form).forEach(([key, value]) => {
      if (value) setApiKey(key as keyof typeof form, value)
    })
    toast.success('API keys saved')
  }

  function testConnection(service: string) {
    toast.loading(`Testing ${service} connection...`, { duration: 1500 })
    setTimeout(() => {
      if (form[service as keyof typeof form]) {
        toast.success(`${service} connected successfully!`)
      } else {
        toast.error(`${service} key not configured`)
      }
    }, 1500)
  }

  return (
    <div className="flex gap-4 max-w-5xl">
      {/* Sidebar */}
      <div className="w-48 shrink-0">
        <div className="atlas-panel rounded-xl p-2 space-y-0.5">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={clsx(
                'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all text-left',
                activeTab === tab.id
                  ? 'bg-atlas-accent/10 text-atlas-accent'
                  : 'text-atlas-muted hover:text-atlas-text hover:bg-white/5'
              )}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 space-y-4">
        {/* API Keys Tab */}
        {activeTab === 'api-keys' && (
          <div className="space-y-4">
            <div className="atlas-panel p-4 rounded-xl">
              <div className="flex items-center gap-2 mb-4">
                <Key size={18} className="text-atlas-gold" />
                <h2 className="text-lg font-bold text-white">API Key Configuration</h2>
              </div>
              <p className="text-xs text-atlas-muted mb-4">
                Keys are stored securely in your browser's local storage. They are never sent to ATLAS servers.
              </p>

              <div className="space-y-4">
                {[
                  { key: 'anthropic', label: 'Anthropic (Claude)', placeholder: 'sk-ant-...', required: true },
                  { key: 'supabase_url', label: 'Supabase URL', placeholder: 'https://xxx.supabase.co', required: true },
                  { key: 'supabase_key', label: 'Supabase Anon Key', placeholder: 'eyJ...', required: true },
                  { key: 'mapbox', label: 'Mapbox Token', placeholder: 'pk.eyJ...', required: false },
                  { key: 'twilio_sid', label: 'Twilio Account SID', placeholder: 'AC...', required: false },
                  { key: 'twilio_token', label: 'Twilio Auth Token', placeholder: '...', required: false },
                ].map(({ key, label, placeholder, required }) => (
                  <div key={key} className="flex items-start gap-3">
                    <div className="flex-1">
                      <label className="text-xs text-atlas-muted mb-1 flex items-center gap-2">
                        {label}
                        {required && <span className="text-atlas-red text-[10px]">Required</span>}
                        {form[key as keyof typeof form] && (
                          <CheckCircle size={12} className="text-atlas-green" />
                        )}
                      </label>
                      <div className="relative">
                        <input
                          type={showKeys[key] ? 'text' : 'password'}
                          value={form[key as keyof typeof form]}
                          onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                          placeholder={placeholder}
                          className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text placeholder-atlas-muted/50 focus:outline-none focus:border-atlas-accent pr-20 font-mono"
                        />
                        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                          <button
                            onClick={() => setShowKeys({ ...showKeys, [key]: !showKeys[key] })}
                            className="p-1 text-atlas-muted hover:text-atlas-text"
                          >
                            {showKeys[key] ? <EyeOff size={14} /> : <Eye size={14} />}
                          </button>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => testConnection(key)}
                      className="mt-5 p-2 rounded-lg border border-atlas-border text-atlas-muted hover:text-atlas-accent hover:border-atlas-accent transition-all"
                      title="Test connection"
                    >
                      <RefreshCw size={14} />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={saveApiKeys}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-atlas-accent text-atlas-dark font-semibold text-sm hover:bg-atlas-accent/80 transition-all"
                >
                  <Save size={14} />
                  Save All Keys
                </button>
              </div>
            </div>

            {/* Connection Status */}
            <div className="atlas-panel p-4 rounded-xl">
              <h3 className="text-sm font-semibold text-atlas-text mb-3">Connection Status</h3>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { name: 'Anthropic', connected: !!form.anthropic },
                  { name: 'Supabase', connected: !!form.supabase_url && !!form.supabase_key },
                  { name: 'Mapbox', connected: !!form.mapbox },
                  { name: 'Twilio', connected: !!form.twilio_sid && !!form.twilio_token },
                  { name: 'Stripe', connected: false },
                  { name: 'n8n', connected: false },
                ].map((service) => (
                  <div
                    key={service.name}
                    className={clsx(
                      'flex items-center gap-2 px-3 py-2 rounded-lg text-xs',
                      service.connected
                        ? 'bg-atlas-green/10 text-atlas-green border border-atlas-green/30'
                        : 'bg-atlas-dark text-atlas-muted border border-atlas-border'
                    )}
                  >
                    {service.connected ? <CheckCircle size={12} /> : <AlertCircle size={12} />}
                    {service.name}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="atlas-panel p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-4">
              <User size={18} className="text-atlas-accent" />
              <h2 className="text-lg font-bold text-white">Profile</h2>
            </div>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-atlas-accent to-atlas-purple flex items-center justify-center text-xl font-bold text-white">
                AT
              </div>
              <div>
                <div className="text-lg font-bold text-white">Atlas User</div>
                <div className="text-sm text-atlas-muted">user@example.com</div>
                <div className={clsx(
                  'text-xs font-bold uppercase px-2 py-0.5 rounded mt-1 w-fit',
                  wallet.plan === 'enterprise' ? 'bg-atlas-gold/20 text-atlas-gold' :
                  wallet.plan === 'pro' ? 'bg-atlas-purple/20 text-atlas-purple' :
                  'bg-atlas-muted/20 text-atlas-muted'
                )}>
                  {wallet.plan} Plan
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs text-atlas-muted mb-1 block">Display Name</label>
                <input
                  type="text"
                  defaultValue="Atlas User"
                  className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text focus:outline-none focus:border-atlas-accent"
                />
              </div>
              <div>
                <label className="text-xs text-atlas-muted mb-1 block">Email</label>
                <input
                  type="email"
                  defaultValue="user@example.com"
                  className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text focus:outline-none focus:border-atlas-accent"
                />
              </div>
              <div>
                <label className="text-xs text-atlas-muted mb-1 block">Company</label>
                <input
                  type="text"
                  defaultValue="Atlas Investments"
                  className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text focus:outline-none focus:border-atlas-accent"
                />
              </div>
            </div>

            <button className="mt-4 px-4 py-2 rounded-lg bg-atlas-accent text-atlas-dark font-semibold text-sm hover:bg-atlas-accent/80 transition-all">
              Save Profile
            </button>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="atlas-panel p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-4">
              <Bell size={18} className="text-atlas-purple" />
              <h2 className="text-lg font-bold text-white">Notification Preferences</h2>
            </div>

            <div className="space-y-3">
              {[
                { key: 'emailAlerts', label: 'Email Alerts', desc: 'Receive important alerts via email' },
                { key: 'smsAlerts', label: 'SMS Alerts', desc: 'Receive urgent alerts via SMS' },
                { key: 'agentComplete', label: 'Agent Completion', desc: 'Notify when agent runs complete' },
                { key: 'creditLow', label: 'Low Credit Warning', desc: 'Alert when credits are running low' },
                { key: 'weeklyReport', label: 'Weekly Report', desc: 'Receive weekly activity summary' },
              ].map(({ key, label, desc }) => (
                <div key={key} className="flex items-center justify-between p-3 rounded-lg bg-atlas-dark border border-atlas-border">
                  <div>
                    <div className="text-sm font-medium text-atlas-text">{label}</div>
                    <div className="text-xs text-atlas-muted">{desc}</div>
                  </div>
                  <button
                    onClick={() => setNotifications({ ...notifications, [key]: !notifications[key as keyof typeof notifications] })}
                    className={clsx(
                      'w-10 h-5 rounded-full transition-all relative',
                      notifications[key as keyof typeof notifications]
                        ? 'bg-atlas-green'
                        : 'bg-atlas-border'
                    )}
                  >
                    <div
                      className={clsx(
                        'absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all',
                        notifications[key as keyof typeof notifications] ? 'left-5' : 'left-0.5'
                      )}
                    />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Security Tab */}
        {activeTab === 'security' && (
          <div className="space-y-4">
            <div className="atlas-panel p-4 rounded-xl">
              <div className="flex items-center gap-2 mb-4">
                <Shield size={18} className="text-atlas-green" />
                <h2 className="text-lg font-bold text-white">Security Settings</h2>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg bg-atlas-dark border border-atlas-border">
                  <div>
                    <div className="text-sm font-medium text-atlas-text">Safe Mode</div>
                    <div className="text-xs text-atlas-muted">Require confirmation for high-cost actions</div>
                  </div>
                  <button
                    onClick={() => setSafeMode(!safeMode)}
                    className={clsx(
                      'w-10 h-5 rounded-full transition-all relative',
                      safeMode ? 'bg-atlas-green' : 'bg-atlas-border'
                    )}
                  >
                    <div
                      className={clsx(
                        'absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all',
                        safeMode ? 'left-5' : 'left-0.5'
                      )}
                    />
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-atlas-dark border border-atlas-border">
                  <div>
                    <div className="text-sm font-medium text-atlas-text">Two-Factor Authentication</div>
                    <div className="text-xs text-atlas-muted">Add an extra layer of security</div>
                  </div>
                  <button className="px-3 py-1 rounded text-xs border border-atlas-accent text-atlas-accent hover:bg-atlas-accent/10 transition-all">
                    Enable
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 rounded-lg bg-atlas-dark border border-atlas-border">
                  <div>
                    <div className="text-sm font-medium text-atlas-text">Active Sessions</div>
                    <div className="text-xs text-atlas-muted">Manage your active login sessions</div>
                  </div>
                  <span className="text-xs text-atlas-accent">1 active</span>
                </div>
              </div>
            </div>

            <div className="atlas-panel p-4 rounded-xl border border-atlas-red/30">
              <h3 className="text-sm font-semibold text-atlas-red mb-2">Danger Zone</h3>
              <div className="flex items-center justify-between">
                <div className="text-xs text-atlas-muted">
                  Delete all data and close your account
                </div>
                <button className="px-3 py-1 rounded text-xs bg-atlas-red/20 text-atlas-red border border-atlas-red/30 hover:bg-atlas-red/30 transition-all">
                  Delete Account
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Database Tab */}
        {activeTab === 'database' && (
          <div className="atlas-panel p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-4">
              <Database size={18} className="text-atlas-accent" />
              <h2 className="text-lg font-bold text-white">Database & Storage</h2>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="p-3 rounded-lg bg-atlas-dark border border-atlas-border text-center">
                <div className="text-xl font-bold text-atlas-accent font-mono">247</div>
                <div className="text-xs text-atlas-muted">Properties</div>
              </div>
              <div className="p-3 rounded-lg bg-atlas-dark border border-atlas-border text-center">
                <div className="text-xl font-bold text-atlas-green font-mono">38</div>
                <div className="text-xs text-atlas-muted">Leads</div>
              </div>
              <div className="p-3 rounded-lg bg-atlas-dark border border-atlas-border text-center">
                <div className="text-xl font-bold text-atlas-purple font-mono">142</div>
                <div className="text-xs text-atlas-muted">Agent Runs</div>
              </div>
            </div>

            <div className="space-y-2">
              <button className="w-full flex items-center justify-between p-3 rounded-lg bg-atlas-dark border border-atlas-border text-sm hover:border-atlas-accent/30 transition-all">
                <span className="text-atlas-text">Export All Data</span>
                <span className="text-atlas-accent">JSON</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 rounded-lg bg-atlas-dark border border-atlas-border text-sm hover:border-atlas-accent/30 transition-all">
                <span className="text-atlas-text">Clear Local Cache</span>
                <span className="text-atlas-muted">2.4 MB</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 rounded-lg bg-atlas-dark border border-atlas-border text-sm hover:border-atlas-accent/30 transition-all">
                <span className="text-atlas-text">Sync with Supabase</span>
                <span className="text-atlas-green">Connected</span>
              </button>
            </div>
          </div>
        )}

        {/* Appearance Tab */}
        {activeTab === 'appearance' && (
          <div className="atlas-panel p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-4">
              <Palette size={18} className="text-atlas-purple" />
              <h2 className="text-lg font-bold text-white">Appearance</h2>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs text-atlas-muted mb-2 block">Theme</label>
                <div className="grid grid-cols-3 gap-2">
                  {['Dark', 'Light', 'System'].map((theme) => (
                    <button
                      key={theme}
                      className={clsx(
                        'p-3 rounded-lg text-sm border transition-all',
                        theme === 'Dark'
                          ? 'border-atlas-accent bg-atlas-accent/10 text-atlas-accent'
                          : 'border-atlas-border text-atlas-muted hover:border-atlas-accent/30'
                      )}
                    >
                      {theme}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-atlas-muted mb-2 block">Accent Color</label>
                <div className="flex gap-2">
                  {[
                    { color: '#00d4ff', name: 'Cyan' },
                    { color: '#7c3aed', name: 'Purple' },
                    { color: '#00ff88', name: 'Green' },
                    { color: '#ffd700', name: 'Gold' },
                    { color: '#ff4444', name: 'Red' },
                  ].map(({ color, name }) => (
                    <button
                      key={name}
                      className={clsx(
                        'w-8 h-8 rounded-lg border-2 transition-all',
                        color === '#00d4ff' ? 'border-white' : 'border-transparent'
                      )}
                      style={{ backgroundColor: color }}
                      title={name}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-atlas-muted mb-2 block">Font Size</label>
                <input
                  type="range"
                  min="12"
                  max="18"
                  defaultValue="14"
                  className="w-full"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
