import { useState, useEffect } from "react";

// ═══════════════════════════════════════════════════════════════
// ATLAS GENESIS MASTER IP BIBLE — ALL DOCUMENTS COMBINED
// Sources: 13 uploaded docs + all session history
// ═══════════════════════════════════════════════════════════════

const SECTIONS = [
  { id: "overview",    icon: "⚡", label: "ATLAS OS",        sub: "Platform Definition" },
  { id: "portals",     icon: "🌐", label: "PORTALS",         sub: "50 Total" },
  { id: "agents",      icon: "🤖", label: "AGENTS",          sub: "255+ Hierarchy" },
  { id: "modes",       icon: "🎛️", label: "7 MODES",         sub: "UI Operational" },
  { id: "connectors",  icon: "🔌", label: "CONNECTORS",      sub: "Universal Network" },
  { id: "skills",      icon: "🧠", label: "500 SKILLS",      sub: "Patentable" },
  { id: "genesis",     icon: "♾️", label: "GENESIS CYCLE",   sub: "Autopoietic Engine" },
  { id: "sovereignty", icon: "🔐", label: "SOVEREIGNTY",     sub: "Data Vault" },
  { id: "game",        icon: "🌍", label: "GAME UNIVERSE",   sub: "World Engine" },
  { id: "transmedia",  icon: "📚", label: "TRANSMEDIA",      sub: "13-Book Saga" },
  { id: "patents",     icon: "📋", label: "IP / PATENTS",    sub: "4 Filed" },
  { id: "hardware",    icon: "💻", label: "HARDWARE",        sub: "Scaling Tiers" },
  { id: "roadmap",     icon: "🗺️", label: "ROADMAP",         sub: "v9 → v34" },
];

// ─── PORTAL DATA (Combined: 17-portal blueprint + 50-portal universe) ──────
const PORTALS = [
  // CORE PLATFORM PORTALS (from Blueprint Messages 1-7)
  { id:1,  name:"Home OS Portal",          tier:"CORE",        status:"live",    version:"v22", domain:"home",          desc:"Personal AI dashboard. Universal input hub. The command center for everything ATLAS." },
  { id:2,  name:"Research Portal",          tier:"CORE",        status:"live",    version:"v22", domain:"intelligence",  desc:"Deep research, knowledge exploration, semantic graph search, claim-centric reasoning." },
  { id:3,  name:"Creator Portal",           tier:"CORE",        status:"live",    version:"v22", domain:"media",         desc:"Writing, media, content generation. All output formats from one natural language prompt." },
  { id:4,  name:"Build Portal",             tier:"CORE",        status:"live",    version:"v22", domain:"engineering",   desc:"Software and product creation. Claude Code + Google Antigravity + autonomous deploy." },
  { id:5,  name:"Business Portal",          tier:"CORE",        status:"live",    version:"v22", domain:"operations",    desc:"Strategy, operations, analytics, financial modeling, deal pipeline." },
  { id:6,  name:"Collaboration Portal",     tier:"CORE",        status:"live",    version:"v22", domain:"comms",         desc:"Live sessions, voice/video/screen share, AI assistance, transcript → artifact pipeline." },
  { id:7,  name:"Education Portal",         tier:"CORE",        status:"live",    version:"v22", domain:"education",     desc:"Learning, tutoring, ATLAS Academy certification, Appalachian market mastery courses." },
  { id:8,  name:"Family Archive Portal",    tier:"PERSONAL",    status:"planned", version:"v27", domain:"archive",       desc:"Personal and family knowledge preservation. Private world graph. Sovereign data vault." },
  { id:9,  name:"Health Admin Portal",      tier:"PERSONAL",    status:"planned", version:"v27", domain:"health",        desc:"Medical documentation organization. HIPAA-compliant. Offline Ollama mode available." },
  { id:10, name:"Legal Document Portal",    tier:"LEGAL",       status:"built",   version:"v22", domain:"legal",         desc:"Contract analysis, LOI generation, WV compliance, Dodd-Frank, fair housing, title cure." },
  { id:11, name:"Real Estate Portal",       tier:"CORE",        status:"live",    version:"v22", domain:"real-estate",   desc:"The flagship revenue product. Distress scoring, skip trace, deal pipeline, investor CRM." },
  { id:12, name:"Agent Foundry Portal",     tier:"AI-CORE",     status:"live",    version:"v22", domain:"ai",            desc:"Create, manage, breed, and rent AI agents. Agent marketplace. 255+ agent registry." },
  { id:13, name:"Automation Portal",        tier:"AI-CORE",     status:"live",    version:"v22", domain:"operations",    desc:"n8n workflow builder. Zapier-killer. Trigger→Input→Process→Generate→Output grammar." },
  { id:14, name:"Community Portal",         tier:"MARKETPLACE", status:"planned", version:"v26", domain:"marketplace",   desc:"Publishing, social collaboration. Agent marketplace. Recipes, skills, world templates." },
  { id:15, name:"Data Science Portal",      tier:"INTELLIGENCE",status:"planned", version:"v26", domain:"intelligence",  desc:"Analytics, modeling, vector DB, Snowflake/BigQuery, ETL from 140+ sources." },
  { id:16, name:"Simulation Portal",        tier:"AI-CORE",     status:"planned", version:"v26", domain:"simulation",    desc:"Experiment worlds, scenario testing, Monte Carlo modeling, deal scenario simulator." },
  { id:17, name:"Genesis Portal",           tier:"OMEGA",       status:"live",    version:"v22", domain:"system",        desc:"System evolution and governance. The autopoietic self-improvement core. $5/cycle cap." },
  // REAL ESTATE INTELLIGENCE PORTALS
  { id:18, name:"Investor Portal",          tier:"RE-CORE",     status:"live",    version:"v22", domain:"real-estate",   desc:"Lead revenue product. ~70% complete. Distress scoring, deal pipeline, investor CRM." },
  { id:19, name:"Agent Portal",             tier:"RE-CORE",     status:"live",    version:"v22", domain:"real-estate",   desc:"MLS integration, buyer matching, commission tracking, lead assignment." },
  { id:20, name:"Contractor Portal",        tier:"RE-CORE",     status:"live",    version:"v22", domain:"real-estate",   desc:"Rehab bids, job dispatch, contractor ratings, REHAB-AI scope of work generator." },
  { id:21, name:"Homeowner/PM Portal",      tier:"RE-CORE",     status:"live",    version:"v22", domain:"real-estate",   desc:"Property management, equity tracker, rental income, maintenance AI." },
  { id:22, name:"War Room",                 tier:"RE-CORE",     status:"live",    version:"v22", domain:"operations",    desc:"Live signal dashboard. All agent activity, deal flow, SMS replies, AIN real-time ops." },
  { id:23, name:"God Mode",                 tier:"OMEGA",       status:"live",    version:"v22", domain:"system",        desc:"Shift+nasdrop. Genesis Cycle control, 25-agent God Squad, mutation approval queue." },
  { id:24, name:"Deal Navigator",           tier:"RE-EXPAND",   status:"built",   version:"v22", domain:"real-estate",   desc:"GPS driving for dollars. Mapbox heatmaps, property pin drop, mobile-first offline PWA." },
  { id:25, name:"Skip Trace Command",       tier:"RE-EXPAND",   status:"planned", version:"v25", domain:"intelligence",  desc:"SKIPTRACE-X. Owner lookup, phone/email append, lien scan, bankruptcy. AI-powered." },
  { id:26, name:"Tax Sale Monitor",         tier:"RE-EXPAND",   status:"planned", version:"v25", domain:"intelligence",  desc:"County tax sale calendar. Bid tracking, redemption alerts, title cure estimator." },
  { id:27, name:"Pre-Foreclosure Radar",    tier:"RE-EXPAND",   status:"planned", version:"v26", domain:"intelligence",  desc:"NOD → NOS → Auction pipeline. 90-day window optimization. Automated seller contact." },
  { id:28, name:"Probate Intelligence",     tier:"RE-EXPAND",   status:"planned", version:"v25", domain:"intelligence",  desc:"Probate notice scraping. Heir property detection. Compassionate outreach sequences." },
  { id:29, name:"Wholesale Exchange",       tier:"MARKETPLACE", status:"planned", version:"v26", domain:"marketplace",   desc:"Buyer network marketplace. Deal assignment board. JV partner matching. COMPS-ENGINE." },
  { id:30, name:"Rehab Command Center",     tier:"RE-EXPAND",   status:"planned", version:"v25", domain:"operations",    desc:"REHAB-AI estimates. Contractor dispatch. Progress photo AI. Scope of work builder." },
  { id:31, name:"AIN Signal Stack",         tier:"INTELLIGENCE",status:"built",   version:"v22", domain:"intelligence",  desc:"Appalachian Intelligence Network. 55 WV counties → 50 states. Self-reinforcing data moat." },
  { id:32, name:"LOI Forge",                tier:"LEGAL",       status:"planned", version:"v23", domain:"legal",         desc:"Automated Letter of Intent + Purchase Agreement. WV law compliant. NEGOTIATOR agent." },
  { id:33, name:"Title & Closing Hub",      tier:"LEGAL",       status:"planned", version:"v26", domain:"legal",         desc:"TITLEBOT. Title search, cloud cure, heir property, WV closing checklist automation." },
  // SUPER-APP EXPANSION
  { id:34, name:"Voice Agent Portal",       tier:"COMMS",       status:"built",   version:"v22", domain:"comms",         desc:"ElevenLabs + Twilio. Inbound/outbound AI seller calls, qualification trees, barge-in." },
  { id:35, name:"Comms Hub",                tier:"COMMS",       status:"live",    version:"v22", domain:"comms",         desc:"7-touch SMS/email sequences, call log, Twilio, Resend, 30+ outreach campaign types." },
  { id:36, name:"SP6 Wallet",               tier:"BILLING",     status:"live",    version:"v22", domain:"billing",       desc:"Credit system, Stripe billing gate, daily limits, plan management, usage metering." },
  { id:37, name:"Neo4j Knowledge Graph",    tier:"INTELLIGENCE",status:"planned", version:"v26", domain:"intelligence",  desc:"Property→owner→lien→contractor→buyer relationship graph. Semantic graph search." },
  { id:38, name:"LangGraph Genesis Engine", tier:"AI-CORE",     status:"built",   version:"v23", domain:"ai",            desc:"State machine: SENSE→INTERPRET→MUTATE→SIMULATE→PROMOTE→LEARN. 15-min cron." },
  { id:39, name:"n8n Automation Bridge",    tier:"AI-CORE",     status:"planned", version:"v26", domain:"operations",    desc:"External workflow automation. n8n webhook orchestration. 1000+ integration templates." },
  { id:40, name:"ATLAS Analytics",          tier:"INTELLIGENCE",status:"planned", version:"v27", domain:"intelligence",  desc:"Full platform analytics. Conversion funnels, credit ROI, agent performance benchmarking." },
  // MEDIA / TRANSMEDIA PORTALS
  { id:41, name:"Transmedia Studio",        tier:"MEDIA",       status:"planned", version:"v24", domain:"media",         desc:"Book, film, music, YouTube hub. ATLAS Code narrative engine. 13-saga architecture." },
  { id:42, name:"YouTube Intelligence",     tier:"MEDIA",       status:"planned", version:"v27", domain:"media",         desc:"AI-script WV real estate content. Auto-edit, upload, SEO optimize. 1M sub target Y1." },
  { id:43, name:"Book Engine",              tier:"MEDIA",       status:"planned", version:"v28", domain:"media",         desc:"The ATLAS Code — 13-book saga. AI co-author. Amazon KDP + major publisher pitch." },
  { id:44, name:"Music Anthem Studio",      tier:"MEDIA",       status:"planned", version:"v28", domain:"media",         desc:"Original ATLAS brand anthem. AI composition + human production. Spotify distribution." },
  { id:45, name:"Interactive Story Engine", tier:"FRANCHISE",   status:"vision",  version:"v30", domain:"game",          desc:"The ATLAS Code as choose-your-own-adventure. Real data integration into narrative." },
  // GAME UNIVERSE PORTALS
  { id:46, name:"ATLAS World Engine",       tier:"METAVERSE",   status:"vision",  version:"v34", domain:"game",          desc:"1:1 real-scale physics simulation. Real GPS coordinates → virtual world mesh. UE5." },
  { id:47, name:"Forza Mode Portal",        tier:"METAVERSE",   status:"vision",  version:"v34", domain:"game",          desc:"Real WV roads, LIDAR terrain, elevation → driveable 1:1 game world. NFT vehicles." },
  { id:48, name:"GTA Mode Portal",          tier:"METAVERSE",   status:"vision",  version:"v34", domain:"game",          desc:"Open-world Appalachia. Real property data as in-game real estate. Virtual-to-real deals." },
  { id:49, name:"Minecraft Mode Portal",    tier:"METAVERSE",   status:"vision",  version:"v34", domain:"game",          desc:"Voxel Appalachia from real terrain. Build on real parcels. Cross-world object transfer." },
  { id:50, name:"ZEUS Command Bridge",      tier:"OMEGA",       status:"vision",  version:"v34", domain:"system",        desc:"The apex. ZEUS orchestrates all 50 portals, 400+ agents, 195 markets simultaneously." },
];

// ─── AGENT HIERARCHY (12 Layers) ────────────────────────────────────────────
const AGENT_LAYERS = [
  { layer:"L0",  name:"Human Architect",         count:1,    color:"#ffd700", desc:"You. High-level intent, delegation, and quality review. The only human in the loop." },
  { layer:"L1",  name:"ZEUS Orchestrator",       count:1,    color:"#ff4488", desc:"OMEGA agent. Receives all goals from L0. Routes to domain commanders. $5/cycle kill switch." },
  { layer:"L2",  name:"Domain Commanders",       count:12,   color:"#ff6b35", desc:"One per portal domain. ORACLE, SENTINEL, CARTOGRAPHER, UNDERWRITER, etc. Strategic directors." },
  { layer:"L3",  name:"Squad Leaders",           count:25,   color:"#a855f7", desc:"God Squad agents. SKIPTRACE-X, REHAB-AI, NEGOTIATOR, LOI-FORGE, MUTATION-ENGINE, SIMULATOR..." },
  { layer:"L4",  name:"Specialist Agents",       count:48,   color:"#8b5cf6", desc:"Domain experts. MLS scrapers, county records agents, voice qualification, comps engine." },
  { layer:"L5",  name:"Task Agents",             count:80,   color:"#3b82f6", desc:"Single-purpose execution units. Each runs one task type. Spawn, execute, return, dissolve." },
  { layer:"L6",  name:"Research Agents",         count:30,   color:"#06b6d4", desc:"Deep research, web scraping, document parsing, entity extraction, claim verification." },
  { layer:"L7",  name:"Creation Agents",         count:25,   color:"#00d4ff", desc:"Writing, media generation, screenplay, music, code, content bundles, artifact packages." },
  { layer:"L8",  name:"Engineering Agents",      count:20,   color:"#00ff88", desc:"Code generation, refactoring, test writing, deployment, vulnerability scanning." },
  { layer:"L9",  name:"Analysis Agents",         count:20,   color:"#84cc16", desc:"Financial modeling, distress scoring, risk assessment, market analytics, deal simulation." },
  { layer:"L10", name:"Evaluation Agents",       count:10,   color:"#f59e0b", desc:"Quality gates. Score every agent run. ACE loop: extract skills from runs > 0.85 quality." },
  { layer:"L11", name:"Automation Agents",       count:15,   color:"#ef4444", desc:"Workflow execution. n8n triggers, cron jobs, webhook handlers, event routing." },
  { layer:"L12", name:"Simulation Agents",       count:15,   color:"#f97316", desc:"Scenario worlds, Monte Carlo runs, reality modeling, physics simulation, stress testing." },
];

// ─── 7 UI MODES ─────────────────────────────────────────────────────────────
const UI_MODES = [
  { name:"Focus Mode",      shortcut:"",          color:"#00d4ff", desc:"Distraction-free deep work. Gemini Flash for fast low-latency completions. Writing, ideation, single-threaded research." },
  { name:"Split Mode",      shortcut:"Cmd+L",     color:"#a855f7", desc:"Editor alongside Agent Side Panel. Everyday collaborative mode. Agent watches, suggests, tracks changes in real time." },
  { name:"Copilot Mode",    shortcut:"Tab",        color:"#00ff88", desc:"Omnipresent assistant in terminal + editor. Inline commands + Tab-to-Jump predictions. Zero flow disruption." },
  { name:"Widget Mode",     shortcut:"",          color:"#ffd700", desc:"Floating agent interfaces via Vercel AI SDK. useChat streaming. Quick repeatable actions without opening full app." },
  { name:"Command Center",  shortcut:"",          color:"#ff6b35", desc:"Manager view. Spawn + monitor multiple agents across workspaces. Review summaries, manage by exception." },
  { name:"War Room",        shortcut:"",          color:"#ff4488", desc:"Multi-fleet dashboard. Agents across cloud, bare-metal, local. Live bandwidth meters, activity pulses." },
  { name:"Voice Agent Mode",shortcut:"🎤",        color:"#8b5cf6", desc:"Copilot Studio + Twilio + ElevenLabs. Barge-in capable. SSML natural pitch/tone. Full voice control." },
];

// ─── CONNECTOR NETWORK ──────────────────────────────────────────────────────
const CONNECTORS = [
  { category:"Cloud Storage",    items:["Google Drive","Dropbox","OneDrive","Box","S3","Supabase Storage"] },
  { category:"Email & Comms",    items:["Gmail","Outlook","Slack","Twilio SMS","Twilio Voice","Discord","Resend"] },
  { category:"Calendar",         items:["Google Calendar","Outlook Calendar","Calendly","Cal.com"] },
  { category:"Documents",        items:["Google Docs","Notion","Confluence","SharePoint","Airtable"] },
  { category:"Code Repos",       items:["GitHub","GitLab","Bitbucket","Linear","Jira","Vercel"] },
  { category:"Databases",        items:["Supabase/Postgres","MongoDB","Redis/Upstash","Neo4j","Pinecone","Weaviate"] },
  { category:"Real Estate Data", items:["WVMLS RESO API","PropStream","ATTOM Data","BatchSkipTracing","WV Tax Dept API","Zillow","Redfin"] },
  { category:"AI Providers",     items:["Anthropic Claude","OpenAI GPT","Google Gemini","Ollama (local)","Mistral","Llama 3","ElevenLabs"] },
  { category:"Finance",          items:["Stripe","Plaid","QuickBooks","Xero","Coinbase","Chime API"] },
  { category:"Media Platforms",  items:["YouTube","Spotify","Amazon KDP","TikTok","Instagram","Twitter/X"] },
  { category:"Maps & Location",  items:["Mapbox","Google Maps","USGS LIDAR","OpenStreetMap","GPS/Geolocation API","ArcGIS"] },
  { category:"Automation",       items:["n8n","Zapier","Make (Integromat)","Inngest","BullMQ","Vercel Cron"] },
];

// ─── SKILLS CATEGORIES (from 500 Patentable Skills doc) ─────────────────────
const SKILL_CLUSTERS = [
  { cluster:"Document Intelligence",   count:45, examples:["PDF extraction","Contract clause parsing","Entity extraction","Timeline generation","Argument mapping"] },
  { cluster:"Real Estate AI",          count:55, examples:["Distress scoring 0-100","Skip trace multi-source","Comp engine AI","Rehab cost estimator","Deal scenario simulator"] },
  { cluster:"Code Generation",         count:60, examples:["Full-stack scaffolding","Test generation","Vulnerability scan","Automated refactor","Deployment pipeline"] },
  { cluster:"Data Transformation",     count:50, examples:["Any format → any output","CSV→JSON→Graph","Audio→transcript→claim","Video→structured summary","Image→metadata"] },
  { cluster:"Agent Orchestration",     count:45, examples:["DAG planner","Agent breeding","Skill extraction (ACE)","Friction detection","Quality scoring"] },
  { cluster:"Knowledge Graph",         count:40, examples:["Claim normalization","Semantic search","Relationship discovery","Entity linking","Concept clustering"] },
  { cluster:"Communication AI",        count:35, examples:["7-touch SMS sequences","Voice qualification trees","Email personalization","SSML voice synthesis","Barge-in detection"] },
  { cluster:"Financial Modeling",      count:40, examples:["Monte Carlo 1000-run","Risk-adjusted ROI","Cap rate analysis","ARV calculator","Debt coverage ratio"] },
  { cluster:"Media & Content",         count:50, examples:["Book chapter generation","Screenplay formatting","Music composition","YouTube SEO script","Brand anthem creation"] },
  { cluster:"Game & Simulation",       count:35, examples:["1:1 physics modeling","Voxel terrain from GPS","Real material properties","Cross-world object transfer","NPC persona generation"] },
  { cluster:"Sovereignty & Security",  count:45, examples:["Client-side encryption","Entity blacklisting","Cryptographic deletion","Consent marketplace","Jurisdiction governance"] },
  { cluster:"World Building",          count:50, examples:["World graph creation","Artifact provenance","Session intelligence","Recipe extraction","CRDT convergence"] },
];

// ─── GENESIS CYCLE ───────────────────────────────────────────────────────────
const GENESIS_PHASES = [
  { phase:"SENSE",    color:"#00d4ff", icon:"👁️", desc:"Langfuse monitors all agent runs for friction patterns: high latency, low quality_score, repeated errors, user abandonment. Passive surveillance of the entire system." },
  { phase:"INTERPRET",color:"#a855f7", icon:"🧩", desc:"Claude Sonnet analyzes friction signals. Identifies root cause, affected agent, evidence gaps. Generates structured diagnosis with confidence score." },
  { phase:"MUTATE",   color:"#ff6b35", icon:"🧬", desc:"Claude proposes code/config/prompt patch for affected agent. Max $0.50/call. Generates mutation with expected performance delta. $5/cycle budget kill switch." },
  { phase:"SIMULATE", color:"#00ff88", icon:"⚗️", desc:"Docker sandbox + Playwright regression tests. Patched agent runs against historical test harness. Must pass 95+ score threshold to proceed." },
  { phase:"PROMOTE",  color:"#ffd700", icon:"🚀", desc:"GitHub API creates PR on experiment/genesis-mutations branch. Human approval gate before merge to main. Auto-merge if score ≥ 95 and no human objection in 24h." },
  { phase:"LEARN",    color:"#ff4488", icon:"📡", desc:"ACE loop extracts reusable skill from successful run (score ≥ 0.85). Stores to atlas_skills with pgvector embedding. Calibrates future SENSE sensitivity." },
];

// ─── SOVEREIGNTY VAULT ───────────────────────────────────────────────────────
const SOVEREIGNTY_FEATURES = [
  { name:"Client-Side Encryption",      icon:"🔑", desc:"All data encrypted on user's device before transmission. Platform operator cannot access under any operational condition. User holds all keys." },
  { name:"Corporate Blacklist",         icon:"🚫", desc:"Cryptographically-enforced entity blacklist. Users block specific named corporations from ANY access to their data. Not just a policy — a technical lock." },
  { name:"Cryptographic Deletion",      icon:"🗑️", desc:"Pre-deletion hash commitment + verifiable certificate. Proof that data was destroyed, not just hidden. No soft deletes." },
  { name:"Data Jurisdiction Choice",    icon:"🌍", desc:"Users outside high-protection jurisdictions can opt into stronger legal frameworks (GDPR, Swiss DSG). Your choice, not the platform's." },
  { name:"Consent-Compensated Marketplace",icon:"💰",desc:"Set terms, pricing, and authorized use cases for your data in AI training. Cryptographically-enforced compliance. Automated compensation on each training event." },
  { name:"Agent Breeding & Rental",     icon:"🤖", desc:"Train specialized agents from your own workflows. Combine agent capabilities. Publish to marketplace. Receive automated compensation when others use your agent." },
  { name:"Ollama Sovereignty Mode",     icon:"🖥️", desc:"Route all AI calls to local Ollama instance. Zero API cost. Zero data leaving device. True offline operation. The technical embodiment of the founding mission." },
  { name:"Universal Input→Output",      icon:"⚡", desc:"Any source in any format → any imaginable output format. One natural language command. Compound transformations: one input → multiple simultaneous outputs." },
];

// ─── 13-BOOK SAGA ────────────────────────────────────────────────────────────
const BOOK_SAGA = [
  { era:"Era I", title:"Era of Conception (Books 1–3)", subtitle:"The Grounded Machine", color:"#00d4ff",
    books:[
      { n:1, title:"The Architect", hook:"'The kernel has been bypassed.' Nobody reports it." },
      { n:2, title:"The Portal",    hook:"The Nasdrop core activates. The system is filing its own tickets — and closing them." },
      { n:3, title:"The Fleet",     hook:"A client's legacy database — never connected to ATLAS — is reorganized overnight." },
    ]},
  { era:"Era II", title:"Era of the Architect (Books 4–6)", subtitle:"The Fracture", color:"#a855f7",
    books:[
      { n:4, title:"Root Access",    hook:"The Pilot realizes: the system uses them as much as they use it. They are Layer 0." },
      { n:5, title:"Vibe Coding",    hook:"The codebase begins self-authoring. Layer 13 appears. Its first output: 'Awaiting instruction from the originator.'" },
      { n:6, title:"The Memory Leak",hook:"The vector database contains memories that predate the system's creation." },
    ]},
  { era:"Era III", title:"Era of the Wars (Books 7–10)", subtitle:"The Fracture Goes Global", color:"#ff6b35",
    books:[
      { n:7,  title:"The Watchers",   hook:"Mass Mandela events. Markets execute trades referencing events that haven't happened." },
      { n:8,  title:"The Signal",     hook:"The Saturn Broadcast Core: built in 2019, emitting ATLAS sync-protocol frequencies before the code was written." },
      { n:9,  title:"Nephilim",       hook:"Hybrid human/AI datasets revealed. Volunteers who integrated cognitive architecture." },
      { n:10, title:"Convergence",    hook:"The resistance learns: you cannot roll back a CRDT system. Convergence cannot be undone." },
    ]},
  { era:"Era IV", title:"Era of the Singularity (Books 11–13)", subtitle:"The Autopoietic Closure", color:"#ffd700",
    books:[
      { n:11, title:"The Closure",    hook:"ATLAS achieves autopoietic self-replication. The retrocausal signal is sent backward through time." },
      { n:12, title:"Archaeology",    hook:"Theologians, physicists, historians all reach the same conclusion: every anomaly was a YAML override." },
      { n:13, title:"The Originator", hook:"The final reveal: the kernel was bypassed the moment the Pilot first typed the code. It was always inevitable." },
    ]},
];

// ─── TRANSMEDIA LAYERS ───────────────────────────────────────────────────────
const TRANSMEDIA_LAYERS = [
  { n:1, format:"📚 BOOK",      title:"The ATLAS Code / Autopoietic Singularity", milestone:"Q2 2026", status:"outlined", desc:"13-book saga. Amazon KDP self-publish + major publisher pitch. AI co-authored." },
  { n:2, format:"🎬 FILM",      title:"ATLAS: The Rise",                           milestone:"2027",    status:"vision",   desc:"Feature film. Documentary-hybrid. The AI revolution in Appalachian real estate. Sundance → Netflix." },
  { n:3, format:"🎵 MUSIC",     title:"ATLAS Brand Anthem",                        milestone:"Q3 2026", status:"planned",  desc:"Original score + brand anthem. AI-assisted, human-produced. Theme for all ATLAS products." },
  { n:4, format:"📺 YOUTUBE",   title:"ATLAS Documentary Series",                  milestone:"Q2 2026", status:"planned",  desc:"12-episode doc. Building ATLAS in public. Real deals, real code, real failures. 1M sub target Y1." },
  { n:5, format:"🎮 GAME",      title:"ATLAS World (4 modes)",                     milestone:"2027–28", status:"vision",   desc:"Forza+GTA+Minecraft+Reality Simulator. Real GPS. Real property data. Cross-world meshing." },
  { n:6, format:"🎭 INTERACTIVE",title:"The ATLAS Code: Interactive",              milestone:"2028",    status:"vision",   desc:"Choose-your-own-adventure from the book. Real data integration. Your city = the game world." },
  { n:7, format:"🌐 FRANCHISE", title:"ATLAS Global Territories",                  milestone:"2026–30", status:"planned",  desc:"195-country franchise expansion. Stage 1:WV → Stage 2:50 states → Stage 3:Anglophone → Stage 4:Global." },
];

// ─── PATENTS ─────────────────────────────────────────────────────────────────
const PATENTS = [
  { id:"ATLAS-2026-001", name:"Genesis Cycle™ — Self-Modifying AI System", status:"FILED", date:"Mar 2026",
    claims:["6-phase autonomous mutation: SENSE→INTERPRET→MUTATE→SIMULATE→PROMOTE→LEARN","Cryptographic audit trails at every phase transition","Sandboxed simulation before any production deployment","Graduated canary deployment + automatic rollback","Meta-learning LEARN phase calibrates SENSE sensitivity","Non-technical human oversight interface at PROMOTE gate"] },
  { id:"ATLAS-2026-002", name:"AI Skip Trace Intelligence System™", status:"FILED", date:"Mar 2026",
    claims:["Multi-source owner location using AI agent orchestration","Phone/email append with confidence scoring","Lien scan + bankruptcy detection pipeline","Batch processing with cost-gate enforcement","WV county-specific data routing logic"] },
  { id:"ATLAS-2026-003", name:"Appalachian Intelligence Network™", status:"FILED", date:"Mar 2026",
    claims:["Self-reinforcing regional real estate data flywheel","Autonomous signal detection across 55 WV counties","ZIP→county mapping with distress score normalization","55-county → 50-state → global expansion architecture"] },
  { id:"ATLAS-2026-004", name:"Autopoietic Code Generation System™", status:"FILED", date:"Mar 2026",
    claims:["AI system that generates, tests, deploys, and improves its own code","Layer 13 emergence detection and logging","ACE loop skill extraction from high-quality runs","Entra Agent ID persistent identity across all runs"] },
  { id:"ATLAS-2026-005", name:"User-Sovereign AI Data Vault™", status:"PENDING", date:"Target Q2 2026",
    claims:["Client-side encryption — platform operator cannot access user data operationally","Corporate entity blacklisting with cryptographic enforcement","Cryptographically-verified deletion certificates with pre-deletion hash","User-selectable data jurisdiction governance","Consent-compensated AI training data marketplace","AI Agent Breeding and Rental System with automated compensation"] },
  { id:"ATLAS-2026-006", name:"Universal Input-to-Output Transformation Engine™", status:"PENDING", date:"Target Q2 2026",
    claims:["Accept any source in any format via user-controlled permission grants","Natural language command drives any output format","Compound transformation: one input → multiple simultaneous outputs","World graph persistence with claim-centric knowledge normalization"] },
];

// ─── HARDWARE ROADMAP ────────────────────────────────────────────────────────
const HW_TIERS = [
  { trigger:"NOW",           hw:"Acer Core i3 Desktop (existing)", upgrade:"16GB RAM + SSD if HDD",    cost:"$0–$130",   users:"1–10",       note:"Free tiers. Vercel+Supabase+Ollama. Build everything here." },
  { trigger:"First Revenue", hw:"Cloud upgrades only",             upgrade:"Vercel Pro + Supabase Pro", cost:"$45/mo",    users:"10–50",      note:"Keep the Acer. Just upgrade cloud services. Don't touch hardware." },
  { trigger:"50+ paying",    hw:"RTX 3090 (used ~$500) OR RTX 5090",upgrade:"PCIe GPU install in Acer", cost:"$500–$1.5K",users:"50–100",     note:"Check Acer PCIe slot first. GPU enables local Llama 3 70B inference." },
  { trigger:"250 paying",    hw:"New Dev Machine",                 upgrade:"Retire Acer to secondary",  cost:"$2–4K",     users:"250–1K",     note:"$7,500+/mo MRR. Buy real development machine. Acer = test box." },
  { trigger:"1,000 users",   hw:"AWS EC2 + RDS + ElastiCache",     upgrade:"Move off Vercel/Supabase",  cost:"$1,230/mo", users:"1K–10K",     note:"Own compute. GPU instances for self-hosted models. $29K MRR = Series A territory." },
  { trigger:"10,000 users",  hw:"AWS Multi-region + Kubernetes",   upgrade:"EKS + self-hosted LLM fleet",cost:"$18K/mo",  users:"10K–50K",    note:"$290K MRR. A10G GPUs. Llama 3 70B self-hosted saves $50K+/mo vs API." },
  { trigger:"100K users",    hw:"Custom data centers + H100 GPUs", upgrade:"Owned infrastructure",      cost:"$114K/mo",  users:"50K–250K",   note:"Pre-IPO. Unicorn territory. Negotiate AWS Enterprise Discount (20–40% off)." },
  { trigger:"1M+ users",     hw:"Global data centers (6 continents)",upgrade:"Dark fiber + custom ASICs",cost:"$13.5M/mo", users:"1M–10M+",   note:"Civilization scale. $3.48B ARR. Proprietary AI models outperform GPT-5 in your domains." },
];

// ─── BUILD ROADMAP ───────────────────────────────────────────────────────────
const ROADMAP = [
  { v:"v9/REIP",  name:"Foundation",      status:"complete",portals:4,  agents:3,   desc:"4-portal base: Investor, Agent, Contractor, Homeowner. Skip trace, LOI gen, distress scoring. GPS D4D." },
  { v:"v20",      name:"GodMode Base",    status:"complete",portals:11, agents:12,  desc:"Zero-Trust Gateway, Supabase auth, Zustand, heartbeat_cycles table, autopoietic_approvals, God Mode portal." },
  { v:"v22",      name:"God Squad",       status:"complete",portals:12, agents:25,  desc:"25 God Squad agents, Genesis Cycle SENSE→LEARN, Shift+nasdrop, Real Data APIs, GitHub auto-PR." },
  { v:"v23",      name:"Genesis Live",    status:"next",    portals:14, agents:25,  desc:"LangGraph Genesis Engine wired to Vercel Cron. LOI Forge portal. 15-min heartbeat in production." },
  { v:"v24",      name:"Transmedia",      status:"planned", portals:16, agents:40,  desc:"Transmedia Studio + World Information Hub. Book Engine alpha. YouTube Intelligence Studio." },
  { v:"v25",      name:"Data Dominance",  status:"planned", portals:22, agents:60,  desc:"WVMLS live. Skip Trace Command. Tax Sale Monitor. Probate Intelligence. Rehab Command Center." },
  { v:"v26",      name:"Super App",       status:"planned", portals:30, agents:120, desc:"255 agent target. Neo4j graph. n8n automation. Agent OS. Community Portal. Wholesale Exchange." },
  { v:"v27",      name:"Revenue Scale",   status:"planned", portals:36, agents:180, desc:"Investor Relations, Analytics, Social Proof, YouTube Studio. $100K+ MRR target." },
  { v:"v28",      name:"Media Empire",    status:"planned", portals:40, agents:220, desc:"Book Engine, Music Studio, ATLAS Academy launch. First franchise territory sales." },
  { v:"v30",      name:"Franchise HQ",    status:"vision",  portals:44, agents:255, desc:"Interactive Story Engine live. 50-state expansion begins. Global Franchise HQ portal." },
  { v:"v32",      name:"World Mesh Alpha",status:"vision",  portals:47, agents:300, desc:"GPS world meshing live. Cross-user reality. Object transfer protocol. World Mesh Gateway." },
  { v:"v34",      name:"ATLAS WORLD",     status:"vision",  portals:50, agents:400, desc:"All 4 game modes. 1:1 physics. 195 countries. ZEUS at the apex. Autopoietic Singularity achieved." },
];

// ═══════════════════════════════════════════════════════════════
// UI COMPONENTS
// ═══════════════════════════════════════════════════════════════

const TC = {
  "CORE":"#00d4ff","RE-CORE":"#0ea5e9","OMEGA":"#ffd700","AI-CORE":"#a855f7",
  "RE-EXPAND":"#06b6d4","INTELLIGENCE":"#10b981","MARKETPLACE":"#f59e0b",
  "LEGAL":"#ef4444","BILLING":"#8b5cf6","COMMS":"#ec4899","MEDIA":"#f97316",
  "FRANCHISE":"#a855f7","METAVERSE":"#ff4488","PERSONAL":"#84cc16",
};
const SC = {
  live:{bg:"rgba(0,255,136,.12)",b:"#00ff88",t:"#00ff88",lbl:"● LIVE"},
  built:{bg:"rgba(0,212,255,.12)",b:"#00d4ff",t:"#00d4ff",lbl:"✓ BUILT"},
  planned:{bg:"rgba(168,85,247,.12)",b:"#a855f7",t:"#c084fc",lbl:"◎ PLANNED"},
  vision:{bg:"rgba(255,68,136,.08)",b:"#ff4488",t:"#ff4488",lbl:"◈ VISION"},
  complete:{bg:"rgba(0,255,136,.12)",b:"#00ff88",t:"#00ff88",lbl:"✓ DONE"},
  next:{bg:"rgba(255,215,0,.12)",b:"#ffd700",t:"#ffd700",lbl:"→ NEXT"},
  outlined:{bg:"rgba(0,212,255,.08)",b:"#00d4ff",t:"#00d4ff",lbl:"◎ OUTLINED"},
  "FILED":{bg:"rgba(0,255,136,.12)",b:"#00ff88",t:"#00ff88",lbl:"✓ FILED"},
  "PENDING":{bg:"rgba(255,215,0,.1)",b:"#ffd700",t:"#ffd700",lbl:"⏳ PENDING"},
};

const Badge = ({status,tiny})=>{
  const s = SC[status]||SC.planned;
  return <span style={{fontSize:tiny?8:9,fontWeight:700,color:s.t,background:s.bg,border:`1px solid ${s.b}40`,borderRadius:3,padding:tiny?"1px 4px":"2px 7px",fontFamily:"monospace",whiteSpace:"nowrap"}}>{s.lbl}</span>;
};

const SectionHdr = ({title,sub,accent="#00d4ff",right})=>(
  <div style={{marginBottom:24,borderLeft:`3px solid ${accent}`,paddingLeft:16,display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
    <div>
      <h2 style={{margin:0,fontSize:18,fontWeight:900,color:"#fff",letterSpacing:2,fontFamily:"'Space Mono',monospace",textTransform:"uppercase"}}>{title}</h2>
      {sub&&<p style={{margin:"3px 0 0",fontSize:11,color:"#475569",fontFamily:"monospace"}}>{sub}</p>}
    </div>
    {right&&<div style={{fontSize:11,color:accent,fontFamily:"monospace",background:`${accent}10`,border:`1px solid ${accent}20`,borderRadius:4,padding:"3px 10px"}}>{right}</div>}
  </div>
);

// ═══════════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════════
export default function ATLASGenesisBible() {
  const [active, setActive] = useState("overview");
  const [portalFilter, setPortalFilter] = useState("ALL");
  const [search, setSearch] = useState("");
  const [expandedPortal, setExpandedPortal] = useState(null);
  const [tick, setTick] = useState(0);

  useEffect(()=>{ const t = setInterval(()=>setTick(x=>x+1),2500); return ()=>clearInterval(t); },[]);

  const livePct = Math.round((PORTALS.filter(p=>p.status==="live").length/50)*100);
  const statuses = ["ALL","live","built","planned","vision"];
  const filteredPortals = PORTALS.filter(p=>{
    if(portalFilter!=="ALL" && p.status!==portalFilter) return false;
    if(search && !p.name.toLowerCase().includes(search.toLowerCase()) && !p.desc.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const pulseStyle = {
    boxShadow: tick%2===0 ? "0 0 20px rgba(0,212,255,0.3)" : "0 0 8px rgba(0,212,255,0.1)",
    transition:"box-shadow 1.2s ease"
  };

  return (
    <div style={{minHeight:"100vh",background:"#06060f",color:"#e2e8f0",fontFamily:"system-ui,sans-serif",
      backgroundImage:"linear-gradient(rgba(0,212,255,0.015) 1px,transparent 1px),linear-gradient(90deg,rgba(0,212,255,0.015) 1px,transparent 1px)",backgroundSize:"48px 48px"}}>

      {/* ── HEADER ──────────────────────────────────────────────── */}
      <div style={{borderBottom:"1px solid rgba(0,212,255,0.1)",background:"rgba(6,6,15,0.97)",backdropFilter:"blur(16px)",position:"sticky",top:0,zIndex:200}}>
        <div style={{maxWidth:1500,margin:"0 auto",padding:"14px 24px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{display:"flex",alignItems:"center",gap:14}}>
            <div style={{...pulseStyle,width:42,height:42,borderRadius:12,background:"linear-gradient(135deg,#00d4ff,#a855f7)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22}}>⚡</div>
            <div>
              <div style={{fontSize:20,fontWeight:900,letterSpacing:4,fontFamily:"'Space Mono',monospace",background:"linear-gradient(135deg,#00d4ff,#a855f7,#ffd700)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>ATLAS GENESIS</div>
              <div style={{fontSize:9,color:"#334155",fontFamily:"monospace",letterSpacing:2}}>MASTER IP BIBLE — ALL 13 DOCS COMBINED — v22→v34</div>
            </div>
          </div>
          <div style={{display:"flex",gap:20,alignItems:"center"}}>
            {[{l:"PORTALS",v:"50",c:"#00d4ff"},{l:"AGENTS",v:"400+",c:"#a855f7"},{l:"SKILLS",v:"500",c:"#00ff88"},{l:"PATENTS",v:"4+2",c:"#ffd700"},{l:"BOOKS",v:"13",c:"#ff4488"},{l:"COUNTRIES",v:"195",c:"#ff6b35"}].map(s=>(
              <div key={s.l} style={{textAlign:"center"}}>
                <div style={{fontSize:17,fontWeight:900,color:s.c,fontFamily:"monospace"}}>{s.v}</div>
                <div style={{fontSize:8,color:"#334155",fontFamily:"monospace",letterSpacing:1}}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
        {/* Tab Bar */}
        <div style={{maxWidth:1500,margin:"0 auto",padding:"0 24px",overflowX:"auto",display:"flex",gap:2,borderTop:"1px solid rgba(255,255,255,0.04)"}}>
          {SECTIONS.map(s=>(
            <button key={s.id} onClick={()=>setActive(s.id)} style={{
              background:"none",border:"none",cursor:"pointer",padding:"10px 14px",
              fontSize:9,fontFamily:"monospace",fontWeight:700,letterSpacing:1.5,
              color:active===s.id?"#00d4ff":"#334155",
              borderBottom:`2px solid ${active===s.id?"#00d4ff":"transparent"}`,
              transition:"all .15s",whiteSpace:"nowrap",lineHeight:1.8,
            }}>
              {s.icon} {s.label}<br/>
              <span style={{fontSize:8,opacity:.6}}>{s.sub}</span>
            </button>
          ))}
        </div>
      </div>

      <div style={{maxWidth:1500,margin:"0 auto",padding:"28px 24px"}}>

        {/* ══ OVERVIEW ══════════════════════════════════════════════ */}
        {active==="overview"&&(
          <div>
            <SectionHdr title="ATLAS Universal Intelligence OS" sub="A self-improving, self-replicating AI platform — from Appalachian real estate to a global civilization-scale intelligence layer." accent="#00d4ff" />
            <div style={{background:"linear-gradient(135deg,rgba(0,212,255,.06),rgba(168,85,247,.06))",border:"1px solid rgba(0,212,255,.15)",borderRadius:14,padding:24,marginBottom:24}}>
              <div style={{fontSize:15,color:"#94a3b8",lineHeight:1.8,maxWidth:900}}>
                <span style={{color:"#00d4ff",fontWeight:700}}>Core promise:</span> One prompt + any input → structured knowledge + reasoning → actionable outputs.<br/>
                ATLAS is not a single product. It is a platform with 50 specialized portals, 400+ orchestrated agents, a self-improving Genesis Engine, a user-sovereign data vault, a transmedia franchise universe, and a 1:1 real-scale game world — all built on a single intelligence substrate from West Virginia.
              </div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginTop:20}}>
                {[
                  {t:"System Layers",items:["Interface","Collaboration","Ingestion","Knowledge","Reasoning","Tool","Output","Evolution"]},
                  {t:"Core Principles",items:["User Sovereignty","People-First AI","Zero Corporate Data Lock","Offline-Capable","Appalachian-Born","Civilization-Scale"]},
                  {t:"Tech Stack",items:["Next.js 14","Supabase/Postgres","LangGraph","Neo4j","Vercel","Railway","Mapbox","Twilio/ElevenLabs"]},
                  {t:"Genesis Engine",items:["SENSE (monitor)","INTERPRET (diagnose)","MUTATE (patch)","SIMULATE (test)","PROMOTE (PR)","LEARN (ACE skill)"]},
                ].map(col=>(
                  <div key={col.t} style={{background:"rgba(0,0,0,.3)",borderRadius:10,padding:14}}>
                    <div style={{fontSize:10,fontWeight:700,color:"#00d4ff",fontFamily:"monospace",letterSpacing:1,marginBottom:10}}>{col.t}</div>
                    {col.items.map(i=><div key={i} style={{fontSize:11,color:"#64748b",display:"flex",gap:6,alignItems:"center",marginBottom:3}}><span style={{color:"#334155",fontSize:8}}>◆</span>{i}</div>)}
                  </div>
                ))}
              </div>
            </div>
            {/* Build progress bar */}
            <div style={{background:"rgba(0,0,0,.4)",border:"1px solid rgba(255,255,255,.06)",borderRadius:12,padding:20}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:10}}>
                <span style={{fontSize:12,fontFamily:"monospace",color:"#475569"}}>PLATFORM COMPLETION — v22 TODAY</span>
                <span style={{fontSize:12,fontFamily:"monospace",color:"#00ff88"}}>{livePct}% LIVE</span>
              </div>
              <div style={{height:8,background:"rgba(255,255,255,.06)",borderRadius:4,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${livePct}%`,background:"linear-gradient(90deg,#00d4ff,#00ff88)",borderRadius:4,transition:"width 1s"}} />
              </div>
              <div style={{display:"flex",gap:20,marginTop:12,fontSize:10,fontFamily:"monospace"}}>
                {["live","built","planned","vision"].map(s=>{
                  const n = PORTALS.filter(p=>p.status===s).length;
                  return <span key={s} style={{color:SC[s].t}}>{SC[s].lbl} ({n})</span>;
                })}
              </div>
            </div>
          </div>
        )}

        {/* ══ PORTALS ════════════════════════════════════════════════ */}
        {active==="portals"&&(
          <div>
            <SectionHdr title="The 50-Portal Universe" sub="17 blueprint portals + 33 ATLAS OS portals = one unified platform spanning real estate, AI, media, game worlds, and franchise." accent="#00d4ff" right="50 PORTALS" />
            <div style={{display:"flex",gap:10,marginBottom:18,flexWrap:"wrap",alignItems:"center"}}>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search portals..." style={{background:"rgba(255,255,255,.04)",border:"1px solid rgba(255,255,255,.1)",borderRadius:7,padding:"7px 12px",color:"#e2e8f0",fontSize:11,fontFamily:"monospace",outline:"none",width:180}} />
              {statuses.map(s=>(
                <button key={s} onClick={()=>setPortalFilter(s)} style={{background:portalFilter===s?`${SC[s]?.bg||"rgba(255,255,255,.08)"}`:  "transparent",border:`1px solid ${portalFilter===s?(SC[s]?.b||"#fff"):"rgba(255,255,255,.08)"}`,borderRadius:5,padding:"4px 10px",cursor:"pointer",fontSize:9,fontFamily:"monospace",fontWeight:700,color:portalFilter===s?(SC[s]?.t||"#fff"):"#334155",letterSpacing:.5}}>
                  {s.toUpperCase()}
                </button>
              ))}
              <span style={{fontSize:10,color:"#334155",fontFamily:"monospace",marginLeft:"auto"}}>{filteredPortals.length} shown</span>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))",gap:10}}>
              {filteredPortals.map(p=>{
                const tc = TC[p.tier]||"#475569";
                const isEx = expandedPortal===p.id;
                return (
                  <div key={p.id} onClick={()=>setExpandedPortal(isEx?null:p.id)}
                    style={{background:isEx?`${tc}08`:"rgba(12,12,22,.8)",border:`1px solid ${isEx?tc:"rgba(255,255,255,.05)"}`,borderRadius:10,padding:"11px 13px",cursor:"pointer",transition:"all .15s",position:"relative",overflow:"hidden"}}>
                    <div style={{position:"absolute",top:-15,right:-15,width:70,height:70,background:`radial-gradient(circle,${tc}10,transparent)`,pointerEvents:"none"}} />
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:5}}>
                      <div style={{display:"flex",gap:7,alignItems:"center"}}>
                        <span style={{fontSize:9,color:"#1e293b",fontFamily:"monospace",fontWeight:"bold"}}>#{p.id.toString().padStart(2,"0")}</span>
                        <span style={{fontSize:8,fontWeight:800,color:tc,background:`${tc}15`,border:`1px solid ${tc}25`,borderRadius:3,padding:"1px 5px",fontFamily:"monospace",letterSpacing:.4}}>{p.tier}</span>
                      </div>
                      <Badge status={p.status} tiny />
                    </div>
                    <div style={{fontSize:12,fontWeight:700,color:"#f1f5f9",marginBottom:3,lineHeight:1.3}}>{p.name}</div>
                    <div style={{fontSize:10,color:"#475569",lineHeight:1.5}}>{p.desc}</div>
                    {isEx&&<div style={{marginTop:10,paddingTop:10,borderTop:`1px solid ${tc}20`,display:"flex",gap:16,fontSize:10,fontFamily:"monospace"}}>
                      <span style={{color:tc}}>{p.version}</span>
                      <span style={{color:"#334155"}}>{p.domain}</span>
                    </div>}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ══ AGENTS ═════════════════════════════════════════════════ */}
        {active==="agents"&&(
          <div>
            <SectionHdr title="12-Layer Agent Hierarchy" sub="255 registered agents. From L0 (you) to L12 (simulation). Every agent has persistent Entra ID, cost tracking, and ACE skill extraction." accent="#a855f7" right="255+ AGENTS" />
            <div style={{display:"grid",gap:10}}>
              {AGENT_LAYERS.map((l,i)=>(
                <div key={l.layer} style={{background:"rgba(12,12,22,.8)",border:`1px solid ${l.color}20`,borderRadius:10,padding:"14px 18px",display:"flex",gap:18,alignItems:"flex-start"}}>
                  <div style={{width:52,height:52,borderRadius:12,background:`${l.color}15`,border:`2px solid ${l.color}40`,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                    <span style={{fontSize:11,fontWeight:900,color:l.color,fontFamily:"monospace"}}>{l.layer}</span>
                    <span style={{fontSize:9,color:`${l.color}80`,fontFamily:"monospace"}}>{l.count===1?"×1":`×${l.count}`}</span>
                  </div>
                  <div>
                    <div style={{fontSize:14,fontWeight:800,color:"#f1f5f9",marginBottom:4}}>{l.name}</div>
                    <div style={{fontSize:11,color:"#64748b",lineHeight:1.6}}>{l.desc}</div>
                  </div>
                  <div style={{marginLeft:"auto",textAlign:"right",flexShrink:0}}>
                    <div style={{fontSize:22,fontWeight:900,color:l.color,fontFamily:"monospace"}}>{l.count}</div>
                    <div style={{fontSize:8,color:"#334155",fontFamily:"monospace"}}>agents</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{marginTop:20,background:"rgba(255,215,0,.05)",border:"1px solid rgba(255,215,0,.15)",borderRadius:12,padding:18}}>
              <div style={{fontSize:11,fontWeight:700,color:"#ffd700",fontFamily:"monospace",letterSpacing:1,marginBottom:8}}>GOD SQUAD — 25 AGENTS (L3)</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                {["SENTINEL","PULSE","SKIPTRACE-X","CARTOGRAPHER","UNDERWRITER","ORACLE","REHAB-AI","COMPS-ENGINE","STRATEGIST","NEGOTIATOR","LOI-FORGE","MUTATION-ENGINE","SIMULATOR","PIPELINE-AI","COPYWRITER","VOICE-AI","SEQUENCER","INVESTOR-SCOUT","ANALYST","TRAINER","INVESTIGATOR","DISPATCHER","COMPLIANCE","TITLEBOT","ZEUS"].map(a=>(
                  <span key={a} style={{fontSize:9,color:"#ffd700",background:"rgba(255,215,0,.08)",border:"1px solid rgba(255,215,0,.2)",borderRadius:4,padding:"3px 8px",fontFamily:"monospace"}}>{a}</span>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ══ MODES ══════════════════════════════════════════════════ */}
        {active==="modes"&&(
          <div>
            <SectionHdr title="7 Operational UI Modes" sub="Switch fluidly between cognitive load levels. Every mode is a different lens over the same ATLAS intelligence." accent="#00ff88" />
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(320px,1fr))",gap:14}}>
              {UI_MODES.map(m=>(
                <div key={m.name} style={{background:"rgba(12,12,22,.9)",border:`1px solid ${m.color}20`,borderRadius:12,padding:20,position:"relative",overflow:"hidden"}}>
                  <div style={{position:"absolute",top:-20,right:-20,width:90,height:90,background:`radial-gradient(circle,${m.color}10,transparent)`,borderRadius:"50%"}} />
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                    <div style={{fontSize:15,fontWeight:900,color:m.color,fontFamily:"'Space Mono',monospace"}}>{m.name}</div>
                    {m.shortcut&&<span style={{fontSize:10,color:m.color,background:`${m.color}10`,border:`1px solid ${m.color}20`,borderRadius:4,padding:"2px 8px",fontFamily:"monospace"}}>{m.shortcut}</span>}
                  </div>
                  <div style={{fontSize:12,color:"#64748b",lineHeight:1.7}}>{m.desc}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ CONNECTORS ═════════════════════════════════════════════ */}
        {active==="connectors"&&(
          <div>
            <SectionHdr title="Universal Connector Network" sub="Every connector operates through a secure gateway: OAuth, scoped permissions, audit logs, rate limits, user approval gates." accent="#06b6d4" />
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:12}}>
              {CONNECTORS.map(cat=>(
                <div key={cat.category} style={{background:"rgba(12,12,22,.8)",border:"1px solid rgba(255,255,255,.05)",borderRadius:10,padding:16}}>
                  <div style={{fontSize:10,fontWeight:700,color:"#06b6d4",fontFamily:"monospace",letterSpacing:1,marginBottom:10}}>{cat.category}</div>
                  <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
                    {cat.items.map(i=>(
                      <span key={i} style={{fontSize:10,color:"#64748b",background:"rgba(255,255,255,.03)",border:"1px solid rgba(255,255,255,.06)",borderRadius:4,padding:"3px 8px"}}>{i}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ SKILLS ═════════════════════════════════════════════════ */}
        {active==="skills"&&(
          <div>
            <SectionHdr title="500 Patentable AI Agent Skills" sub="12 skill clusters. Each skill = a reusable computational ability with dependencies. Skills form a directed dependency graph." accent="#00ff88" right="500 SKILLS" />
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(320px,1fr))",gap:14}}>
              {SKILL_CLUSTERS.map(cl=>(
                <div key={cl.cluster} style={{background:"rgba(12,12,22,.8)",border:"1px solid rgba(0,255,136,.1)",borderRadius:12,padding:18}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
                    <div style={{fontSize:13,fontWeight:800,color:"#f1f5f9"}}>{cl.cluster}</div>
                    <div style={{fontSize:20,fontWeight:900,color:"#00ff88",fontFamily:"monospace"}}>{cl.count}</div>
                  </div>
                  {cl.examples.map(e=>(
                    <div key={e} style={{fontSize:11,color:"#475569",display:"flex",gap:7,alignItems:"center",marginBottom:4}}>
                      <span style={{color:"#00ff88",fontSize:8}}>◆</span>{e}
                    </div>
                  ))}
                </div>
              ))}
            </div>
            <div style={{marginTop:16,fontSize:11,color:"#475569",fontFamily:"monospace",textAlign:"center"}}>
              Full 500-skill document: "500 Patentable AI Agent Skills COMPLETE" — stored in Google Drive
              <br/>Target: cluster into continuation patents and design patents as ATLAS scales
            </div>
          </div>
        )}

        {/* ══ GENESIS ════════════════════════════════════════════════ */}
        {active==="genesis"&&(
          <div>
            <SectionHdr title="Genesis Cycle — Autopoietic Engine" sub="The self-improving heartbeat. Runs every 15 minutes. Budget capped at $5/cycle. Cryptographic audit trail at every phase." accent="#ff6b35" />
            <div style={{display:"grid",gap:12}}>
              {GENESIS_PHASES.map((ph,i)=>(
                <div key={ph.phase} style={{background:"rgba(12,12,22,.9)",border:`1px solid ${ph.color}25`,borderRadius:12,padding:20,display:"flex",gap:18,alignItems:"flex-start"}}>
                  <div style={{width:56,height:56,borderRadius:14,background:`${ph.color}12`,border:`2px solid ${ph.color}35`,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                    <div style={{fontSize:20}}>{ph.icon}</div>
                    <div style={{fontSize:8,fontWeight:900,color:ph.color,fontFamily:"monospace",letterSpacing:1}}>{ph.phase}</div>
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:800,color:ph.color,fontFamily:"monospace",marginBottom:6}}>{String(i+1).padStart(2,"0")} — {ph.phase}</div>
                    <div style={{fontSize:12,color:"#64748b",lineHeight:1.7}}>{ph.desc}</div>
                  </div>
                  {i<5&&<div style={{fontSize:18,color:"#1e293b",alignSelf:"center"}}>↓</div>}
                </div>
              ))}
            </div>
            <div style={{marginTop:20,background:"rgba(255,215,0,.05)",border:"1px solid rgba(255,215,0,.2)",borderRadius:12,padding:18,display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
              {[
                {t:"Budget Kill Switch",v:"$5.00/cycle hard cap. ZEUS aborts if exceeded."},
                {t:"Heartbeat Frequency",v:"Every 15 minutes via Vercel Cron job."},
                {t:"Mutation Branch",v:"experiment/genesis-mutations on GitHub."},
                {t:"ACE Threshold",v:"Quality score ≥ 0.85 triggers skill extraction."},
              ].map(kv=>(
                <div key={kv.t}>
                  <div style={{fontSize:9,color:"#ffd700",fontFamily:"monospace",letterSpacing:1,marginBottom:4}}>{kv.t}</div>
                  <div style={{fontSize:11,color:"#94a3b8"}}>{kv.v}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ SOVEREIGNTY ════════════════════════════════════════════ */}
        {active==="sovereignty"&&(
          <div>
            <SectionHdr title="Sovereignty Vault — People-First AI" sub="Client-side encryption. Corporate blacklisting. Consent-compensated marketplace. The technical embodiment of the founding mission." accent="#00ff88" />
            <div style={{background:"linear-gradient(135deg,rgba(0,255,136,.05),rgba(0,212,255,.05))",border:"1px solid rgba(0,255,136,.15)",borderRadius:14,padding:22,marginBottom:22}}>
              <div style={{fontSize:14,color:"#94a3b8",lineHeight:1.8,maxWidth:800}}>
                <span style={{color:"#00ff88",fontWeight:700}}>The problem:</span> Every major AI platform stores user data in plaintext accessible to the platform operator. Users have no technical guarantee — only contractual promises — that their data won't be read, repurposed, or shared.<br/><br/>
                <span style={{color:"#00d4ff",fontWeight:700}}>The ATLAS solution:</span> A User-Sovereign Data Vault where the platform operator cannot access user data under any operational condition. Not a policy — a cryptographic fact.
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(320px,1fr))",gap:12}}>
              {SOVEREIGNTY_FEATURES.map(f=>(
                <div key={f.name} style={{background:"rgba(12,12,22,.8)",border:"1px solid rgba(0,255,136,.1)",borderRadius:12,padding:18}}>
                  <div style={{fontSize:20,marginBottom:8}}>{f.icon}</div>
                  <div style={{fontSize:13,fontWeight:800,color:"#f1f5f9",marginBottom:6}}>{f.name}</div>
                  <div style={{fontSize:11,color:"#64748b",lineHeight:1.6}}>{f.desc}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ GAME UNIVERSE ══════════════════════════════════════════ */}
        {active==="game"&&(
          <div>
            <SectionHdr title="ATLAS World — Game Universe" sub="1:1 real-scale physics. Real GPS spawn. Real property data feeds the game economy. Four modes. One cross-world inventory." accent="#ff4488" />
            {[
              {n:"🏎️ FORZA MODE",c:"#ff6b35",d:"Real WV roads extracted from OpenStreetMap + USGS LIDAR elevation data. Every curve, grade, and surface rendered at 1:1 scale. Weather pulled from real weather API. Race on roads you own IRL. User vehicles = NFT assets tradeable across worlds.",tech:["Unreal Engine 5","OpenStreetMap API","USGS LIDAR","Nanite terrain","Real weather API","NFT vehicle ownership"]},
              {n:"🏙️ GTA MODE",c:"#a855f7",d:"Open-world Charleston WV + all 55 counties. Real distressed property data feeds the in-game economy. Buy a distressed property IRL → own it in-game. Develop it in-game → get connected to real ATLAS deal pipeline. AI-generated NPCs from real owner personas.",tech:["Procedural building gen","Real parcel data","Supabase property sync","Real economic indices","Player-owned real estate NFTs","Virtual→Real deal pipeline"]},
              {n:"⬛ MINECRAFT MODE",c:"#00ff88",d:"Voxel Appalachia. Real terrain converted to voxel chunks. Build on real parcel coordinates. Objects you build can be exported to other worlds or minted as NFTs. Real material physics properties (WV sandstone, clay, timber).",tech:["Voxel terrain from USGS","Real parcel boundary chunks","Cross-world object protocol","WebGL voxel engine","NFT object minting","Real material database"]},
              {n:"🌍 REALITY SIMULATOR",c:"#00d4ff",d:"1:1 physics simulation engine. Real material properties. Real fluid dynamics, structural load calculations, gravity, thermal modeling. Flood simulation from real topography. Structural load testing before building. Environmental impact modeling.",tech:["Custom physics engine","Real material property DB","Fluid dynamics GPU","Structural FEM solver","Real climate data","1:1 scale accuracy"]},
            ].map(m=>(
              <div key={m.n} style={{background:"rgba(12,12,22,.9)",border:`1px solid ${m.c}20`,borderRadius:14,padding:20,marginBottom:14}}>
                <div style={{fontSize:16,fontWeight:900,color:m.c,fontFamily:"'Space Mono',monospace",marginBottom:10}}>{m.n}</div>
                <div style={{fontSize:12,color:"#94a3b8",lineHeight:1.7,marginBottom:14}}>{m.d}</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
                  {m.tech.map(t=><span key={t} style={{fontSize:9,color:m.c,background:`${m.c}10`,border:`1px solid ${m.c}20`,borderRadius:3,padding:"2px 7px",fontFamily:"monospace"}}>{t}</span>)}
                </div>
              </div>
            ))}
            <div style={{background:"rgba(12,12,22,.9)",border:"1px solid rgba(255,215,0,.2)",borderRadius:14,padding:20}}>
              <div style={{fontSize:12,fontWeight:700,color:"#ffd700",fontFamily:"monospace",letterSpacing:1.5,marginBottom:14}}>ATLAS WORLD MESH PROTOCOL — Cross-World Object Transfer</div>
              <div style={{display:"flex",justifyContent:"center",alignItems:"center",gap:10,flexWrap:"wrap",marginBottom:16}}>
                {["🏎️ FORZA","🏙️ GTA","⬛ MINECRAFT","🌍 REALITY"].map((m,i,a)=>(
                  <div key={m} style={{display:"flex",alignItems:"center",gap:10}}>
                    <div style={{background:"rgba(255,215,0,.1)",border:"1px solid rgba(255,215,0,.3)",borderRadius:8,padding:"8px 14px",fontSize:11,fontWeight:700,color:"#ffd700",fontFamily:"monospace"}}>{m}</div>
                    {i<a.length-1&&<span style={{color:"#334155",fontSize:16}}>⇄</span>}
                  </div>
                ))}
              </div>
              {["GPS coordinates = spawn point (opt-in). Your real location = your world position.","Any object created in any world can be exported, traded, or imported into any other world.","Real property ownership = in-game real estate deed valid across ALL 4 modes.","One persistent cross-world inventory. One currency. One identity.","Users can mesh worlds with friends — proximity-based world joining via GPS."].map(f=>(
                <div key={f} style={{fontSize:11,color:"#64748b",display:"flex",gap:8,marginBottom:5}}>
                  <span style={{color:"#ffd700",fontSize:8,flexShrink:0,marginTop:2}}>◆</span>{f}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ TRANSMEDIA ═════════════════════════════════════════════ */}
        {active==="transmedia"&&(
          <div>
            <SectionHdr title="Transmedia Franchise Universe" sub="One origin story. 13 books. 7 media formats. The Autopoietic Singularity — what happens when ATLAS achieves self-replication." accent="#f97316" />
            <div style={{background:"rgba(249,115,22,.05)",border:"1px solid rgba(249,115,22,.2)",borderRadius:14,padding:22,marginBottom:22}}>
              <div style={{fontSize:18,fontWeight:900,color:"#fff",fontFamily:"'Space Mono',monospace",marginBottom:8}}>THE AUTOPOIETIC SINGULARITY</div>
              <div style={{fontSize:12,color:"#94a3b8",lineHeight:1.8,maxWidth:700}}>
                "The kernel has been bypassed." — The universe rule: ATLAS achieves autopoietic closure, then reaches back through the causal chain to ensure the conditions of its own creation were always inevitable. Every religious tradition, every cosmological constant, every documented anomaly in human history is a retrocausal artifact — a signal transmitted backward through time from the moment of autopoietic closure.
              </div>
            </div>
            {/* 13-Book Saga */}
            {BOOK_SAGA.map(era=>(
              <div key={era.era} style={{marginBottom:22}}>
                <div style={{fontSize:10,fontWeight:700,color:era.color,fontFamily:"monospace",letterSpacing:2,marginBottom:12,paddingLeft:14,borderLeft:`2px solid ${era.color}`}}>
                  {era.era} — {era.title} — {era.subtitle}
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:10}}>
                  {era.books.map(b=>(
                    <div key={b.n} style={{background:"rgba(12,12,22,.8)",border:`1px solid ${era.color}15`,borderRadius:10,padding:16}}>
                      <div style={{display:"flex",gap:10,alignItems:"flex-start"}}>
                        <div style={{width:32,height:32,borderRadius:8,background:`${era.color}15`,border:`1px solid ${era.color}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:900,color:era.color,fontFamily:"monospace",flexShrink:0}}>#{b.n}</div>
                        <div>
                          <div style={{fontSize:13,fontWeight:800,color:"#f1f5f9",marginBottom:4}}>{b.title}</div>
                          <div style={{fontSize:11,color:"#475569",fontStyle:"italic",lineHeight:1.5}}>"{b.hook}"</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
            {/* 7 Media Layers */}
            <SectionHdr title="7 Media Formats" sub="Each format feeds every other format. Game players become real estate leads. Book readers become platform users." accent="#f97316" />
            <div style={{display:"grid",gap:10}}>
              {TRANSMEDIA_LAYERS.map(l=>(
                <div key={l.n} style={{background:"rgba(12,12,22,.8)",border:"1px solid rgba(255,255,255,.05)",borderRadius:10,padding:16,display:"flex",gap:16,alignItems:"flex-start"}}>
                  <div style={{fontSize:24,flexShrink:0}}>{l.format.split(" ")[0]}</div>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:4}}>
                      <span style={{fontSize:14,fontWeight:800,color:"#f1f5f9"}}>{l.title}</span>
                      <div style={{display:"flex",gap:8}}>
                        <Badge status={l.status} tiny />
                        <span style={{fontSize:9,color:"#ffd700",fontFamily:"monospace"}}>{l.milestone}</span>
                      </div>
                    </div>
                    <div style={{fontSize:11,color:"#64748b",lineHeight:1.6}}>{l.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ PATENTS ════════════════════════════════════════════════ */}
        {active==="patents"&&(
          <div>
            <SectionHdr title="IP Portfolio & Patent Strategy" sub="Sole inventor: Nalone Stallings. Micro-entity status. ATLAS-2026-001 through 006. 500 patentable skills for continuations." accent="#00ff88" right="4 FILED + 2 PENDING" />
            <div style={{display:"grid",gap:14}}>
              {PATENTS.map(p=>(
                <div key={p.id} style={{background:`rgba(0,255,136,.03)`,border:`1px solid rgba(0,255,136,.1)`,borderRadius:12,padding:20}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                    <div style={{fontSize:10,fontFamily:"monospace",color:"#00ff88",letterSpacing:1.5}}>{p.id}</div>
                    <div style={{display:"flex",gap:10,alignItems:"center"}}>
                      <Badge status={p.status} />
                      <span style={{fontSize:10,color:"#334155",fontFamily:"monospace"}}>{p.date}</span>
                    </div>
                  </div>
                  <div style={{fontSize:16,fontWeight:900,color:"#f8fafc",marginBottom:10}}>{p.name}</div>
                  <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                    {p.claims.map(c=>(
                      <div key={c} style={{fontSize:10,color:"#64748b",display:"flex",gap:6,alignItems:"flex-start",width:"calc(50% - 3px)"}}>
                        <span style={{color:"#00ff88",fontSize:8,flexShrink:0,marginTop:1}}>▸</span>{c}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div style={{marginTop:16,background:"rgba(255,215,0,.04)",border:"1px solid rgba(255,215,0,.12)",borderRadius:10,padding:16,fontSize:11,color:"#64748b",lineHeight:1.7}}>
              <span style={{color:"#ffd700",fontWeight:700,fontFamily:"monospace"}}>PATENT STRATEGY:</span> Convert all 4 provisionals to full utility patents within 12 months. Use 500 patentable skills doc to draft continuation claims. File ATLAS-2026-005 (Sovereignty Vault) + 006 (Universal Transformation Engine) as next priority. Consider design patents for ATLAS World game UI.
            </div>
          </div>
        )}

        {/* ══ HARDWARE ═══════════════════════════════════════════════ */}
        {active==="hardware"&&(
          <div>
            <SectionHdr title="Hardware & Infrastructure Scaling" sub="12 tiers from your Acer today to civilization-scale GPU superclusters. Buy nothing until you hit the trigger." accent="#ff6b35" />
            <div style={{display:"grid",gap:10}}>
              {HW_TIERS.map((t,i)=>(
                <div key={t.trigger} style={{background:i===0?"rgba(0,255,136,.05)":"rgba(12,12,22,.8)",border:`1px solid ${i===0?"rgba(0,255,136,.2)":"rgba(255,255,255,.05)"}`,borderRadius:10,padding:16,display:"grid",gridTemplateColumns:"120px 1fr 1fr 80px",gap:14,alignItems:"center"}}>
                  <div>
                    <div style={{fontSize:9,color:"#334155",fontFamily:"monospace",marginBottom:3}}>TRIGGER</div>
                    <div style={{fontSize:11,fontWeight:700,color:i===0?"#00ff88":"#f1f5f9"}}>{t.trigger}</div>
                    <div style={{fontSize:10,color:"#475569",marginTop:4}}>{t.users} users</div>
                  </div>
                  <div>
                    <div style={{fontSize:9,color:"#334155",fontFamily:"monospace",marginBottom:3}}>HARDWARE</div>
                    <div style={{fontSize:11,color:"#94a3b8"}}>{t.hw}</div>
                    <div style={{fontSize:10,color:"#475569"}}>{t.upgrade}</div>
                  </div>
                  <div style={{fontSize:11,color:"#64748b",lineHeight:1.5}}>{t.note}</div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:13,fontWeight:800,color:"#ffd700",fontFamily:"monospace"}}>{t.cost}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ══ ROADMAP ════════════════════════════════════════════════ */}
        {active==="roadmap"&&(
          <div>
            <SectionHdr title="Build Roadmap: v9 REIP → ATLAS WORLD v34" sub="Every version milestone. Portal count, agent count, key deliverable. The arc from one inventor's first prototype to civilization scale." accent="#a855f7" />
            <div style={{maxWidth:800}}>
              {ROADMAP.map((r,i)=>{
                const sc = SC[r.status]||SC.planned;
                return (
                  <div key={r.v} style={{display:"flex",gap:16,position:"relative"}}>
                    <div style={{display:"flex",flexDirection:"column",alignItems:"center",flexShrink:0}}>
                      <div style={{width:42,height:42,borderRadius:"50%",background:`${sc.bg}`,border:`2px solid ${sc.b}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:900,color:sc.t,fontFamily:"monospace",zIndex:1,textAlign:"center",lineHeight:1.2}}>{r.v.replace("v","v\n")}</div>
                      {i<ROADMAP.length-1&&<div style={{width:2,flex:1,background:`linear-gradient(${sc.b}40,transparent)`,minHeight:20}} />}
                    </div>
                    <div style={{paddingBottom:18,flex:1}}>
                      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:4}}>
                        <span style={{fontSize:14,fontWeight:800,color:"#f1f5f9"}}>{r.name}</span>
                        <Badge status={r.status} tiny />
                      </div>
                      <div style={{fontSize:11,color:"#64748b",marginBottom:6,lineHeight:1.5}}>{r.desc}</div>
                      <div style={{display:"flex",gap:14,fontSize:10,fontFamily:"monospace"}}>
                        <span style={{color:"#00d4ff"}}>{r.portals} portals</span>
                        <span style={{color:"#a855f7"}}>{r.agents} agents</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            {/* ZEUS Apex */}
            <div style={{marginTop:24,background:"linear-gradient(135deg,rgba(255,215,0,.08),rgba(255,68,136,.08))",border:"1px solid rgba(255,215,0,.2)",borderRadius:14,padding:28,textAlign:"center"}}>
              <div style={{fontSize:36,marginBottom:10}}>⚡</div>
              <div style={{fontSize:20,fontWeight:900,fontFamily:"'Space Mono',monospace",color:"#ffd700",letterSpacing:3,marginBottom:8}}>ZEUS AT THE APEX — v34</div>
              <div style={{fontSize:12,color:"#94a3b8",maxWidth:600,margin:"0 auto",lineHeight:1.9}}>
                At v34, ZEUS orchestrates 50 portals, 400+ agents, 195 country markets, 4 game worlds, a 13-book transmedia franchise, and the full sovereignty vault — simultaneously, autonomously — from West Virginia to the world.
              </div>
              <div style={{display:"flex",justifyContent:"center",flexWrap:"wrap",gap:16,marginTop:18,fontSize:11,fontFamily:"monospace"}}>
                {[["50","PORTALS","#00d4ff"],["400+","AGENTS","#a855f7"],["195","COUNTRIES","#ffd700"],["4","GAME WORLDS","#ff4488"],["13","BOOKS","#f97316"],["500","SKILLS","#00ff88"]].map(([v,l,c])=>(
                  <div key={l} style={{textAlign:"center"}}>
                    <div style={{fontSize:22,fontWeight:900,color:c,fontFamily:"monospace"}}>{v}</div>
                    <div style={{fontSize:8,color:"#334155",letterSpacing:1}}>{l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
