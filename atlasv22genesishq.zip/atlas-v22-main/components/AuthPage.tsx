'use client'

import { useState } from 'react'
import { Zap, Mail, Lock, User, Loader2, Github, Chrome } from 'lucide-react'
import toast from 'react-hot-toast'

type AuthMode = 'login' | 'signup' | 'forgot'

export function AuthPage() {
  const [mode, setMode] = useState<AuthMode>('login')
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    email: '',
    password: '',
    name: '',
  })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)

    try {
      if (mode === 'login') {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: form.email, password: form.password }),
        })
        
        if (res.ok) {
          toast.success('Welcome back!')
          window.location.href = '/'
        } else {
          const { error } = await res.json()
          toast.error(error || 'Login failed')
        }
      } else if (mode === 'signup') {
        const res = await fetch('/api/auth/signup', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(form),
        })
        
        if (res.ok) {
          toast.success('Account created! Check your email to verify.')
          setMode('login')
        } else {
          const { error } = await res.json()
          toast.error(error || 'Signup failed')
        }
      } else if (mode === 'forgot') {
        const res = await fetch('/api/auth/forgot-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: form.email }),
        })
        
        if (res.ok) {
          toast.success('Password reset email sent!')
          setMode('login')
        } else {
          toast.error('Failed to send reset email')
        }
      }
    } catch {
      toast.error('Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  async function handleOAuth(provider: 'google' | 'github') {
    setLoading(true)
    try {
      const res = await fetch(`/api/auth/${provider}`)
      const { url } = await res.json()
      if (url) window.location.href = url
    } catch {
      toast.error(`${provider} login failed`)
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-atlas-dark flex items-center justify-center p-4 atlas-grid">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-atlas-accent to-atlas-purple flex items-center justify-center glow-accent">
              <Zap size={24} className="text-white" />
            </div>
            <div className="text-left">
              <div className="text-2xl font-bold text-white">ATLAS</div>
              <div className="text-xs text-atlas-muted font-mono">v20.0 GodMode</div>
            </div>
          </div>
          <p className="text-atlas-muted text-sm">
            {mode === 'login' && 'Welcome back! Sign in to continue.'}
            {mode === 'signup' && 'Create your account to get started.'}
            {mode === 'forgot' && 'Enter your email to reset your password.'}
          </p>
        </div>

        {/* Auth Card */}
        <div className="atlas-panel p-6 rounded-2xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="text-xs text-atlas-muted mb-1 block">Full Name</label>
                <div className="relative">
                  <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-atlas-muted" />
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="John Smith"
                    required
                    className="w-full bg-atlas-dark border border-atlas-border rounded-lg pl-10 pr-4 py-2.5 text-sm text-atlas-text placeholder-atlas-muted/50 focus:outline-none focus:border-atlas-accent transition-colors"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-xs text-atlas-muted mb-1 block">Email</label>
              <div className="relative">
                <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-atlas-muted" />
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@example.com"
                  required
                  className="w-full bg-atlas-dark border border-atlas-border rounded-lg pl-10 pr-4 py-2.5 text-sm text-atlas-text placeholder-atlas-muted/50 focus:outline-none focus:border-atlas-accent transition-colors"
                />
              </div>
            </div>

            {mode !== 'forgot' && (
              <div>
                <label className="text-xs text-atlas-muted mb-1 block">Password</label>
                <div className="relative">
                  <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-atlas-muted" />
                  <input
                    type="password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder="••••••••"
                    required
                    minLength={8}
                    className="w-full bg-atlas-dark border border-atlas-border rounded-lg pl-10 pr-4 py-2.5 text-sm text-atlas-text placeholder-atlas-muted/50 focus:outline-none focus:border-atlas-accent transition-colors"
                  />
                </div>
              </div>
            )}

            {mode === 'login' && (
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setMode('forgot')}
                  className="text-xs text-atlas-accent hover:underline"
                >
                  Forgot password?
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 rounded-lg bg-atlas-accent text-atlas-dark font-semibold hover:bg-atlas-accent/80 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={16} className="animate-spin" />}
              {mode === 'login' && 'Sign In'}
              {mode === 'signup' && 'Create Account'}
              {mode === 'forgot' && 'Send Reset Link'}
            </button>
          </form>

          {mode !== 'forgot' && (
            <>
              <div className="flex items-center gap-3 my-4">
                <div className="flex-1 h-px bg-atlas-border" />
                <span className="text-xs text-atlas-muted">or continue with</span>
                <div className="flex-1 h-px bg-atlas-border" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => handleOAuth('google')}
                  disabled={loading}
                  className="flex items-center justify-center gap-2 py-2.5 rounded-lg border border-atlas-border text-atlas-text hover:bg-white/5 transition-all text-sm"
                >
                  <Chrome size={16} />
                  Google
                </button>
                <button
                  onClick={() => handleOAuth('github')}
                  disabled={loading}
                  className="flex items-center justify-center gap-2 py-2.5 rounded-lg border border-atlas-border text-atlas-text hover:bg-white/5 transition-all text-sm"
                >
                  <Github size={16} />
                  GitHub
                </button>
              </div>
            </>
          )}

          <div className="text-center mt-4">
            {mode === 'login' && (
              <p className="text-xs text-atlas-muted">
                Don't have an account?{' '}
                <button onClick={() => setMode('signup')} className="text-atlas-accent hover:underline">
                  Sign up
                </button>
              </p>
            )}
            {mode === 'signup' && (
              <p className="text-xs text-atlas-muted">
                Already have an account?{' '}
                <button onClick={() => setMode('login')} className="text-atlas-accent hover:underline">
                  Sign in
                </button>
              </p>
            )}
            {mode === 'forgot' && (
              <p className="text-xs text-atlas-muted">
                Remember your password?{' '}
                <button onClick={() => setMode('login')} className="text-atlas-accent hover:underline">
                  Sign in
                </button>
              </p>
            )}
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-[10px] text-atlas-muted mt-6">
          By continuing, you agree to ATLAS Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  )
}
