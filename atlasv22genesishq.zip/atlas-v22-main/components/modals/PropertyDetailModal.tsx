'use client'

import { useAtlasStore } from '@/store/useAtlasStore'
import { 
  MapPin, 
  User, 
  Phone, 
  Mail, 
  DollarSign, 
  TrendingUp, 
  AlertTriangle,
  FileText,
  MessageSquare,
  Calendar,
  Copy,
  ExternalLink
} from 'lucide-react'
import { clsx } from 'clsx'
import toast from 'react-hot-toast'

export function PropertyDetailModal() {
  const { modalData, closeModal, openModal } = useAtlasStore()
  const property = modalData as {
    id?: string
    address?: string
    city?: string
    state?: string
    zip?: string
    owner_name?: string
    owner_phone?: string
    owner_email?: string
    equity_pct?: number
    arv?: number
    asking_price?: number
    assessed_value?: number
    status?: 'hot' | 'warm' | 'cold' | 'closed'
    tax_delinquent?: boolean
    tax_owed?: number
    distress_score?: number
    deal_grade?: string
    notes?: string
    dossier_json?: Record<string, unknown>
    created_at?: string
  }

  if (!property) return null

  const statusColors = {
    hot: 'badge-hot',
    warm: 'badge-warm',
    cold: 'badge-cold',
    closed: 'badge-green',
  }

  const gradeColors: Record<string, string> = {
    A: 'text-atlas-green',
    B: 'text-atlas-accent',
    C: 'text-atlas-gold',
    D: 'text-atlas-red',
    F: 'text-atlas-red',
  }

  function copyToClipboard(text: string, label: string) {
    navigator.clipboard.writeText(text)
    toast.success(`${label} copied!`)
  }

  function initiateCall() {
    if (property.owner_phone) {
      openModal('neural-call', { 
        name: property.owner_name, 
        phone: property.owner_phone 
      })
    } else {
      toast.error('No phone number available')
    }
  }

  return (
    <div className="p-6 max-h-[80vh] overflow-y-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <MapPin size={18} className="text-atlas-accent" />
            {property.address}
          </h2>
          <p className="text-sm text-atlas-muted">
            {property.city}, {property.state} {property.zip}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {property.status && (
            <span className={clsx('px-2 py-1 rounded text-xs font-bold uppercase', statusColors[property.status])}>
              {property.status}
            </span>
          )}
          {property.deal_grade && (
            <span className={clsx('text-2xl font-bold', gradeColors[property.deal_grade])}>
              {property.deal_grade}
            </span>
          )}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-3 mb-4">
        <div className="atlas-panel p-3 rounded-lg text-center">
          <div className="text-xs text-atlas-muted mb-1">Distress Score</div>
          <div className={clsx(
            'text-xl font-bold font-mono',
            (property.distress_score ?? 0) > 70 ? 'text-atlas-red' :
            (property.distress_score ?? 0) > 40 ? 'text-atlas-gold' : 'text-atlas-accent'
          )}>
            {property.distress_score ?? 'N/A'}/100
          </div>
        </div>
        <div className="atlas-panel p-3 rounded-lg text-center">
          <div className="text-xs text-atlas-muted mb-1">Equity</div>
          <div className="text-xl font-bold text-atlas-green font-mono">
            {property.equity_pct ? `${property.equity_pct}%` : 'N/A'}
          </div>
        </div>
        <div className="atlas-panel p-3 rounded-lg text-center">
          <div className="text-xs text-atlas-muted mb-1">ARV</div>
          <div className="text-xl font-bold text-atlas-text font-mono">
            {property.arv ? `$${property.arv.toLocaleString()}` : 'N/A'}
          </div>
        </div>
        <div className="atlas-panel p-3 rounded-lg text-center">
          <div className="text-xs text-atlas-muted mb-1">Tax Del.</div>
          <div className={clsx(
            'text-xl font-bold font-mono',
            property.tax_delinquent ? 'text-atlas-red' : 'text-atlas-green'
          )}>
            {property.tax_delinquent ? 'YES' : 'NO'}
          </div>
        </div>
      </div>

      {/* Owner Info */}
      <div className="atlas-panel p-4 rounded-xl mb-4">
        <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <User size={14} className="text-atlas-accent" />
          Owner Information
        </h3>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-atlas-muted">Name</span>
            <span className="text-sm text-atlas-text font-medium">
              {property.owner_name || 'Unknown'}
            </span>
          </div>
          
          {property.owner_phone && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-atlas-muted flex items-center gap-1">
                <Phone size={12} /> Phone
              </span>
              <div className="flex items-center gap-2">
                <span className="text-sm text-atlas-accent font-mono">{property.owner_phone}</span>
                <button
                  onClick={() => copyToClipboard(property.owner_phone!, 'Phone')}
                  className="p-1 text-atlas-muted hover:text-atlas-text"
                >
                  <Copy size={12} />
                </button>
              </div>
            </div>
          )}
          
          {property.owner_email && (
            <div className="flex items-center justify-between">
              <span className="text-sm text-atlas-muted flex items-center gap-1">
                <Mail size={12} /> Email
              </span>
              <div className="flex items-center gap-2">
                <span className="text-sm text-atlas-text">{property.owner_email}</span>
                <button
                  onClick={() => copyToClipboard(property.owner_email!, 'Email')}
                  className="p-1 text-atlas-muted hover:text-atlas-text"
                >
                  <Copy size={12} />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="flex gap-2 mt-4">
          <button
            onClick={initiateCall}
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-atlas-green/20 text-atlas-green border border-atlas-green/30 hover:bg-atlas-green/30 transition-all text-sm"
          >
            <Phone size={14} /> Call
          </button>
          <button
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-atlas-accent/20 text-atlas-accent border border-atlas-accent/30 hover:bg-atlas-accent/30 transition-all text-sm"
          >
            <MessageSquare size={14} /> SMS
          </button>
          <button
            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-atlas-purple/20 text-atlas-purple border border-atlas-purple/30 hover:bg-atlas-purple/30 transition-all text-sm"
          >
            <Mail size={14} /> Email
          </button>
        </div>
      </div>

      {/* Financial Details */}
      <div className="atlas-panel p-4 rounded-xl mb-4">
        <h3 className="text-sm font-semibold text-atlas-text mb-3 flex items-center gap-2">
          <DollarSign size={14} className="text-atlas-gold" />
          Financial Details
        </h3>
        
        <div className="grid grid-cols-2 gap-3">
          <div className="p-2 rounded bg-atlas-dark border border-atlas-border">
            <div className="text-[10px] text-atlas-muted uppercase">Assessed Value</div>
            <div className="text-sm font-bold text-atlas-text font-mono">
              ${property.assessed_value?.toLocaleString() ?? 'N/A'}
            </div>
          </div>
          <div className="p-2 rounded bg-atlas-dark border border-atlas-border">
            <div className="text-[10px] text-atlas-muted uppercase">Asking Price</div>
            <div className="text-sm font-bold text-atlas-text font-mono">
              ${property.asking_price?.toLocaleString() ?? 'N/A'}
            </div>
          </div>
          <div className="p-2 rounded bg-atlas-dark border border-atlas-border">
            <div className="text-[10px] text-atlas-muted uppercase">Tax Owed</div>
            <div className={clsx(
              'text-sm font-bold font-mono',
              property.tax_owed ? 'text-atlas-red' : 'text-atlas-text'
            )}>
              {property.tax_owed ? `$${property.tax_owed.toLocaleString()}` : '$0'}
            </div>
          </div>
          <div className="p-2 rounded bg-atlas-dark border border-atlas-border">
            <div className="text-[10px] text-atlas-muted uppercase">ARV</div>
            <div className="text-sm font-bold text-atlas-green font-mono">
              ${property.arv?.toLocaleString() ?? 'N/A'}
            </div>
          </div>
        </div>
      </div>

      {/* Notes */}
      {property.notes && (
        <div className="atlas-panel p-4 rounded-xl mb-4">
          <h3 className="text-sm font-semibold text-atlas-text mb-2 flex items-center gap-2">
            <FileText size={14} className="text-atlas-purple" />
            Notes
          </h3>
          <p className="text-sm text-atlas-muted leading-relaxed">{property.notes}</p>
        </div>
      )}

      {/* Dossier Alert */}
      {property.dossier_json && (
        <div className="atlas-panel p-3 rounded-xl border border-atlas-accent/30 flex items-center gap-3">
          <TrendingUp size={16} className="text-atlas-accent shrink-0" />
          <div className="flex-1">
            <p className="text-xs font-semibold text-atlas-accent">Full Dossier Available</p>
            <p className="text-[10px] text-atlas-muted">Generated by Investigator → Underwriter → Copywriter pipeline</p>
          </div>
          <button className="text-xs text-atlas-accent hover:underline flex items-center gap-1">
            View <ExternalLink size={10} />
          </button>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-atlas-border">
        <div className="text-[10px] text-atlas-muted flex items-center gap-1">
          <Calendar size={10} />
          Added {property.created_at ? new Date(property.created_at).toLocaleDateString() : 'Unknown'}
        </div>
        <div className="flex gap-2">
          <button
            onClick={closeModal}
            className="px-4 py-2 rounded-lg border border-atlas-border text-atlas-muted hover:text-white hover:border-white transition-all text-sm"
          >
            Close
          </button>
          <button
            className="px-4 py-2 rounded-lg bg-atlas-accent text-atlas-dark font-semibold hover:bg-atlas-accent/80 transition-all text-sm"
          >
            Run Dossier
          </button>
        </div>
      </div>
    </div>
  )
}
