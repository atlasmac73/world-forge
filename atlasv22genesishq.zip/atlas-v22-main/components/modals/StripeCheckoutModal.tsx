'use client'

import { useAtlasStore } from '@/store/useAtlasStore'
import { CreditCard, Zap, Building2, Star } from 'lucide-react'
import toast from 'react-hot-toast'

const PLANS = [
  {
    id: 'pro',
    name: 'Pro',
    price: '$97/mo',
    credits: 1000,
    icon: <Star size={20} className="text-atlas-purple" />,
    color: 'atlas-purple',
    features: ['1,000 daily credits', 'Skip Trace unlocked', 'All agent pods', 'Priority support'],
    priceId: 'price_pro_monthly',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: '$297/mo',
    credits: 5000,
    icon: <Building2 size={20} className="text-atlas-gold" />,
    color: 'atlas-gold',
    features: ['5,000 daily credits', 'White-label ready', 'Custom agent training', 'Dedicated success mgr'],
    priceId: 'price_enterprise_monthly',
  },
]

export function StripeCheckoutModal() {
  const { closeModal } = useAtlasStore()

  async function checkout(priceId: string) {
    try {
      const res = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priceId }),
      })
      const { url } = await res.json()
      if (url) window.location.href = url
    } catch {
      toast.error('Stripe not configured. Add STRIPE_SECRET_KEY to .env.local')
    }
  }

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-atlas-purple/20 flex items-center justify-center">
          <CreditCard size={20} className="text-atlas-purple" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Upgrade ATLAS</h2>
          <p className="text-xs text-atlas-muted">Unlock full agent capabilities</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        {PLANS.map((plan) => (
          <div key={plan.id} className="atlas-panel p-4 rounded-xl border hover:border-atlas-accent/50 transition-all cursor-pointer group">
            <div className="flex items-center gap-2 mb-3">
              {plan.icon}
              <span className="font-bold text-white">{plan.name}</span>
            </div>
            <div className="text-2xl font-bold text-white mb-1">{plan.price}</div>
            <div className="text-xs text-atlas-muted mb-3">{plan.credits.toLocaleString()} credits/day</div>
            <ul className="space-y-1 mb-4">
              {plan.features.map((f) => (
                <li key={f} className="text-[11px] text-atlas-text flex items-center gap-1.5">
                  <Zap size={10} className="text-atlas-accent shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <button
              onClick={() => checkout(plan.priceId)}
              className="w-full py-2 rounded-lg bg-atlas-accent text-atlas-dark text-sm font-semibold hover:bg-atlas-accent/80 transition-all"
            >
              Select {plan.name}
            </button>
          </div>
        ))}
      </div>

      <button onClick={closeModal} className="w-full text-xs text-atlas-muted hover:text-atlas-text transition-colors py-2">
        Maybe later — stay on Free
      </button>
    </div>
  )
}
