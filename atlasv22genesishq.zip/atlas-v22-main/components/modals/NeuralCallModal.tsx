'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { Phone, Mic, MicOff, PhoneOff } from 'lucide-react'
import toast from 'react-hot-toast'

export function NeuralCallModal() {
  const { closeModal, modalData } = useAtlasStore()
  const [callStatus, setCallStatus] = useState<'idle' | 'calling' | 'connected' | 'ended'>('idle')
  const [muted, setMuted] = useState(false)

  const lead = modalData as { name?: string; phone?: string }

  async function startCall() {
    setCallStatus('calling')
    try {
      const res = await fetch('/api/twilio/call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: lead.phone }),
      })
      if (res.ok) setCallStatus('connected')
      else throw new Error()
    } catch {
      toast.error('Twilio not configured. Add credentials in Settings.')
      setCallStatus('idle')
    }
  }

  function endCall() {
    setCallStatus('ended')
    setTimeout(closeModal, 1500)
  }

  return (
    <div className="p-6 text-center">
      <div className="w-16 h-16 rounded-full bg-atlas-green/20 border-2 border-atlas-green/40 flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
        <Phone size={28} className="text-atlas-green" />
      </div>

      <h2 className="text-xl font-bold text-white mb-1">Neural Call Assistant</h2>
      <p className="text-atlas-muted text-sm mb-2">{lead.name ?? 'Unknown Lead'}</p>
      <p className="text-atlas-accent font-mono text-lg mb-6">{lead.phone ?? 'No phone'}</p>

      <div className={`text-xs font-mono mb-6 px-3 py-1.5 rounded-full inline-block ${
        callStatus === 'connected' ? 'bg-atlas-green/20 text-atlas-green' :
        callStatus === 'calling'   ? 'bg-atlas-gold/20 text-atlas-gold animate-pulse' :
        callStatus === 'ended'     ? 'bg-atlas-red/20 text-atlas-red' :
        'bg-atlas-muted/20 text-atlas-muted'
      }`}>
        {callStatus === 'connected' ? '● CONNECTED' :
         callStatus === 'calling'   ? '⟳ CALLING...' :
         callStatus === 'ended'     ? '✗ CALL ENDED' :
         '○ READY'}
      </div>

      <div className="flex gap-3 justify-center">
        {callStatus === 'idle' && (
          <button onClick={startCall} className="px-6 py-2.5 rounded-full bg-atlas-green text-atlas-dark font-semibold hover:bg-atlas-green/80 transition-all flex items-center gap-2">
            <Phone size={16} /> Start Call
          </button>
        )}
        {callStatus === 'connected' && (
          <>
            <button onClick={() => setMuted(!muted)} className={`px-4 py-2 rounded-full border transition-all ${muted ? 'bg-atlas-red/20 border-atlas-red text-atlas-red' : 'border-atlas-border text-atlas-muted hover:border-white'}`}>
              {muted ? <MicOff size={16} /> : <Mic size={16} />}
            </button>
            <button onClick={endCall} className="px-6 py-2.5 rounded-full bg-atlas-red text-white font-semibold hover:bg-atlas-red/80 transition-all flex items-center gap-2">
              <PhoneOff size={16} /> End Call
            </button>
          </>
        )}
        {(callStatus === 'idle' || callStatus === 'calling') && (
          <button onClick={closeModal} className="px-4 py-2.5 rounded-full border border-atlas-border text-atlas-muted hover:text-white hover:border-white transition-all">
            Cancel
          </button>
        )}
      </div>
    </div>
  )
}
