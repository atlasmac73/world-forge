'use client'

import { useState } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { Key, Eye, EyeOff, CheckCircle } from 'lucide-react'
import toast from 'react-hot-toast'

export function ApiKeyModal() {
  const { apiKeys, setApiKey, closeModal } = useAtlasStore()
  const [show, setShow] = useState<Record<string, boolean>>({})
  const [form, setForm] = useState({
    anthropic: apiKeys.anthropic ?? '',
    mapbox: apiKeys.mapbox ?? '',
    twilio_sid: apiKeys.twilio_sid ?? '',
    twilio_token: apiKeys.twilio_token ?? '',
    supabase_url: apiKeys.supabase_url ?? '',
    supabase_key: apiKeys.supabase_key ?? '',
  })

  function handleSave() {
    Object.entries(form).forEach(([key, value]) => {
      if (value) setApiKey(key as keyof typeof form, value)
    })
    toast.success('API keys saved securely')
    closeModal()
  }

  const fields = [
    { key: 'anthropic', label: 'Anthropic API Key', placeholder: 'sk-ant-...' },
    { key: 'supabase_url', label: 'Supabase URL', placeholder: 'https://xxx.supabase.co' },
    { key: 'supabase_key', label: 'Supabase Anon Key', placeholder: 'eyJ...' },
    { key: 'mapbox', label: 'Mapbox Token', placeholder: 'pk.eyJ...' },
    { key: 'twilio_sid', label: 'Twilio Account SID', placeholder: 'AC...' },
    { key: 'twilio_token', label: 'Twilio Auth Token', placeholder: '...' },
  ]

  return (
    <div className="p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-atlas-gold/20 flex items-center justify-center">
          <Key size={20} className="text-atlas-gold" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">API Key Configuration</h2>
          <p className="text-xs text-atlas-muted">Keys are stored locally — never sent to ATLAS servers.</p>
        </div>
      </div>

      <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
        {fields.map(({ key, label, placeholder }) => (
          <div key={key}>
            <label className="text-xs text-atlas-muted mb-1 block">{label}</label>
            <div className="relative">
              <input
                type={show[key] ? 'text' : 'password'}
                value={form[key as keyof typeof form]}
                onChange={(e) => setForm({ ...form, [key]: e.target.value })}
                placeholder={placeholder}
                className="w-full bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text placeholder-atlas-muted/50 focus:outline-none focus:border-atlas-accent pr-8 font-mono"
              />
              <button
                onClick={() => setShow({ ...show, [key]: !show[key] })}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-atlas-muted hover:text-atlas-text"
              >
                {show[key] ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-3 mt-6">
        <button
          onClick={closeModal}
          className="flex-1 py-2 rounded-lg border border-atlas-border text-atlas-muted hover:text-white hover:border-atlas-text transition-all text-sm"
        >
          Cancel
        </button>
        <button
          onClick={handleSave}
          className="flex-1 py-2 rounded-lg bg-atlas-accent text-atlas-dark font-semibold hover:bg-atlas-accent/80 transition-all text-sm flex items-center justify-center gap-2"
        >
          <CheckCircle size={14} />
          Save Keys
        </button>
      </div>
    </div>
  )
}
