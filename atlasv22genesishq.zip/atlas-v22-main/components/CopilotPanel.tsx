'use client'

import { useState, useRef, useEffect } from 'react'
import { useAtlasStore } from '@/store/useAtlasStore'
import { Send, Bot, Trash2, Loader2 } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import toast from 'react-hot-toast'

export function CopilotPanel() {
  const { messages, isStreaming, addMessage, updateLastMessage, clearMessages, setStreaming, consumeCredits } = useAtlasStore()
  const [input, setInput] = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function handleSend() {
    if (!input.trim() || isStreaming) return

    const userMsg = input.trim()
    setInput('')

    // Billing gate check
    if (!consumeCredits(2)) {
      toast.error('Daily credit limit reached. Upgrade to Pro for more.')
      return
    }

    addMessage({ role: 'user', content: userMsg })
    addMessage({ role: 'assistant', content: '' })
    setStreaming(true)

    try {
      const response = await fetch('/api/claude', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messages
            .filter((m) => m.content)
            .map((m) => ({ role: m.role, content: m.content }))
            .concat([{ role: 'user', content: userMsg }]),
        }),
      })

      if (!response.ok) throw new Error('Stream failed')

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let accumulated = ''

      while (reader) {
        const { done, value } = await reader.read()
        if (done) break
        const chunk = decoder.decode(value, { stream: true })
        accumulated += chunk
        updateLastMessage(accumulated)
      }
    } catch (err) {
      updateLastMessage('⚠️ Error connecting to ATLAS AI. Check your API key.')
      toast.error('Claude connection failed')
    } finally {
      setStreaming(false)
    }
  }

  return (
    <aside className="w-80 flex flex-col bg-atlas-panel border-l border-atlas-border h-screen shrink-0">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-atlas-border">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-atlas-accent/20 flex items-center justify-center">
            <Bot size={14} className="text-atlas-accent" />
          </div>
          <span className="text-sm font-semibold text-white">ATLAS Copilot</span>
          {isStreaming && <Loader2 size={12} className="text-atlas-accent animate-spin" />}
        </div>
        <button onClick={clearMessages} className="text-atlas-muted hover:text-atlas-red transition-colors">
          <Trash2 size={14} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.length === 0 && (
          <div className="text-center text-atlas-muted text-xs mt-8 space-y-2">
            <Bot size={32} className="mx-auto text-atlas-accent/30" />
            <p>ATLAS AI Copilot ready.</p>
            <p className="text-[11px]">Ask about properties, deals, market data, or run agent workflows.</p>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`animate-fade-in ${msg.role === 'user' ? 'flex justify-end' : ''}`}>
            {msg.role === 'user' ? (
              <div className="max-w-[85%] bg-atlas-accent/10 border border-atlas-accent/20 rounded-lg px-3 py-2 text-sm text-atlas-text">
                {msg.content}
              </div>
            ) : (
              <div className="text-xs text-atlas-text">
                <div className="flex items-center gap-1 mb-1">
                  <Bot size={10} className="text-atlas-accent" />
                  <span className="text-atlas-muted text-[10px]">ATLAS</span>
                </div>
                <div className="prose-atlas">
                  {msg.content ? (
                    <ReactMarkdown>{msg.content}</ReactMarkdown>
                  ) : (
                    <span className="text-atlas-muted animate-pulse">▊</span>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-3 border-t border-atlas-border">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="Ask ATLAS..."
            disabled={isStreaming}
            className="flex-1 bg-atlas-dark border border-atlas-border rounded-lg px-3 py-2 text-sm text-atlas-text placeholder-atlas-muted focus:outline-none focus:border-atlas-accent disabled:opacity-50 transition-colors"
          />
          <button
            onClick={handleSend}
            disabled={isStreaming || !input.trim()}
            className="w-8 h-8 rounded-lg bg-atlas-accent flex items-center justify-center text-atlas-dark hover:bg-atlas-accent/80 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
          >
            {isStreaming ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
          </button>
        </div>
        <div className="text-[9px] text-atlas-muted mt-1 text-center font-mono">
          Powered by Claude Opus 4.5 · 2 credits/msg
        </div>
      </div>
    </aside>
  )
}
