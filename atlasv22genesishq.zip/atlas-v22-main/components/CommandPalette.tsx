'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { useAtlasStore, type Portal } from '@/store/useAtlasStore'
import { 
  Search, 
  LayoutDashboard, 
  Map, 
  MessageSquare, 
  BarChart3, 
  Bot, 
  Wallet, 
  Settings,
  Zap,
  Users,
  Home,
  Phone,
  FileText,
  Activity
} from 'lucide-react'
import { clsx } from 'clsx'

interface CommandItem {
  id: string
  label: string
  description?: string
  icon: React.ReactNode
  category: 'navigation' | 'action' | 'agent' | 'tool'
  action: () => void
  shortcut?: string
}

export function CommandPalette() {
  const { 
    setActivePortal, 
    openModal, 
    addMessage, 
    setStreaming 
  } = useAtlasStore()
  
  const [isOpen, setIsOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [selectedIndex, setSelectedIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  const commands: CommandItem[] = [
    // Navigation
    { id: 'nav-dashboard', label: 'Dashboard', description: 'Command center overview', icon: <LayoutDashboard size={16} />, category: 'navigation', action: () => setActivePortal('dashboard'), shortcut: '⌘1' },
    { id: 'nav-deal', label: 'Deal Navigator', description: 'Property intelligence', icon: <Map size={16} />, category: 'navigation', action: () => setActivePortal('deal-navigator'), shortcut: '⌘2' },
    { id: 'nav-comms', label: 'Comms Hub', description: 'SMS & email sequences', icon: <MessageSquare size={16} />, category: 'navigation', action: () => setActivePortal('comms-hub'), shortcut: '⌘3' },
    { id: 'nav-market', label: 'Market Intel', description: 'Charleston market data', icon: <BarChart3 size={16} />, category: 'navigation', action: () => setActivePortal('market-intel'), shortcut: '⌘4' },
    { id: 'nav-agent', label: 'Agent Lab', description: 'Multi-agent orchestration', icon: <Bot size={16} />, category: 'navigation', action: () => setActivePortal('agent-lab'), shortcut: '⌘5' },
    { id: 'nav-wallet', label: 'SP6 Wallet', description: 'Credits & billing', icon: <Wallet size={16} />, category: 'navigation', action: () => setActivePortal('sp6-wallet'), shortcut: '⌘6' },
    { id: 'nav-settings', label: 'Settings', description: 'API keys & preferences', icon: <Settings size={16} />, category: 'navigation', action: () => setActivePortal('settings'), shortcut: '⌘7' },
    
    // Actions
    { id: 'action-analyze', label: 'Analyze Property', description: 'Run full dossier pipeline', icon: <Home size={16} />, category: 'action', action: () => { setActivePortal('deal-navigator'); setIsOpen(false) } },
    { id: 'action-sms', label: 'Launch SMS Sequence', description: 'Start 7-touch outreach', icon: <MessageSquare size={16} />, category: 'action', action: () => { setActivePortal('comms-hub'); setIsOpen(false) } },
    { id: 'action-call', label: 'Neural Call', description: 'AI-assisted phone call', icon: <Phone size={16} />, category: 'action', action: () => openModal('neural-call') },
    { id: 'action-api', label: 'Configure API Keys', description: 'Add or update credentials', icon: <Settings size={16} />, category: 'action', action: () => openModal('api-key') },
    { id: 'action-upgrade', label: 'Upgrade Plan', description: 'Get more credits', icon: <Zap size={16} />, category: 'action', action: () => openModal('stripe-checkout') },
    
    // Agents
    { id: 'agent-investigator', label: 'Run Investigator', description: 'Property research agent', icon: <Search size={16} />, category: 'agent', action: () => { setActivePortal('agent-lab'); setIsOpen(false) } },
    { id: 'agent-underwriter', label: 'Run Underwriter', description: 'Deal analysis agent', icon: <FileText size={16} />, category: 'agent', action: () => { setActivePortal('agent-lab'); setIsOpen(false) } },
    { id: 'agent-copywriter', label: 'Run Copywriter', description: 'Outreach copy agent', icon: <MessageSquare size={16} />, category: 'agent', action: () => { setActivePortal('agent-lab'); setIsOpen(false) } },
    { id: 'agent-swarm', label: 'Deploy Swarm', description: 'Multi-agent parallel execution', icon: <Activity size={16} />, category: 'agent', action: () => { setActivePortal('agent-lab'); setIsOpen(false) } },
    
    // Tools
    { id: 'tool-skip', label: 'Skip Trace', description: 'Owner lookup (10 credits)', icon: <Users size={16} />, category: 'tool', action: () => { setActivePortal('agent-lab'); setIsOpen(false) } },
    { id: 'tool-heatmap', label: 'Market Heatmap', description: 'ZIP opportunity scoring', icon: <BarChart3 size={16} />, category: 'tool', action: () => { setActivePortal('market-intel'); setIsOpen(false) } },
  ]

  const filteredCommands = query
    ? commands.filter(cmd => 
        cmd.label.toLowerCase().includes(query.toLowerCase()) ||
        cmd.description?.toLowerCase().includes(query.toLowerCase())
      )
    : commands

  const groupedCommands = {
    navigation: filteredCommands.filter(c => c.category === 'navigation'),
    action: filteredCommands.filter(c => c.category === 'action'),
    agent: filteredCommands.filter(c => c.category === 'agent'),
    tool: filteredCommands.filter(c => c.category === 'tool'),
  }

  const allFiltered = [...groupedCommands.navigation, ...groupedCommands.action, ...groupedCommands.agent, ...groupedCommands.tool]

  // Keyboard handler
  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Open with Cmd+K or Ctrl+K
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
      e.preventDefault()
      setIsOpen(true)
    }
    
    // Close with Escape
    if (e.key === 'Escape') {
      setIsOpen(false)
    }
  }, [])

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [handleKeyDown])

  useEffect(() => {
    if (isOpen) {
      inputRef.current?.focus()
      setQuery('')
      setSelectedIndex(0)
    }
  }, [isOpen])

  function handleInputKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setSelectedIndex(i => Math.min(i + 1, allFiltered.length - 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setSelectedIndex(i => Math.max(i - 1, 0))
    } else if (e.key === 'Enter' && allFiltered[selectedIndex]) {
      allFiltered[selectedIndex].action()
      setIsOpen(false)
    }
  }

  if (!isOpen) return null

  return (
    <div
      className="fixed inset-0 z-[9000] bg-black/75 backdrop-blur-sm flex items-start justify-center pt-20 animate-fade-in"
      onClick={(e) => e.target === e.currentTarget && setIsOpen(false)}
    >
      <div className="w-full max-w-xl bg-atlas-panel border border-atlas-border rounded-2xl shadow-2xl overflow-hidden">
        {/* Search Input */}
        <div className="relative border-b border-atlas-border">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-atlas-muted" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setSelectedIndex(0) }}
            onKeyDown={handleInputKeyDown}
            placeholder="Search views, agents, commands..."
            className="w-full bg-transparent border-none px-12 py-4 text-atlas-text text-base focus:outline-none placeholder-atlas-muted"
          />
          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-xs text-atlas-muted font-mono">
            ⌘K
          </div>
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto p-2">
          {Object.entries(groupedCommands).map(([category, items]) => {
            if (items.length === 0) return null
            
            return (
              <div key={category} className="mb-2">
                <div className="text-[10px] font-bold text-atlas-muted uppercase tracking-wider px-3 py-1">
                  {category}
                </div>
                {items.map((cmd) => {
                  const globalIndex = allFiltered.indexOf(cmd)
                  return (
                    <button
                      key={cmd.id}
                      onClick={() => { cmd.action(); setIsOpen(false) }}
                      onMouseEnter={() => setSelectedIndex(globalIndex)}
                      className={clsx(
                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-colors',
                        globalIndex === selectedIndex
                          ? 'bg-atlas-accent/10 border-l-2 border-atlas-accent'
                          : 'hover:bg-atlas-dark'
                      )}
                    >
                      <span className={clsx(
                        'shrink-0',
                        globalIndex === selectedIndex ? 'text-atlas-accent' : 'text-atlas-muted'
                      )}>
                        {cmd.icon}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm text-atlas-text font-medium">{cmd.label}</div>
                        {cmd.description && (
                          <div className="text-xs text-atlas-muted truncate">{cmd.description}</div>
                        )}
                      </div>
                      {cmd.shortcut && (
                        <span className="text-[10px] text-atlas-muted font-mono bg-atlas-dark px-1.5 py-0.5 rounded">
                          {cmd.shortcut}
                        </span>
                      )}
                    </button>
                  )
                })}
              </div>
            )
          })}

          {filteredCommands.length === 0 && (
            <div className="text-center py-8 text-atlas-muted text-sm">
              No results for "{query}"
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-atlas-border px-4 py-2 flex items-center justify-between text-[10px] text-atlas-muted">
          <div className="flex gap-3">
            <span><kbd className="px-1 py-0.5 rounded bg-atlas-dark">↑↓</kbd> Navigate</span>
            <span><kbd className="px-1 py-0.5 rounded bg-atlas-dark">↵</kbd> Select</span>
            <span><kbd className="px-1 py-0.5 rounded bg-atlas-dark">esc</kbd> Close</span>
          </div>
          <span className="font-mono">ATLAS v20</span>
        </div>
      </div>
    </div>
  )
}
