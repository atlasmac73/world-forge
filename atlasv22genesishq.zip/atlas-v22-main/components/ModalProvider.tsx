'use client'

import { useAtlasStore } from '@/store/useAtlasStore'
import { X } from 'lucide-react'
import { ApiKeyModal } from './modals/ApiKeyModal'
import { NeuralCallModal } from './modals/NeuralCallModal'
import { StripeCheckoutModal } from './modals/StripeCheckoutModal'
import { PropertyDetailModal } from './modals/PropertyDetailModal'

export function ModalProvider() {
  const { activeModal, closeModal } = useAtlasStore()

  if (!activeModal) return null

  const MODALS: Record<string, React.ReactNode> = {
    'api-key':        <ApiKeyModal />,
    'neural-call':    <NeuralCallModal />,
    'stripe-checkout': <StripeCheckoutModal />,
    'property-detail': <PropertyDetailModal />,
  }

  const content = MODALS[activeModal]
  if (!content) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm animate-fade-in"
      onClick={(e) => e.target === e.currentTarget && closeModal()}
    >
      <div className="relative bg-atlas-panel border border-atlas-border rounded-xl shadow-2xl w-full max-w-lg mx-4 animate-slide-in">
        {/* Close button */}
        <button
          onClick={closeModal}
          className="absolute top-3 right-3 text-atlas-muted hover:text-white transition-colors z-10"
          aria-label="Close modal"
        >
          <X size={18} />
        </button>
        {content}
      </div>
    </div>
  )
}
