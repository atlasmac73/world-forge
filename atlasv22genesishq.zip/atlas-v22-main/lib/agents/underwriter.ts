/**
 * ATLAS v20 — Underwriter Agent (L6)
 * Role: Financial analysis. Calculates ARV, equity, recommended offer, distress score.
 * Input: PropertyInvestigation from Investigator
 * Output: UnderwriterReport
 */

import Anthropic from '@anthropic-ai/sdk'
import type { PropertyInvestigation } from './investigator'

export interface UnderwriterReport {
  address: string
  arv: number               // After Repair Value
  equity_pct: number        // Equity percentage
  recommended_offer: number // MAO (Maximum Allowable Offer)
  distress_score: number    // 0-100
  deal_grade: 'A' | 'B' | 'C' | 'D' | 'F'
  estimated_repair: number
  net_profit_potential: number
  risk_factors: string[]
  investment_thesis: string
}

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function runUnderwriter(investigation: PropertyInvestigation): Promise<UnderwriterReport> {
  const response = await client.messages.create({
    model: 'claude-opus-4-5-20251101',
    max_tokens: 1024,
    system: `You are the ATLAS Underwriter Agent. You perform real estate deal analysis for WV distressed assets.
Formula: MAO = (ARV × 0.70) - Repairs. Distress score (0-100) based on: tax delinquency (+30), vacancy (+20), liens (+20), equity (+30).
Charleston WV ARV range: $90k-$250k. Repairs: $15k-$60k typical.
Return ONLY valid JSON. No markdown.`,
    messages: [{
      role: 'user',
      content: `Underwrite this property investigation and return a JSON UnderwriterReport:

${JSON.stringify(investigation, null, 2)}

Required: address, arv, equity_pct, recommended_offer, distress_score, deal_grade, estimated_repair, net_profit_potential, risk_factors (array), investment_thesis.`
    }],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''

  try {
    return JSON.parse(text) as UnderwriterReport
  } catch {
    const arv = investigation.assessed_value * 1.4
    const repair = 25000
    return {
      address: investigation.address,
      arv,
      equity_pct: 65,
      recommended_offer: Math.round(arv * 0.7 - repair),
      distress_score: investigation.tax_status === 'delinquent' ? 75 : 40,
      deal_grade: 'B',
      estimated_repair: repair,
      net_profit_potential: Math.round(arv * 0.2),
      risk_factors: ['Parse error — manual review recommended'],
      investment_thesis: text || 'Analysis pending manual review',
    }
  }
}
