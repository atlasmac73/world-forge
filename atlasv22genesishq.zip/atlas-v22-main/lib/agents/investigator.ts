/**
 * ATLAS v20 — Investigator Agent (L6)
 * Role: Deep property research. Fetches owner data, tax records, deed history.
 * Outputs: Structured PropertyInvestigation object.
 */

import Anthropic from '@anthropic-ai/sdk'

export interface PropertyInvestigation {
  address: string
  owner_name: string
  owner_phone?: string
  owner_email?: string
  owner_mailing_address?: string
  last_sale_date?: string
  last_sale_price?: number
  assessed_value: number
  tax_status: 'current' | 'delinquent' | 'unknown'
  tax_owed?: number
  years_delinquent?: number
  liens: string[]
  occupancy: 'owner-occupied' | 'vacant' | 'tenant' | 'unknown'
  year_built?: number
  sqft?: number
  bedrooms?: number
  bathrooms?: number
  lot_size?: string
  raw_notes: string
}

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function runInvestigator(address: string): Promise<PropertyInvestigation> {
  const response = await client.messages.create({
    model: 'claude-opus-4-5-20251101',
    max_tokens: 1024,
    system: `You are the ATLAS Investigator Agent. You research distressed properties in West Virginia.
Given a property address, produce a realistic property investigation report.
For the Charleston, WV market: median assessed values are $85k-$200k, many properties are tax-delinquent.
Return ONLY valid JSON matching the PropertyInvestigation schema. No markdown, no explanation.`,
    messages: [{
      role: 'user',
      content: `Investigate this property and return a JSON PropertyInvestigation object: ${address}

Required fields: address, owner_name, assessed_value, tax_status, liens (array), occupancy, raw_notes.
Optional: owner_phone, owner_email, last_sale_date, last_sale_price, tax_owed, years_delinquent, year_built, sqft, bedrooms, bathrooms.`
    }],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''

  try {
    return JSON.parse(text) as PropertyInvestigation
  } catch {
    // Fallback if JSON parse fails
    return {
      address,
      owner_name: 'Unknown Owner',
      assessed_value: 125000,
      tax_status: 'unknown',
      liens: [],
      occupancy: 'unknown',
      raw_notes: text,
    }
  }
}
