/**
 * ATLAS v20 — Copywriter Agent (L6)
 * Role: Generates personalized outreach copy for distressed property owners.
 * Input: Investigation + Underwriter data
 * Output: CopywriterOutput with 7-touch sequence drafts
 */

import Anthropic from '@anthropic-ai/sdk'
import type { PropertyInvestigation } from './investigator'
import type { UnderwriterReport } from './underwriter'

export interface CopywriterOutput {
  sms_touch_1: string
  sms_touch_2: string
  sms_touch_3: string
  email_touch_3: string
  sms_touch_4: string
  sms_touch_5: string
  email_touch_6: string
  sms_touch_7: string
  voicemail_script: string
  talking_points: string[]
}

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export async function runCopywriter(
  investigation: PropertyInvestigation,
  underwriting: UnderwriterReport
): Promise<CopywriterOutput> {
  const response = await client.messages.create({
    model: 'claude-opus-4-5-20251101',
    max_tokens: 2048,
    system: `You are the ATLAS Copywriter Agent. You write persuasive, empathetic outreach copy for distressed property owners in West Virginia.
Tone: Friendly, non-aggressive, solution-focused. Never sound predatory.
WV culture: Direct, neighborly, values honesty. Mention fast close, cash, as-is.
SMS limit: 160 chars. Emails: 3-5 short paragraphs.
Return ONLY valid JSON with the CopywriterOutput schema.`,
    messages: [{
      role: 'user',
      content: `Write a 7-touch outreach sequence for this owner:

Owner: ${investigation.owner_name}
Address: ${investigation.address}
Tax Status: ${investigation.tax_status}${investigation.tax_owed ? ` ($${investigation.tax_owed} owed)` : ''}
Occupancy: ${investigation.occupancy}
Our Offer: $${underwriting.recommended_offer.toLocaleString()}
Deal Grade: ${underwriting.deal_grade}

Return JSON CopywriterOutput with: sms_touch_1, sms_touch_2, sms_touch_3, email_touch_3, sms_touch_4, sms_touch_5, email_touch_6, sms_touch_7, voicemail_script, talking_points (array of 5).`
    }],
  })

  const text = response.content[0].type === 'text' ? response.content[0].text : ''

  try {
    return JSON.parse(text) as CopywriterOutput
  } catch {
    const ownerFirst = investigation.owner_name.split(' ')[0]
    return {
      sms_touch_1: `Hi ${ownerFirst}, I'm interested in buying your property at ${investigation.address} for cash, as-is. No repairs, fast close. Interested? Reply YES.`,
      sms_touch_2: `Hey ${ownerFirst}, following up on ${investigation.address}. I can close in 7 days, pay all fees. Would a fair cash offer help? Reply YES or STOP.`,
      sms_touch_3: `${ownerFirst}, still thinking about ${investigation.address}? Cash offer, no agents, no repairs. I cover closing costs. Reply anytime.`,
      email_touch_3: `Subject: Cash offer for ${investigation.address}\n\nHi ${ownerFirst},\n\nI wanted to follow up about your property. We buy homes as-is for cash in WV — quick close, no stress.\n\nWould you be open to a brief call?\n\nAtlas Investments`,
      sms_touch_4: `${ownerFirst}, one more thought on ${investigation.address}. If taxes are an issue, a cash sale can clear it all. Reply INFO.`,
      sms_touch_5: `Final follow-up ${ownerFirst}. Cash offer still stands for ${investigation.address}. No pressure — just here if you're ready. Reply YES.`,
      email_touch_6: `Subject: Still here if you need us\n\nHi ${ownerFirst},\n\nNo pressure — just wanted you to know our offer for ${investigation.address} stands whenever you're ready.\n\nAtlas Investments`,
      sms_touch_7: `Hi ${ownerFirst} — checking in one last time. If now isn't right, that's okay. I'm here whenever you're ready. - Atlas Investments`,
      voicemail_script: `Hi ${ownerFirst}, this is with Atlas Investments. I'm reaching out about your property on ${investigation.address.split(',')[0]}. We buy homes for cash in WV, any condition. Give me a call back at your convenience. No pressure. Thanks!`,
      talking_points: [
        'We close in 7 days — no waiting on bank financing',
        'You pay zero closing costs or agent fees',
        'We buy as-is — no repairs or cleanup needed',
        'Cash resolves any tax or lien issues immediately',
        'Flexible timeline — we work around your schedule',
      ],
    }
  }
}
