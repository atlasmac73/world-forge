// lib/genesis-hq/permissions.ts
// ATLAS v22 — Genesis HQ — Access Control
//
// atlas-v22 has no org/role table — every other feature in this app is
// gated by simple auth.uid() = user_id ownership. Genesis HQ is the
// founder's personal product command center, so admin/write actions are
// gated by a single owner check (GENESIS_HQ_OWNER_EMAIL) instead of a
// role matrix. Any authenticated user may *view* Genesis HQ content;
// only the owner may seed, reset, or edit it. All checks happen here,
// server-side — never trust a client-supplied role/flag.

import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export class GenesisHqAccessError extends Error {
  status: number
  constructor(message: string, status = 403) {
    super(message)
    this.status = status
  }
}

export interface GenesisHqContext {
  userId: string
  email: string
  isOwner: boolean
}

export async function getGenesisHqContext(): Promise<GenesisHqContext> {
  const supabase = createClient()
  const { data, error } = await supabase.auth.getUser()
  if (error || !data.user) {
    throw new GenesisHqAccessError('Not authenticated', 401)
  }

  const ownerEmail = process.env.GENESIS_HQ_OWNER_EMAIL?.trim().toLowerCase()
  const userEmail = data.user.email?.trim().toLowerCase() ?? ''
  const isOwner = Boolean(ownerEmail) && userEmail === ownerEmail

  return { userId: data.user.id, email: userEmail, isOwner }
}

/** Any authenticated user can view Genesis HQ content. */
export async function requireGenesisHqAccess(): Promise<GenesisHqContext> {
  return getGenesisHqContext()
}

/** Only the configured owner may seed, reset, or mutate Genesis HQ content. */
export async function requireGenesisHqOwner(): Promise<GenesisHqContext> {
  const ctx = await getGenesisHqContext()
  if (!ctx.isOwner) {
    throw new GenesisHqAccessError('Owner access required for this action', 403)
  }
  return ctx
}

export function canEditGenesisHqContent(ctx: GenesisHqContext): boolean {
  return ctx.isOwner
}

export function canManageGenesisHqAdmin(ctx: GenesisHqContext): boolean {
  return ctx.isOwner
}

export function canResetGenesisHq(ctx: GenesisHqContext): boolean {
  return ctx.isOwner
}

export function canToggleGenesisHqTasks(ctx: GenesisHqContext): boolean {
  return ctx.isOwner
}

export function canMoveGenesisHqKanbanCards(ctx: GenesisHqContext): boolean {
  return ctx.isOwner
}

export function handleGenesisHqPermissionError(error: unknown): NextResponse {
  if (error instanceof GenesisHqAccessError) {
    return NextResponse.json({ error: error.message }, { status: error.status })
  }
  console.error('[Genesis HQ] Unexpected error:', error)
  return NextResponse.json({ error: 'Unexpected error' }, { status: 500 })
}
