/**
 * ATLAS v22 — Genesis Cycle Engine
 * Autopoietic self-improvement system.
 * Phases: SENSE → INTERPRET → MUTATE → SIMULATE → PROMOTE → LEARN
 *
 * 15-minute heartbeat cron. $5/cycle budget kill switch.
 * All mutations require God Mode approval before production promotion.
 */

import { GOD_SQUAD, GENESIS_PHASES, type GenesiPhase } from '@/lib/agents/godSquad'

// ─── Types ────────────────────────────────────────────────────────────────────

export type CycleStatus = 'idle' | 'running' | 'awaiting_approval' | 'complete' | 'aborted'

export interface GenesisCycleRun {
  id: string
  startedAt: string
  completedAt?: string
  status: CycleStatus
  currentPhase: GenesiPhase
  phaseResults: Partial<Record<GenesiPhase, PhaseResult>>
  totalCostUsd: number
  budgetKillTriggered: boolean
  mutations: ProposedMutation[]
  approvalRequired: boolean
}

export interface PhaseResult {
  phase: GenesiPhase
  agentsUsed: string[]
  outputs: Record<string, unknown>
  costUsd: number
  durationMs: number
  insights: string[]
  errors: string[]
}

export interface ProposedMutation {
  id: string
  type: 'prompt_update' | 'routing_change' | 'new_tool' | 'threshold_adjustment' | 'agent_spawn'
  targetComponent: string
  currentValue: string
  proposedValue: string
  expectedImprovement: string
  riskLevel: 'low' | 'medium' | 'high'
  status: 'pending' | 'approved' | 'rejected' | 'deployed'
  githubPrUrl?: string
}

export interface ExecutionMetrics {
  agentSuccessRate: number
  avgResponseTimeMs: number
  creditEfficiency: number  // deals closed per 1000 credits
  leadConversionRate: number
  apiErrorRate: number
  userSatisfactionScore: number
  weekOverWeekDelta: number
}

export interface GenesisConfig {
  budgetLimitUsd: number          // default $5.00
  heartbeatIntervalMs: number     // default 15 minutes
  mutationApprovalRequired: boolean
  experimentBranch: string
  metricsThresholds: {
    minSuccessRate: number        // trigger mutation if below
    maxErrorRate: number
    minCreditEfficiency: number
  }
}

// ─── Default Config ───────────────────────────────────────────────────────────

export const DEFAULT_GENESIS_CONFIG: GenesisConfig = {
  budgetLimitUsd: 5.00,
  heartbeatIntervalMs: 15 * 60 * 1000,  // 15 minutes
  mutationApprovalRequired: true,
  experimentBranch: 'experiment/genesis-mutations',
  metricsThresholds: {
    minSuccessRate: 0.85,
    maxErrorRate: 0.05,
    minCreditEfficiency: 2.5,
  },
}

// ─── SENSE Phase ──────────────────────────────────────────────────────────────

export async function runSensePhase(config: GenesisConfig): Promise<PhaseResult> {
  const start = Date.now()
  const insights: string[] = []
  const errors: string[] = []
  let costUsd = 0

  try {
    // Gather execution metrics from Supabase agent_runs table
    const response = await fetch('/api/genesis/metrics', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    })

    if (!response.ok) throw new Error('Failed to fetch metrics')

    const metrics: ExecutionMetrics = await response.json()
    costUsd += 0.01  // minimal DB read cost

    // Generate insights
    if (metrics.agentSuccessRate < config.metricsThresholds.minSuccessRate) {
      insights.push(`⚠️ Agent success rate ${(metrics.agentSuccessRate * 100).toFixed(1)}% below threshold ${config.metricsThresholds.minSuccessRate * 100}%`)
    }
    if (metrics.apiErrorRate > config.metricsThresholds.maxErrorRate) {
      insights.push(`🔴 API error rate ${(metrics.apiErrorRate * 100).toFixed(1)}% exceeds threshold`)
    }
    if (metrics.weekOverWeekDelta < 0) {
      insights.push(`📉 Performance degrading: ${metrics.weekOverWeekDelta.toFixed(1)}% WoW`)
    }
    if (insights.length === 0) {
      insights.push(`✅ All metrics nominal. Success: ${(metrics.agentSuccessRate * 100).toFixed(1)}%`)
    }

    return {
      phase: 'SENSE',
      agentsUsed: ['gs-01', 'gs-02', 'gs-19'],
      outputs: { metrics },
      costUsd,
      durationMs: Date.now() - start,
      insights,
      errors,
    }
  } catch (err) {
    errors.push(`SENSE phase error: ${err instanceof Error ? err.message : 'Unknown'}`)
    return {
      phase: 'SENSE',
      agentsUsed: [],
      outputs: {},
      costUsd,
      durationMs: Date.now() - start,
      insights,
      errors,
    }
  }
}

// ─── INTERPRET Phase ──────────────────────────────────────────────────────────

export async function runInterpretPhase(
  senseResult: PhaseResult,
  config: GenesisConfig
): Promise<PhaseResult> {
  const start = Date.now()
  const insights: string[] = []
  const errors: string[] = []
  let costUsd = 0

  try {
    const response = await fetch('/api/genesis/interpret', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ senseData: senseResult.outputs, insights: senseResult.insights }),
    })

    if (!response.ok) throw new Error('Interpret API failed')

    const analysis = await response.json()
    costUsd += 0.08  // Claude API call

    const degradedComponents = analysis.degradedComponents || []
    if (degradedComponents.length > 0) {
      insights.push(`🔍 Degraded components identified: ${degradedComponents.join(', ')}`)
    }

    insights.push(`📊 Root cause analysis: ${analysis.primaryRootCause || 'None identified'}`)

    return {
      phase: 'INTERPRET',
      agentsUsed: ['gs-06', 'gs-19'],
      outputs: { analysis, degradedComponents },
      costUsd,
      durationMs: Date.now() - start,
      insights,
      errors,
    }
  } catch (err) {
    errors.push(`INTERPRET phase error: ${err instanceof Error ? err.message : 'Unknown'}`)
    return {
      phase: 'INTERPRET',
      agentsUsed: [],
      outputs: { degradedComponents: [] },
      costUsd,
      durationMs: Date.now() - start,
      insights,
      errors,
    }
  }
}

// ─── MUTATE Phase ─────────────────────────────────────────────────────────────

export async function runMutatePhase(
  interpretResult: PhaseResult,
  config: GenesisConfig
): Promise<PhaseResult> {
  const start = Date.now()
  const insights: string[] = []
  const errors: string[] = []
  let costUsd = 0
  const mutations: ProposedMutation[] = []

  try {
    const degradedComponents = (interpretResult.outputs.degradedComponents as string[]) || []

    if (degradedComponents.length === 0) {
      insights.push('✅ No mutations required — system performing within parameters')
      return {
        phase: 'MUTATE',
        agentsUsed: ['gs-12'],
        outputs: { mutations: [] },
        costUsd,
        durationMs: Date.now() - start,
        insights,
        errors,
      }
    }

    // Call MUTATION-ENGINE via API
    const response = await fetch('/api/genesis/mutate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ degradedComponents, budgetRemaining: config.budgetLimitUsd - costUsd }),
    })

    if (!response.ok) throw new Error('Mutate API failed')

    const result = await response.json()
    costUsd += 0.25  // larger Claude call for code generation

    result.mutations?.forEach((m: ProposedMutation) => {
      mutations.push({ ...m, status: 'pending' })
      insights.push(`🧬 Mutation proposed: ${m.type} on ${m.targetComponent} (risk: ${m.riskLevel})`)
    })

    return {
      phase: 'MUTATE',
      agentsUsed: ['gs-12', 'gs-20'],
      outputs: { mutations },
      costUsd,
      durationMs: Date.now() - start,
      insights,
      errors,
    }
  } catch (err) {
    errors.push(`MUTATE phase error: ${err instanceof Error ? err.message : 'Unknown'}`)
    return {
      phase: 'MUTATE',
      agentsUsed: [],
      outputs: { mutations: [] },
      costUsd,
      durationMs: Date.now() - start,
      insights,
      errors,
    }
  }
}

// ─── SIMULATE Phase ───────────────────────────────────────────────────────────

export async function runSimulatePhase(
  mutateResult: PhaseResult,
  config: GenesisConfig
): Promise<PhaseResult> {
  const start = Date.now()
  const insights: string[] = []
  const errors: string[] = []
  let costUsd = 0.03

  const mutations = (mutateResult.outputs.mutations as ProposedMutation[]) || []

  if (mutations.length === 0) {
    return {
      phase: 'SIMULATE',
      agentsUsed: [],
      outputs: { simulationResults: [] },
      costUsd: 0,
      durationMs: Date.now() - start,
      insights: ['✅ No mutations to simulate'],
      errors,
    }
  }

  const simulationResults = mutations.map((m) => ({
    mutationId: m.id,
    expectedImprovement: parseFloat(m.expectedImprovement) || 5,
    confidence: m.riskLevel === 'low' ? 0.85 : m.riskLevel === 'medium' ? 0.65 : 0.40,
    simulatedOutcome: m.riskLevel === 'high' ? 'CONDITIONAL_APPROVE' : 'APPROVE',
  }))

  simulationResults.forEach((r) => {
    insights.push(`🔬 Simulation: mutation ${r.mutationId} → ${r.simulatedOutcome} (${(r.confidence * 100).toFixed(0)}% confidence)`)
  })

  return {
    phase: 'SIMULATE',
    agentsUsed: ['gs-13', 'gs-14'],
    outputs: { simulationResults },
    costUsd,
    durationMs: Date.now() - start,
    insights,
    errors,
  }
}

// ─── PROMOTE Phase ────────────────────────────────────────────────────────────

export async function runPromotePhase(
  simulateResult: PhaseResult,
  config: GenesisConfig
): Promise<PhaseResult> {
  const start = Date.now()
  const insights: string[] = []
  const errors: string[] = []
  let costUsd = 0

  const simulationResults = (simulateResult.outputs.simulationResults as Array<{
    mutationId: string
    simulatedOutcome: string
  }>) || []

  const toPromote = simulationResults.filter((r) => r.simulatedOutcome === 'APPROVE')

  if (toPromote.length === 0) {
    return {
      phase: 'PROMOTE',
      agentsUsed: [],
      outputs: { promoted: [], awaitingApproval: true },
      costUsd,
      durationMs: Date.now() - start,
      insights: ['⏳ No auto-promotable mutations. Awaiting God Mode approval.'],
      errors,
    }
  }

  // Create GitHub PRs via API
  try {
    const response = await fetch('/api/genesis/promote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mutationIds: toPromote.map((r) => r.mutationId), branch: config.experimentBranch }),
    })

    costUsd += 0.02

    if (response.ok) {
      const result = await response.json()
      insights.push(`🚀 ${result.prsCreated} GitHub PRs created on ${config.experimentBranch}`)
      insights.push(`⏳ Awaiting God Mode approval in dashboard`)
    }
  } catch (err) {
    errors.push(`PR creation failed: ${err instanceof Error ? err.message : 'Unknown'}`)
    insights.push('📋 Mutations queued for manual promotion in God Mode dashboard')
  }

  return {
    phase: 'PROMOTE',
    agentsUsed: ['gs-12'],
    outputs: { promoted: toPromote, awaitingApproval: config.mutationApprovalRequired },
    costUsd,
    durationMs: Date.now() - start,
    insights,
    errors,
  }
}

// ─── LEARN Phase ──────────────────────────────────────────────────────────────

export async function runLearnPhase(
  allPhaseResults: Partial<Record<GenesiPhase, PhaseResult>>,
  config: GenesisConfig
): Promise<PhaseResult> {
  const start = Date.now()
  const insights: string[] = []
  const errors: string[] = []

  const totalCost = Object.values(allPhaseResults).reduce(
    (sum, r) => sum + (r?.costUsd ?? 0), 0
  )

  const totalInsights = Object.values(allPhaseResults).flatMap((r) => r?.insights ?? [])
  const totalErrors = Object.values(allPhaseResults).flatMap((r) => r?.errors ?? [])

  insights.push(`💡 Cycle complete. Total cost: $${totalCost.toFixed(4)}`)
  insights.push(`📈 ${totalInsights.length} insights generated across 6 phases`)
  if (totalErrors.length > 0) {
    insights.push(`⚠️ ${totalErrors.length} errors encountered — review required`)
  }
  insights.push(`🔄 Next cycle in ${Math.round(config.heartbeatIntervalMs / 60000)} minutes`)

  // Persist learning to Supabase
  try {
    await fetch('/api/genesis/learn', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cycleResults: allPhaseResults, totalCost, timestamp: new Date().toISOString() }),
    })
  } catch (err) {
    errors.push(`Learn persistence failed: ${err instanceof Error ? err.message : 'Unknown'}`)
  }

  return {
    phase: 'LEARN',
    agentsUsed: ['gs-19', 'gs-20', 'gs-25'],
    outputs: { totalCost, cycleInsights: totalInsights, cycleErrors: totalErrors },
    costUsd: 0.01,
    durationMs: Date.now() - start,
    insights,
    errors,
  }
}

// ─── Full Cycle Runner ────────────────────────────────────────────────────────

export async function runGenesisCycle(
  config: GenesisConfig = DEFAULT_GENESIS_CONFIG
): Promise<GenesisCycleRun> {
  const run: GenesisCycleRun = {
    id: crypto.randomUUID(),
    startedAt: new Date().toISOString(),
    status: 'running',
    currentPhase: 'SENSE',
    phaseResults: {},
    totalCostUsd: 0,
    budgetKillTriggered: false,
    mutations: [],
    approvalRequired: config.mutationApprovalRequired,
  }

  const checkBudget = () => {
    if (run.totalCostUsd >= config.budgetLimitUsd) {
      run.status = 'aborted'
      run.budgetKillTriggered = true
      console.warn(`[Genesis] 🛑 Budget kill triggered at $${run.totalCostUsd.toFixed(4)}`)
      return false
    }
    return true
  }

  const addPhaseResult = (result: PhaseResult) => {
    run.phaseResults[result.phase] = result
    run.totalCostUsd += result.costUsd
    run.currentPhase = result.phase
  }

  try {
    // SENSE
    if (!checkBudget()) return run
    const senseResult = await runSensePhase(config)
    addPhaseResult(senseResult)

    // INTERPRET
    if (!checkBudget()) return run
    run.currentPhase = 'INTERPRET'
    const interpretResult = await runInterpretPhase(senseResult, config)
    addPhaseResult(interpretResult)

    // MUTATE
    if (!checkBudget()) return run
    run.currentPhase = 'MUTATE'
    const mutateResult = await runMutatePhase(interpretResult, config)
    addPhaseResult(mutateResult)
    run.mutations = (mutateResult.outputs.mutations as ProposedMutation[]) || []

    // SIMULATE
    if (!checkBudget()) return run
    run.currentPhase = 'SIMULATE'
    const simulateResult = await runSimulatePhase(mutateResult, config)
    addPhaseResult(simulateResult)

    // PROMOTE
    if (!checkBudget()) return run
    run.currentPhase = 'PROMOTE'
    const promoteResult = await runPromotePhase(simulateResult, config)
    addPhaseResult(promoteResult)

    // LEARN
    run.currentPhase = 'LEARN'
    const learnResult = await runLearnPhase(run.phaseResults, config)
    addPhaseResult(learnResult)

    run.status = run.mutations.length > 0 ? 'awaiting_approval' : 'complete'
    run.completedAt = new Date().toISOString()

  } catch (err) {
    console.error('[Genesis] Cycle error:', err)
    run.status = 'aborted'
    run.completedAt = new Date().toISOString()
  }

  return run
}
