/**
 * ATLAS v20 — Utility Functions
 */

import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

// Classname merge utility
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Format currency
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

// Format percentage
export function formatPercent(value: number): string {
  return `${value.toFixed(1)}%`
}

// Format phone number
export function formatPhone(phone: string): string {
  const cleaned = phone.replace(/\D/g, '')
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`
  }
  if (cleaned.length === 11 && cleaned.startsWith('1')) {
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`
  }
  return phone
}

// Calculate MAO (Maximum Allowable Offer)
export function calculateMAO(arv: number, repairs: number): number {
  return Math.round(arv * 0.7 - repairs)
}

// Calculate distress score
export function calculateDistressScore(params: {
  taxDelinquent: boolean
  yearsDelinquent?: number
  vacant?: boolean
  liens?: number
  equity?: number
}): number {
  let score = 0
  
  if (params.taxDelinquent) score += 30
  if (params.yearsDelinquent && params.yearsDelinquent > 1) score += Math.min(params.yearsDelinquent * 5, 20)
  if (params.vacant) score += 20
  if (params.liens && params.liens > 0) score += Math.min(params.liens * 10, 20)
  if (params.equity && params.equity > 50) score += 10
  
  return Math.min(score, 100)
}

// Get deal grade based on distress score
export function getDealGrade(distressScore: number): 'A' | 'B' | 'C' | 'D' | 'F' {
  if (distressScore >= 80) return 'A'
  if (distressScore >= 60) return 'B'
  if (distressScore >= 40) return 'C'
  if (distressScore >= 20) return 'D'
  return 'F'
}

// Truncate text
export function truncate(text: string, length: number): string {
  if (text.length <= length) return text
  return text.slice(0, length) + '...'
}

// Generate unique ID
export function generateId(): string {
  return crypto.randomUUID()
}

// Delay utility
export function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

// Debounce function
export function debounce<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null
  return (...args: Parameters<T>) => {
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

// Parse address components
export function parseAddress(fullAddress: string): {
  street: string
  city: string
  state: string
  zip: string
} {
  const parts = fullAddress.split(',').map((p) => p.trim())
  const street = parts[0] || ''
  const city = parts[1] || ''
  const stateZip = parts[2]?.split(' ').filter(Boolean) || []
  const state = stateZip[0] || 'WV'
  const zip = stateZip[1] || ''
  
  return { street, city, state, zip }
}

// Check if valid email
export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

// Check if valid phone
export function isValidPhone(phone: string): boolean {
  const cleaned = phone.replace(/\D/g, '')
  return cleaned.length >= 10 && cleaned.length <= 11
}
