/**
 * ATLAS v20 — Zero-Trust Tool Gateway
 * Server-side only. All AI tool calls route through here.
 * Enforces: Auth check → Billing Gate → Rate Limit → Execute → Log
 */

'use server'

import Anthropic from '@anthropic-ai/sdk'
import { createClient } from '@/lib/supabase/server'

// ─── Types ────────────────────────────────────────────────────────────────────

export interface GatewayRequest {
  tool: string
  input: Record<string, unknown>
  userId: string
  sessionId: string
  creditsRequired?: number
}

export interface GatewayResponse {
  success: boolean
  data?: unknown
  error?: string
  creditsConsumed?: number
  tokensUsed?: number
}

export interface StreamRequest {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>
  systemPrompt?: string
  userId: string
  maxTokens?: number
}

// ─── Registered Tools ─────────────────────────────────────────────────────────

const TOOL_REGISTRY: Record<string, { credits: number; requiresPro: boolean }> = {
  'property.analyze':       { credits: 5,  requiresPro: false },
  'property.skipTrace':     { credits: 10, requiresPro: true  },
  'property.dossier':       { credits: 25, requiresPro: true  },
  'lead.smsSequence':       { credits: 3,  requiresPro: false },
  'lead.emailSequence':     { credits: 3,  requiresPro: false },
  'market.heatmap':         { credits: 8,  requiresPro: false },
  'agent.investigator':     { credits: 15, requiresPro: true  },
  'agent.underwriter':      { credits: 20, requiresPro: true  },
  'agent.copywriter':       { credits: 10, requiresPro: false },
  'agent.orchestrator':     { credits: 40, requiresPro: true  },
  'copilot.stream':         { credits: 2,  requiresPro: false },
}

// ─── Main Gateway ─────────────────────────────────────────────────────────────

export async function callTool(req: GatewayRequest): Promise<GatewayResponse> {
  const supabase = createClient()

  // 1. AUTH CHECK
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user || user.id !== req.userId) {
    return { success: false, error: 'Unauthorized: Invalid session' }
  }

  // 2. TOOL VALIDATION
  const toolConfig = TOOL_REGISTRY[req.tool]
  if (!toolConfig) {
    return { success: false, error: `Unknown tool: ${req.tool}` }
  }

  // 3. BILLING GATE
  const creditsNeeded = req.creditsRequired ?? toolConfig.credits
  const { data: wallet } = await supabase
    .from('sp6_user_wallets')
    .select('credits_used_today, credits_limit_daily, plan')
    .eq('user_id', req.userId)
    .single()

  if (!wallet) {
    return { success: false, error: 'Wallet not found' }
  }

  if (toolConfig.requiresPro && wallet.plan === 'free') {
    return { success: false, error: 'Pro plan required for this tool' }
  }

  if (wallet.credits_used_today + creditsNeeded > wallet.credits_limit_daily) {
    return {
      success: false,
      error: `Daily credit limit reached (${wallet.credits_limit_daily}). Upgrade to Pro for more.`,
    }
  }

  // 4. LOG RUN START
  const { data: run } = await supabase
    .from('agent_runs')
    .insert({
      user_id: req.userId,
      session_id: req.sessionId,
      tool_name: req.tool,
      input: req.input,
      status: 'running',
      credits_reserved: creditsNeeded,
    })
    .select()
    .single()

  // 5. EXECUTE TOOL
  let result: GatewayResponse
  try {
    result = await executeTool(req.tool, req.input, req.userId)
    result.creditsConsumed = creditsNeeded
  } catch (err) {
    const error = err instanceof Error ? err.message : 'Tool execution failed'
    result = { success: false, error }
  }

  // 6. UPDATE CREDITS & LOG
  if (result.success) {
    await supabase
      .from('sp6_user_wallets')
      .update({ credits_used_today: wallet.credits_used_today + creditsNeeded })
      .eq('user_id', req.userId)

    await supabase
      .from('agent_runs')
      .update({
        status: 'completed',
        output: result.data,
        credits_consumed: creditsNeeded,
        tokens_used: result.tokensUsed,
        completed_at: new Date().toISOString(),
      })
      .eq('id', run?.id)
  } else {
    await supabase
      .from('agent_runs')
      .update({ status: 'failed', error: result.error })
      .eq('id', run?.id)
  }

  return result
}

// ─── Tool Executor ─────────────────────────────────────────────────────────────

async function executeTool(
  tool: string,
  input: Record<string, unknown>,
  userId: string
): Promise<GatewayResponse> {
  switch (tool) {
    case 'property.skipTrace':
      return skipTraceViaWebhook(input)
    case 'market.heatmap':
      return generateHeatmapData(input)
    case 'copilot.stream':
      return { success: true, data: 'Use streamCopilot() for streaming responses' }
    default:
      return { success: true, data: `Tool ${tool} queued for execution` }
  }
}

// ─── Skip Trace via n8n Webhook ───────────────────────────────────────────────

async function skipTraceViaWebhook(input: Record<string, unknown>): Promise<GatewayResponse> {
  const webhookUrl = process.env.N8N_WEBHOOK_URL
  if (!webhookUrl) {
    return { success: false, error: 'n8n webhook URL not configured' }
  }

  const response = await fetch(`${webhookUrl}skip-trace`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  })

  if (!response.ok) {
    return { success: false, error: `Webhook error: ${response.statusText}` }
  }

  const data = await response.json()
  return { success: true, data }
}

// ─── Market Heatmap ───────────────────────────────────────────────────────────

async function generateHeatmapData(input: Record<string, unknown>): Promise<GatewayResponse> {
  // Charleston, WV hot zip codes for high-equity distressed assets
  const heatData = {
    market: input.market ?? 'Charleston, WV',
    top_zips: [
      { zip: '25301', score: 94, avg_equity: 68, tax_delinquent_count: 142, label: 'Downtown Charleston' },
      { zip: '25312', score: 87, avg_equity: 72, tax_delinquent_count: 89,  label: 'South Hills' },
      { zip: '25302', score: 82, avg_equity: 61, tax_delinquent_count: 76,  label: 'West Side' },
    ],
    generated_at: new Date().toISOString(),
  }
  return { success: true, data: heatData }
}

// ─── Claude Streaming (Server Action) ─────────────────────────────────────────

export async function* streamCopilot(req: StreamRequest) {
  const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

  const systemPrompt = req.systemPrompt ?? `You are the ATLAS AI Copilot — an elite real estate
investment intelligence assistant. You specialize in distressed asset analysis, deal underwriting,
skip tracing, and market intelligence for the Charleston, WV metro area. You have access to tools
for property analysis, lead management, and multi-agent orchestration. Be concise, data-driven,
and action-oriented.`

  const stream = client.messages.stream({
    model: 'claude-opus-4-5-20251101',
    max_tokens: req.maxTokens ?? 2048,
    system: systemPrompt,
    messages: req.messages,
  })

  for await (const chunk of stream) {
    if (
      chunk.type === 'content_block_delta' &&
      chunk.delta.type === 'text_delta'
    ) {
      yield chunk.delta.text
    }
  }
}
