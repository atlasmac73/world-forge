/**
 * ATLAS v22 — Real Data API: MLS Integration
 * Supports: WVMLS (West Virginia MLS), RETS/RESO Web API, IDX feeds
 * Falls back to mock data in development.
 */

import { NextRequest, NextResponse } from 'next/server'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const zip = searchParams.get('zip') || '25301'
  const limit = parseInt(searchParams.get('limit') || '20')
  const status = searchParams.get('status') || 'Active'
  const minEquity = parseInt(searchParams.get('minEquity') || '0')

  try {
    // ── Live MLS Connection ─────────────────────────────────────────────────
    // WVMLS uses RESO Web API standard
    // Production: replace with your MLS access token + endpoint
    const MLS_TOKEN = process.env.MLS_ACCESS_TOKEN
    const MLS_ENDPOINT = process.env.MLS_ENDPOINT || 'https://api.wvmls.com/reso/odata'

    if (MLS_TOKEN && MLS_ENDPOINT !== 'https://api.wvmls.com/reso/odata') {
      // Live MLS fetch
      const filter = [
        `PostalCode eq '${zip}'`,
        status !== 'all' ? `StandardStatus eq '${status}'` : '',
      ].filter(Boolean).join(' and ')

      const mlsResponse = await fetch(
        `${MLS_ENDPOINT}/Property?$filter=${encodeURIComponent(filter)}&$top=${limit}&$select=ListingKey,ListPrice,UnparsedAddress,City,StateOrProvince,PostalCode,LivingArea,BedroomsTotal,BathroomsTotalInteger,DaysOnMarket,ListingContractDate,PublicRemarks,Latitude,Longitude`,
        {
          headers: {
            'Authorization': `Bearer ${MLS_TOKEN}`,
            'Accept': 'application/json',
          },
        }
      )

      if (mlsResponse.ok) {
        const data = await mlsResponse.json()
        const properties = data.value.map(normalizeMLSProperty)
        return NextResponse.json({ source: 'live_mls', properties, count: properties.length })
      }
    }

    // ── PropStream Integration ──────────────────────────────────────────────
    const PROPSTREAM_KEY = process.env.PROPSTREAM_API_KEY
    if (PROPSTREAM_KEY) {
      const psResponse = await fetch('https://api.propstream.com/v1/properties/search', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${PROPSTREAM_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          filters: {
            postalCode: zip,
            listingStatus: status,
            equityPercentMin: minEquity,
          },
          limit,
          fields: ['address', 'listPrice', 'arv', 'equity', 'ownerInfo', 'taxInfo', 'coordinates'],
        }),
      })

      if (psResponse.ok) {
        const data = await psResponse.json()
        const properties = data.results.map(normalizePropStreamProperty)
        return NextResponse.json({ source: 'propstream', properties, count: properties.length })
      }
    }

    // ── Development Mock Data ───────────────────────────────────────────────
    const mockProperties = generateMockMLSData(zip, limit)
    return NextResponse.json({ source: 'mock', properties: mockProperties, count: mockProperties.length })

  } catch (error) {
    console.error('[MLS API] Error:', error)
    const mockProperties = generateMockMLSData(zip, limit)
    return NextResponse.json(
      { source: 'mock_fallback', properties: mockProperties, count: mockProperties.length, error: 'Live MLS unavailable' },
      { status: 200 }
    )
  }
}

// ─── Normalizers ──────────────────────────────────────────────────────────────

function normalizeMLSProperty(raw: Record<string, unknown>) {
  return {
    id: raw.ListingKey,
    address: raw.UnparsedAddress,
    city: raw.City,
    state: raw.StateOrProvince,
    zip: raw.PostalCode,
    list_price: raw.ListPrice,
    sqft: raw.LivingArea,
    beds: raw.BedroomsTotal,
    baths: raw.BathroomsTotalInteger,
    days_on_market: raw.DaysOnMarket,
    listed_date: raw.ListingContractDate,
    description: raw.PublicRemarks,
    lat: raw.Latitude,
    lng: raw.Longitude,
    source: 'mls',
  }
}

function normalizePropStreamProperty(raw: Record<string, unknown>) {
  const addr = raw.address as Record<string, string>
  const owner = raw.ownerInfo as Record<string, string>
  return {
    id: crypto.randomUUID(),
    address: `${addr?.street} ${addr?.city}, ${addr?.state} ${addr?.zip}`,
    city: addr?.city,
    state: addr?.state,
    zip: addr?.zip,
    list_price: raw.listPrice,
    arv: raw.arv,
    equity_pct: raw.equity,
    owner_name: `${owner?.firstName} ${owner?.lastName}`,
    source: 'propstream',
  }
}

// ─── Mock Data Generator ──────────────────────────────────────────────────────

const WV_STREETS = [
  'Kanawha Blvd', 'Virginia St', 'Quarrier St', 'Lee St', 'Washington St',
  'Elk St', 'Court St', 'Smith St', 'Bridge Rd', 'MacCorkle Ave',
  'Patrick St', 'Bigley Ave', 'Staunton Ave', 'Summers St', 'Capitol St',
]

const WV_CITIES: Record<string, string[]> = {
  '25301': ['Charleston', 'WV'],
  '25302': ['Charleston', 'WV'],
  '25303': ['South Charleston', 'WV'],
  '25401': ['Martinsburg', 'WV'],
  '25801': ['Beckley', 'WV'],
  '26101': ['Parkersburg', 'WV'],
  '26501': ['Morgantown', 'WV'],
  '25701': ['Huntington', 'WV'],
}

function generateMockMLSData(zip: string, limit: number) {
  const cityData = WV_CITIES[zip] || ['Charleston', 'WV']
  return Array.from({ length: Math.min(limit, 20) }, (_, i) => {
    const num = Math.floor(Math.random() * 2000) + 100
    const street = WV_STREETS[i % WV_STREETS.length]
    const listPrice = Math.floor(Math.random() * 180000) + 40000
    const arv = Math.floor(listPrice * (1.2 + Math.random() * 0.4))
    const equity = Math.round(((arv - listPrice) / arv) * 100)
    const distressScore = Math.floor(Math.random() * 100)

    return {
      id: `mock-${zip}-${i}`,
      address: `${num} ${street}`,
      city: cityData[0],
      state: cityData[1],
      zip,
      list_price: listPrice,
      arv,
      equity_pct: equity,
      sqft: Math.floor(Math.random() * 1800) + 800,
      beds: Math.floor(Math.random() * 3) + 2,
      baths: Math.floor(Math.random() * 2) + 1,
      days_on_market: Math.floor(Math.random() * 180),
      distress_score: distressScore,
      tax_delinquent: distressScore > 70,
      owner_name: generateWVName(),
      status: distressScore > 70 ? 'hot' : distressScore > 40 ? 'warm' : 'cold',
      lat: 38.3498 + (Math.random() - 0.5) * 0.1,
      lng: -81.6326 + (Math.random() - 0.5) + 0.1,
      source: 'mock',
    }
  })
}

function generateWVName(): string {
  const first = ['James', 'Mary', 'Robert', 'Patricia', 'John', 'Linda', 'William', 'Barbara', 'David', 'Dorothy']
  const last = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson', 'Moore', 'Taylor']
  return `${first[Math.floor(Math.random() * first.length)]} ${last[Math.floor(Math.random() * last.length)]}`
}
