/**
 * ATLAS v22 — Genesis promote endpoint
 * Delegates to /api/genesis main handler
 */
export { GET, POST } from '../route'
