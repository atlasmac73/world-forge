/**
 * ATLAS v22 — Genesis metrics endpoint
 * Delegates to /api/genesis main handler
 */
export { GET, POST } from '../route'
