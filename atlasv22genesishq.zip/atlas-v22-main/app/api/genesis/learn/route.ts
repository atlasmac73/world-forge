/**
 * ATLAS v22 — Genesis learn endpoint
 * Delegates to /api/genesis main handler
 */
export { GET, POST } from '../route'
