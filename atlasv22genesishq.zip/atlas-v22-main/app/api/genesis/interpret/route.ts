/**
 * ATLAS v22 — Genesis interpret endpoint
 * Delegates to /api/genesis main handler
 */
export { GET, POST } from '../route'
