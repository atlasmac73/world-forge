/**
 * ATLAS v22 — Genesis mutate endpoint
 * Delegates to /api/genesis main handler
 */
export { GET, POST } from '../route'
