/**
 * ATLAS v22 — Genesis Cycle API Routes
 * POST /api/genesis → triggers a full cycle run
 * GET  /api/genesis → returns last cycle status
 */

import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

// GET: return current system metrics for SENSE phase
export async function GET(request: NextRequest) {
  try {
    // In production: query Supabase agent_runs table
    // For now: return computed mock metrics
    const metrics = {
      agentSuccessRate: 0.89 + (Math.random() * 0.08 - 0.04),
      avgResponseTimeMs: 1200 + Math.floor(Math.random() * 800),
      creditEfficiency: 2.8 + (Math.random() * 1.0 - 0.5),
      leadConversionRate: 0.12 + (Math.random() * 0.06 - 0.03),
      apiErrorRate: 0.02 + (Math.random() * 0.03),
      userSatisfactionScore: 4.2 + (Math.random() * 0.6 - 0.3),
      weekOverWeekDelta: (Math.random() * 10 - 3).toFixed(1),
      sampleSize: Math.floor(Math.random() * 200) + 100,
      timestamp: new Date().toISOString(),
    }

    return NextResponse.json(metrics)
  } catch (error) {
    return NextResponse.json({ error: 'Metrics fetch failed' }, { status: 500 })
  }
}

// POST: trigger a genesis phase or full cycle
export async function POST(request: NextRequest) {
  const body = await request.json()
  const { phase, data, budget = 5.00 } = body

  if (!phase) {
    return NextResponse.json({ error: 'phase required' }, { status: 400 })
  }

  try {
    switch (phase) {
      case 'interpret': {
        const { senseData, insights } = data
        const message = await anthropic.messages.create({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1024,
          messages: [{
            role: 'user',
            content: `You are the INTERPRET phase of the ATLAS Genesis Cycle.
            
Analyze these system metrics and identify root causes of any performance issues:

Metrics: ${JSON.stringify(senseData, null, 2)}
Insights: ${insights.join('\n')}

Return a JSON object with:
- degradedComponents: array of component names that are underperforming
- primaryRootCause: string describing the main issue
- secondaryFactors: array of contributing factors
- urgency: "immediate" | "scheduled" | "none"

Return only valid JSON, no markdown.`
          }]
        })

        const text = message.content[0].type === 'text' ? message.content[0].text : '{}'
        const analysis = JSON.parse(text.replace(/```json|```/g, '').trim())
        return NextResponse.json(analysis)
      }

      case 'mutate': {
        const { degradedComponents } = data
        const message = await anthropic.messages.create({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 2048,
          messages: [{
            role: 'user',
            content: `You are MUTATION-ENGINE in the ATLAS Genesis Cycle.

These components are underperforming: ${degradedComponents.join(', ')}
Budget remaining: $${budget}

Generate up to 3 targeted mutations to improve these components.
Return a JSON object with:
- mutations: array of objects, each with:
  - id: string (uuid format)
  - type: "prompt_update" | "routing_change" | "threshold_adjustment"
  - targetComponent: string
  - currentValue: brief description of current behavior
  - proposedValue: the specific improvement
  - expectedImprovement: "X% improvement in [metric]"
  - riskLevel: "low" | "medium" | "high"

Keep total estimated cost under $${budget}. Return only valid JSON.`
          }]
        })

        const text = message.content[0].type === 'text' ? message.content[0].text : '{"mutations":[]}'
        const result = JSON.parse(text.replace(/```json|```/g, '').trim())
        // Ensure IDs are set
        result.mutations = (result.mutations || []).map((m: Record<string, unknown>) => ({
          ...m,
          id: m.id || crypto.randomUUID(),
          status: 'pending',
        }))
        return NextResponse.json(result)
      }

      case 'promote': {
        // In production: create GitHub PRs via GitHub API
        const { mutationIds, branch } = data
        const GITHUB_TOKEN = process.env.GITHUB_TOKEN
        const GITHUB_REPO = process.env.GITHUB_REPO || 'atlasmac73/atlas-v22'

        if (GITHUB_TOKEN && mutationIds.length > 0) {
          // Create a PR for mutations (simplified - production would generate actual code)
          const prResponse = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/pulls`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${GITHUB_TOKEN}`,
              'Accept': 'application/vnd.github.v3+json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              title: `[Genesis] Auto-mutation: ${mutationIds.length} improvements`,
              body: `Automated mutations proposed by ATLAS Genesis Cycle.\n\nMutation IDs: ${mutationIds.join(', ')}\n\nReview in God Mode dashboard before merging.`,
              head: branch,
              base: 'main',
              draft: true,
            }),
          })

          if (prResponse.ok) {
            const pr = await prResponse.json()
            return NextResponse.json({ prsCreated: 1, prUrl: pr.html_url })
          }
        }

        // Mock PR creation
        return NextResponse.json({
          prsCreated: mutationIds.length,
          prUrl: `https://github.com/${GITHUB_REPO}/pull/mock-${Date.now()}`,
          note: 'Mock PR — configure GITHUB_TOKEN for live PRs',
        })
      }

      case 'learn': {
        // Persist cycle results to Supabase
        // In production: write to genesis_cycles table
        const { cycleResults, totalCost, timestamp } = data
        console.log(`[Genesis LEARN] Cycle persisted. Cost: $${totalCost}. Time: ${timestamp}`)
        return NextResponse.json({ persisted: true, totalCost, timestamp })
      }

      default:
        return NextResponse.json({ error: `Unknown phase: ${phase}` }, { status: 400 })
    }
  } catch (error) {
    console.error('[Genesis API] Error:', error)
    return NextResponse.json({ error: 'Genesis phase execution failed' }, { status: 500 })
  }
}
