/**
 * ATLAS v20 — Property Dossier API Route
 * Orchestrates: Investigator → Underwriter → Copywriter
 * Returns full PropertyDossier from a single address
 */

import { NextRequest, NextResponse } from 'next/server'
import { runInvestigator } from '@/lib/agents/investigator'
import { runUnderwriter } from '@/lib/agents/underwriter'
import { runCopywriter } from '@/lib/agents/copywriter'

export async function POST(req: NextRequest) {
  try {
    const { address } = await req.json()

    if (!address) {
      return NextResponse.json({ error: 'Address required' }, { status: 400 })
    }

    // Step 1: Investigator — research the property
    const investigation = await runInvestigator(address)

    // Step 2: Underwriter — analyze the deal
    const underwriting = await runUnderwriter(investigation)

    // Step 3: Copywriter — generate outreach copy
    const copy = await runCopywriter(investigation, underwriting)

    // Compose final dossier
    const dossier = {
      address: investigation.address,
      owner: investigation.owner_name,
      equity_pct: underwriting.equity_pct,
      arv: underwriting.arv,
      distress_score: underwriting.distress_score,
      deal_grade: underwriting.deal_grade,
      tax_delinquent: investigation.tax_status === 'delinquent',
      recommended_offer: underwriting.recommended_offer,
      estimated_repair: underwriting.estimated_repair,
      net_profit_potential: underwriting.net_profit_potential,
      risk_factors: underwriting.risk_factors,
      notes: underwriting.investment_thesis,
      sms_draft: copy.sms_touch_1,
      full_sequence: {
        sms_1: copy.sms_touch_1,
        sms_2: copy.sms_touch_2,
        sms_3: copy.sms_touch_3,
        email_3: copy.email_touch_3,
        sms_4: copy.sms_touch_4,
        sms_5: copy.sms_touch_5,
        email_6: copy.email_touch_6,
        sms_7: copy.sms_touch_7,
      },
      voicemail: copy.voicemail_script,
      talking_points: copy.talking_points,
      raw_investigation: investigation,
      generated_at: new Date().toISOString(),
    }

    return NextResponse.json(dossier)
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Agent pipeline failed'
    console.error('[Dossier API]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
