/**
 * ATLAS v20 — Claude Streaming API Route
 * Streams Anthropic responses to the CopilotPanel
 */

import { NextRequest } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

export const runtime = 'edge'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

const SYSTEM_PROMPT = `You are the ATLAS AI Copilot — an elite real estate investment intelligence assistant.
You specialize in: distressed asset analysis, deal underwriting, skip tracing, market intelligence for Charleston, WV.
Your default market focus: Charleston, WV metro (ZIP codes 25301, 25312, 25302 are hotspots).
Be concise, data-driven, and action-oriented. Use numbers when possible.
When discussing deals: always reference MAO formula (ARV × 0.70 - Repairs).
Available portals: Deal Navigator, Comms Hub, Market Intel, Agent Lab, SP6 Wallet.`

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()

    const stream = new ReadableStream({
      async start(controller) {
        const response = client.messages.stream({
          model: 'claude-opus-4-5-20251101',
          max_tokens: 2048,
          system: SYSTEM_PROMPT,
          messages,
        })

        for await (const chunk of response) {
          if (
            chunk.type === 'content_block_delta' &&
            chunk.delta.type === 'text_delta'
          ) {
            controller.enqueue(new TextEncoder().encode(chunk.delta.text))
          }
        }

        controller.close()
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'X-Accel-Buffering': 'no',
      },
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return Response.json({ error: message }, { status: 500 })
  }
}
