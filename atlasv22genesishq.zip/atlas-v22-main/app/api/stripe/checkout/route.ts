/**
 * ATLAS v20 — Stripe Checkout API
 * Creates checkout sessions for Pro/Enterprise upgrades
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import Stripe from 'stripe'

const PLANS = {
  price_pro_monthly: {
    name: 'Pro',
    credits: 1000,
    plan: 'pro' as const,
  },
  price_enterprise_monthly: {
    name: 'Enterprise',
    credits: 5000,
    plan: 'enterprise' as const,
  },
}

export async function POST(req: NextRequest) {
  try {
    const { priceId } = await req.json()

    if (!priceId || !PLANS[priceId as keyof typeof PLANS]) {
      return NextResponse.json({ error: 'Invalid price ID' }, { status: 400 })
    }

    const stripeKey = process.env.STRIPE_SECRET_KEY
    if (!stripeKey) {
      return NextResponse.json(
        { error: 'Stripe not configured. Add STRIPE_SECRET_KEY to environment.' },
        { status: 503 }
      )
    }

    const stripe = new Stripe(stripeKey, { apiVersion: '2024-06-20' })
    const supabase = createClient()

    // Get current user
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get or create Stripe customer
    const { data: wallet } = await supabase
      .from('sp6_user_wallets')
      .select('stripe_customer_id')
      .eq('user_id', user.id)
      .single()

    let customerId = wallet?.stripe_customer_id

    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: { user_id: user.id },
      })
      customerId = customer.id

      await supabase
        .from('sp6_user_wallets')
        .update({ stripe_customer_id: customerId })
        .eq('user_id', user.id)
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}?checkout=success&plan=${PLANS[priceId as keyof typeof PLANS].name}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}?checkout=cancelled`,
      metadata: {
        user_id: user.id,
        plan: PLANS[priceId as keyof typeof PLANS].plan,
      },
    })

    return NextResponse.json({ url: session.url })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Checkout failed'
    console.error('[Stripe Checkout]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
