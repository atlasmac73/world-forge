/**
 * ATLAS v20 — Stripe Webhook Handler
 * Processes subscription events and updates user wallets
 */

import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import Stripe from 'stripe'

const PLAN_CREDITS: Record<string, number> = {
  free: 100,
  pro: 1000,
  enterprise: 5000,
}

export async function POST(req: NextRequest) {
  const stripeKey = process.env.STRIPE_SECRET_KEY
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET

  if (!stripeKey || !webhookSecret) {
    return NextResponse.json({ error: 'Stripe not configured' }, { status: 503 })
  }

  const stripe = new Stripe(stripeKey, { apiVersion: '2024-06-20' })
  const body = await req.text()
  const signature = req.headers.get('stripe-signature')

  if (!signature) {
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 })
  }

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Webhook verification failed'
    console.error('[Stripe Webhook]', message)
    return NextResponse.json({ error: message }, { status: 400 })
  }

  const supabase = createAdminClient()

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object as Stripe.Checkout.Session
      const userId = session.metadata?.user_id
      const plan = session.metadata?.plan as 'pro' | 'enterprise'

      if (userId && plan) {
        await supabase
          .from('sp6_user_wallets')
          .update({
            plan,
            credits_limit_daily: PLAN_CREDITS[plan],
            stripe_subscription_id: session.subscription as string,
          })
          .eq('user_id', userId)

        console.log(`[Stripe] User ${userId} upgraded to ${plan}`)
      }
      break
    }

    case 'customer.subscription.updated': {
      const subscription = event.data.object as Stripe.Subscription
      const customerId = subscription.customer as string

      // Find user by stripe_customer_id
      const { data: wallet } = await supabase
        .from('sp6_user_wallets')
        .select('user_id')
        .eq('stripe_customer_id', customerId)
        .single()

      if (wallet) {
        const isActive = subscription.status === 'active'
        
        if (!isActive) {
          // Downgrade to free if subscription inactive
          await supabase
            .from('sp6_user_wallets')
            .update({
              plan: 'free',
              credits_limit_daily: 100,
            })
            .eq('user_id', wallet.user_id)
        }
      }
      break
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object as Stripe.Subscription
      const customerId = subscription.customer as string

      // Downgrade to free
      const { data: wallet } = await supabase
        .from('sp6_user_wallets')
        .select('user_id')
        .eq('stripe_customer_id', customerId)
        .single()

      if (wallet) {
        await supabase
          .from('sp6_user_wallets')
          .update({
            plan: 'free',
            credits_limit_daily: 100,
            stripe_subscription_id: null,
          })
          .eq('user_id', wallet.user_id)

        console.log(`[Stripe] User ${wallet.user_id} downgraded to free`)
      }
      break
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object as Stripe.Invoice
      const customerId = invoice.customer as string

      console.warn(`[Stripe] Payment failed for customer ${customerId}`)
      // Could send email notification here
      break
    }

    default:
      console.log(`[Stripe] Unhandled event: ${event.type}`)
  }

  return NextResponse.json({ received: true })
}
