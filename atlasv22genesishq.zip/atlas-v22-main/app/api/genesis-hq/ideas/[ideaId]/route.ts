/**
 * ATLAS v22 — Genesis HQ Idea by ID
 * PATCH  /api/genesis-hq/ideas/[ideaId] → edit (owner-only)
 * DELETE /api/genesis-hq/ideas/[ideaId] → remove (owner-only)
 */

import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { requireGenesisHqOwner, handleGenesisHqPermissionError } from '@/lib/genesis-hq/permissions'
import { UpdateIdeaSchema } from '@/lib/genesis-hq/validators'

export async function PATCH(req: NextRequest, { params }: { params: { ideaId: string } }) {
  try {
    const ctx = await requireGenesisHqOwner()
    const body = await req.json()
    const parsed = UpdateIdeaSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = createAdminClient()
    const { data, error } = await supabase
      .from('genesis_hq_ideas')
      .update(parsed.data)
      .eq('id', params.ideaId)
      .select()
      .single()

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    if (!data) return NextResponse.json({ error: 'Idea not found' }, { status: 404 })

    await supabase.from('genesis_hq_audit_events').insert({
      user_id: ctx.userId,
      action: 'idea_updated',
      entity_type: 'idea',
      entity_id: params.ideaId,
      metadata: parsed.data,
    })

    return NextResponse.json(data)
  } catch (error) {
    return handleGenesisHqPermissionError(error)
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { ideaId: string } }) {
  try {
    const ctx = await requireGenesisHqOwner()
    const supabase = createAdminClient()
    const { error } = await supabase.from('genesis_hq_ideas').delete().eq('id', params.ideaId)
    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    await supabase.from('genesis_hq_audit_events').insert({
      user_id: ctx.userId,
      action: 'idea_deleted',
      entity_type: 'idea',
      entity_id: params.ideaId,
      metadata: {},
    })

    return NextResponse.json({ deleted: true })
  } catch (error) {
    return handleGenesisHqPermissionError(error)
  }
}
