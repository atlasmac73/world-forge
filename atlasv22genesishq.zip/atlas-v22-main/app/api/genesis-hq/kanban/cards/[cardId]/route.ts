/**
 * ATLAS v22 — Genesis HQ Kanban Card by ID
 * PATCH  /api/genesis-hq/kanban/cards/[cardId] → move/edit a card (owner-only)
 * DELETE /api/genesis-hq/kanban/cards/[cardId] → remove a card (owner-only)
 */

import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { requireGenesisHqOwner, handleGenesisHqPermissionError } from '@/lib/genesis-hq/permissions'
import { UpdateKanbanCardSchema } from '@/lib/genesis-hq/validators'

export async function PATCH(req: NextRequest, { params }: { params: { cardId: string } }) {
  try {
    const ctx = await requireGenesisHqOwner()
    const body = await req.json()
    const parsed = UpdateKanbanCardSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = createAdminClient()
    const { data, error } = await supabase
      .from('genesis_hq_kanban_cards')
      .update(parsed.data)
      .eq('id', params.cardId)
      .select()
      .single()

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    if (!data) return NextResponse.json({ error: 'Card not found' }, { status: 404 })

    await supabase.from('genesis_hq_audit_events').insert({
      user_id: ctx.userId,
      action: 'kanban_card_updated',
      entity_type: 'kanban_card',
      entity_id: params.cardId,
      metadata: parsed.data,
    })

    return NextResponse.json(data)
  } catch (error) {
    return handleGenesisHqPermissionError(error)
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { cardId: string } }) {
  try {
    const ctx = await requireGenesisHqOwner()
    const supabase = createAdminClient()
    const { error } = await supabase.from('genesis_hq_kanban_cards').delete().eq('id', params.cardId)
    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    await supabase.from('genesis_hq_audit_events').insert({
      user_id: ctx.userId,
      action: 'kanban_card_deleted',
      entity_type: 'kanban_card',
      entity_id: params.cardId,
      metadata: {},
    })

    return NextResponse.json({ deleted: true })
  } catch (error) {
    return handleGenesisHqPermissionError(error)
  }
}
