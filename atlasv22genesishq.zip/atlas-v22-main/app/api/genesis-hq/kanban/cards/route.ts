/**
 * ATLAS v22 — Genesis HQ Kanban Cards
 * POST /api/genesis-hq/kanban/cards → create a card (owner-only)
 */

import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { requireGenesisHqOwner, handleGenesisHqPermissionError } from '@/lib/genesis-hq/permissions'
import { CreateKanbanCardSchema } from '@/lib/genesis-hq/validators'

export async function POST(req: NextRequest) {
  try {
    const ctx = await requireGenesisHqOwner()
    const body = await req.json()
    const parsed = CreateKanbanCardSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = createAdminClient()
    const { data, error } = await supabase
      .from('genesis_hq_kanban_cards')
      .insert({ ...parsed.data, created_by: ctx.userId })
      .select()
      .single()

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    await supabase.from('genesis_hq_audit_events').insert({
      user_id: ctx.userId,
      action: 'kanban_card_created',
      entity_type: 'kanban_card',
      entity_id: data.id,
      metadata: parsed.data,
    })

    return NextResponse.json(data, { status: 201 })
  } catch (error) {
    return handleGenesisHqPermissionError(error)
  }
}
