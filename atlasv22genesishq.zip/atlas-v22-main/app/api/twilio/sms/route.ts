/**
 * ATLAS v20 — Twilio SMS API
 * Sends SMS messages and sequences
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  try {
    const { to, message, leadId, sequenceTouch } = await req.json()

    if (!to || !message) {
      return NextResponse.json({ error: 'Phone number and message required' }, { status: 400 })
    }

    // Validate environment
    const accountSid = process.env.TWILIO_ACCOUNT_SID
    const authToken = process.env.TWILIO_AUTH_TOKEN
    const fromNumber = process.env.TWILIO_PHONE_NUMBER

    if (!accountSid || !authToken || !fromNumber) {
      return NextResponse.json(
        { error: 'Twilio credentials not configured. Add them in Settings → API Keys.' },
        { status: 503 }
      )
    }

    // Format phone number
    const formattedTo = to.startsWith('+') ? to : `+1${to.replace(/\D/g, '')}`

    // Initialize Twilio client
    const twilio = await import('twilio')
    const client = twilio.default(accountSid, authToken)

    // Send SMS
    const sms = await client.messages.create({
      to: formattedTo,
      from: fromNumber,
      body: message,
      statusCallback: `${process.env.NEXT_PUBLIC_APP_URL}/api/twilio/sms/status`,
    })

    // Update lead if provided
    if (leadId) {
      const supabase = createClient()
      const updates: Record<string, unknown> = {
        last_contact: new Date().toISOString(),
      }
      
      if (sequenceTouch) {
        updates.touch_sequence = sequenceTouch
      }

      await supabase.from('leads').update(updates).eq('id', leadId)
    }

    return NextResponse.json({
      success: true,
      messageSid: sms.sid,
      status: sms.status,
      to: formattedTo,
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'SMS failed'
    console.error('[Twilio SMS API]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}

// Batch SMS for sequences
export async function PUT(req: NextRequest) {
  try {
    const { leads, template } = await req.json()

    if (!leads?.length || !template) {
      return NextResponse.json({ error: 'Leads array and template required' }, { status: 400 })
    }

    const accountSid = process.env.TWILIO_ACCOUNT_SID
    const authToken = process.env.TWILIO_AUTH_TOKEN
    const fromNumber = process.env.TWILIO_PHONE_NUMBER

    if (!accountSid || !authToken || !fromNumber) {
      return NextResponse.json({ error: 'Twilio not configured' }, { status: 503 })
    }

    const twilio = await import('twilio')
    const client = twilio.default(accountSid, authToken)
    const supabase = createClient()

    const results = []

    for (const lead of leads) {
      const { id, name, phone, address } = lead
      if (!phone) continue

      // Personalize template
      const personalizedMessage = template
        .replace(/{name}/g, name?.split(' ')[0] || 'there')
        .replace(/{address}/g, address || 'your property')

      const formattedTo = phone.startsWith('+') ? phone : `+1${phone.replace(/\D/g, '')}`

      try {
        const sms = await client.messages.create({
          to: formattedTo,
          from: fromNumber,
          body: personalizedMessage,
        })

        // Update lead
        await supabase.from('leads').update({
          last_contact: new Date().toISOString(),
          touch_sequence: (lead.touch_sequence || 0) + 1,
        }).eq('id', id)

        results.push({ id, success: true, sid: sms.sid })
      } catch (err) {
        results.push({ id, success: false, error: (err as Error).message })
      }
    }

    const successCount = results.filter((r) => r.success).length

    return NextResponse.json({
      success: true,
      total: leads.length,
      sent: successCount,
      failed: leads.length - successCount,
      results,
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Batch SMS failed'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
