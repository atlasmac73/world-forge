/**
 * ATLAS v20 — Twilio Voice Call API
 * Initiates outbound calls via Twilio
 */

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(req: NextRequest) {
  try {
    const { to, leadId } = await req.json()

    if (!to) {
      return NextResponse.json({ error: 'Phone number required' }, { status: 400 })
    }

    // Validate environment
    const accountSid = process.env.TWILIO_ACCOUNT_SID
    const authToken = process.env.TWILIO_AUTH_TOKEN
    const fromNumber = process.env.TWILIO_PHONE_NUMBER

    if (!accountSid || !authToken || !fromNumber) {
      return NextResponse.json(
        { error: 'Twilio credentials not configured. Add them in Settings → API Keys.' },
        { status: 503 }
      )
    }

    // Format phone number
    const formattedTo = to.startsWith('+') ? to : `+1${to.replace(/\D/g, '')}`

    // Initialize Twilio client dynamically (to avoid import errors if not configured)
    const twilio = await import('twilio')
    const client = twilio.default(accountSid, authToken)

    // Create the call
    const call = await client.calls.create({
      to: formattedTo,
      from: fromNumber,
      url: `${process.env.NEXT_PUBLIC_APP_URL}/api/twilio/twiml/outbound`,
      statusCallback: `${process.env.NEXT_PUBLIC_APP_URL}/api/twilio/status`,
      statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
    })

    // Log to database if leadId provided
    if (leadId) {
      const supabase = createClient()
      await supabase.from('leads').update({
        last_contact: new Date().toISOString(),
        notes: `Outbound call initiated: ${call.sid}`,
      }).eq('id', leadId)
    }

    return NextResponse.json({
      success: true,
      callSid: call.sid,
      status: call.status,
      to: formattedTo,
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Call failed'
    console.error('[Twilio Call API]', message)
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
