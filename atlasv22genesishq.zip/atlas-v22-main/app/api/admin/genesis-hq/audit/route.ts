/**
 * ATLAS v22 — Genesis HQ Admin: Audit Log
 * GET /api/admin/genesis-hq/audit → recent admin actions (owner-only)
 * Reads via the service-role client — genesis_hq_audit_events has no
 * authenticated-role RLS policy, so this is the only way to read it.
 */

import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@/lib/supabase/server'
import { requireGenesisHqOwner, handleGenesisHqPermissionError } from '@/lib/genesis-hq/permissions'
import { GENESIS_HQ_AUDIT_PAGE_SIZE } from '@/lib/genesis-hq/constants'

export async function GET(req: NextRequest) {
  try {
    await requireGenesisHqOwner()
    const { searchParams } = new URL(req.url)
    const limit = Math.min(Number(searchParams.get('limit')) || GENESIS_HQ_AUDIT_PAGE_SIZE, 200)

    const supabase = createAdminClient()
    const { data, error } = await supabase
      .from('genesis_hq_audit_events')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit)

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    return NextResponse.json({ events: data ?? [] })
  } catch (error) {
    return handleGenesisHqPermissionError(error)
  }
}
