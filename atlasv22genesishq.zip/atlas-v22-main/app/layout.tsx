/**
 * ATLAS v20 — Root Layout
 * App Router entry point. Mounts all providers cleanly.
 */

import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/Providers'
import { ModalProvider } from '@/components/ModalProvider'
import { Toaster } from 'react-hot-toast'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'ATLAS v20 — Real Estate AI Command Center',
  description: 'AI-powered real estate investment intelligence platform. Multi-agent deal analysis, skip tracing, market intel, and automated outreach.',
  keywords: ['real estate', 'AI', 'deal analysis', 'skip trace', 'investment'],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link href="https://api.mapbox.com/mapbox-gl-js/v3.5.1/mapbox-gl.css" rel="stylesheet" />
      </head>
      <body className={`${inter.className} bg-atlas-dark text-atlas-text overflow-hidden`}>
        <Providers>
          {/* Main app content */}
          {children}

          {/* Global modal host — renders all modals cleanly via portal */}
          <ModalProvider />

          {/* Toast notifications */}
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: '#0f0f1a',
                color: '#e0e0e0',
                border: '1px solid #1a1a2e',
              },
              success: { iconTheme: { primary: '#00ff88', secondary: '#0f0f1a' } },
              error:   { iconTheme: { primary: '#ff4444', secondary: '#0f0f1a' } },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
